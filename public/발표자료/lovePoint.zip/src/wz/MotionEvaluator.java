/*
 * Created on 2006. 5. 3
 */
package wz;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import wz.deprecated.LinearRegression;
import wz.deprecated.NoRegressionException;
import wz.motion.BulletMotion;
import wz.motion.LinearMotion;
import wz.motion.Motion;
import wz.motion.StuckMotion;
import wz.motion.TrackMotion;

public class MotionEvaluator {
    // �����ؾ��ϴ� �� - 1. ������ ������, 2. ������ �����ϴ� ���� ������

    public final double fieldWidth;
    public final double fieldHeight;

    public MotionEvaluator(double fieldWidth, double fieldHeight) {
        this.fieldHeight = fieldHeight;
        this.fieldWidth = fieldWidth;
    }

    // public static double evalSimilarity(Motion m1, Motion m2, double start, double end) {
    // // 0~1 ���� ��
    // return 1;
    // }
    //
    // public static double evalCorrelation(Motion m1, Motion m2, double start, double end, double atTime) {
    // // http://en.wikipedia.org/wiki/Correlation
    // return 1;
    // }
    //
    // public static DoublePair evalExpectedValue(Motion m, double start, double end) {
    // return null;
    // }
    //
    // public static DoublePair evalStandardDeviation(Motion m, double start, double end) {
    // return null;
    // }

    // public static BulletMotion evalBulletHitMotion(RoboTraits shooter, boolean isAccl, double shooterTurnRemaining, double shooterGunHeading, Motion target, double shootingPower) {
    // return (BulletMotion) _evalBulletHit(shooter, isAccl, shooterTurnRemaining, shooterGunHeading, target, shootingPower)[1];
    // }
    //
    // public static DoublePair evalBulletHitPolarPosition(RoboTraits shooter, boolean isAccl, double shooterTurnRemaining, double shooterGunHeading, Motion target, double shootingPower) {
    // return (DoublePair) _evalBulletHit(shooter, isAccl, shooterTurnRemaining, shooterGunHeading, target, shootingPower)[0];
    // }

    public static BulletMotion evalBulletHit(RoboTraits shooter, double shooterTurnRemaining, double shooterGunHeading, Motion target, double shootingPower) {
        DoublePair shooterPosition = shooter.xy;
        DoublePair targetPosition = target.evalXY(shooter.time);
        double turnTime = 0;
        double hitTime = 0;

        // 3-times iteration
        for (int i = 0, len = 3; i < len; ++i) {
            double enemyHeading = Tool.rectToPolar(targetPosition.v1, targetPosition.v2, shooterPosition.v1, shooterPosition.v2).v2;
            double relAngle = Tool.toRelRad(enemyHeading, shooterGunHeading);
            turnTime = (_signum(relAngle) == _signum(shooterTurnRemaining)) ? (Math.abs(relAngle / (Spec.GUN_TURN + Spec.getMaxBodyTurnRate(shooter.velocity)))) : (Math.abs(relAngle / (Spec.GUN_TURN - Spec.getMaxBodyTurnRate(shooter.velocity))));
            hitTime = shooter.time + turnTime + MotionEvaluator.evalDist(shooterPosition, targetPosition) / Spec.getBulletSpeed(shootingPower);
            // shooterPosition = new AcclMotion(shooter, isAccl).evalXY(shooter.time + turnTime);
            shooterPosition = new LinearMotion(shooter).evalXY(shooter.time + turnTime);
            Tool.polarToRect(shooter.velocity * turnTime, shooter.heading, shooterPosition.v1, shooterPosition.v2);
            targetPosition = target.evalXY(hitTime);
        }

        DoublePair polarPair = Tool.rectToPolar(targetPosition.v1, targetPosition.v2, shooterPosition.v1, shooterPosition.v2);
        BulletMotion motion = new BulletMotion(shooterPosition.v1, shooterPosition.v2, polarPair.v2, shootingPower, shooter.time + turnTime, hitTime, polarPair);
        // return new Object[] { polarPair, motion };
        return motion;
    }

    private static double _signum(double d) {
        return d > 0 ? 1 : d < 0 ? -1 : 0;
    }

    public DoublePair boundForBattleField(DoublePair rect) {
        return new DoublePair(Math.min(Math.max(rect.v1, Spec.BODY_RADIUS), fieldWidth - Spec.BODY_RADIUS), Math.min(Math.max(rect.v2, Spec.BODY_RADIUS), fieldHeight - Spec.BODY_RADIUS));
    }

    // public DoublePair evalHitPoint(double onX, double onY, double shootingHeading, double shootingPower, RoboHistory enemyHist, long fromTime) {
    // Motion enemy = predict(enemyHist);
    // Motion bullet = new BulletMotion(onX, onY, shootingHeading, shootingPower, fromTime);
    // return enemy.eval(hitAt(bullet, enemy, fromTime));
    // }

    // /**
    // * @return null if couldnot be solved, coeffs
    // */
    // public static double[] doCurveFitting(double[] times, double[] values, int order) {
    // ArrayList list = new ArrayList();
    //
    // for (int i = 0, len = times.length; i < len; ++i) {
    // double t = times[i];
    // double[] v = new double[order + 1];
    // for (int j = 0; j <= order; ++j)
    // v[j] = Math.pow(t, j);
    //
    // list.add(v);
    // }
    //
    // double[][] inA = (double[][]) list.toArray(new double[0][0]);
    // return solveX(inA, values);
    // }
    // /**
    // * get X to minimize |AX - B|
    // *
    // * @return null if couldnot be solved
    // */
    // public static double[] solveX(double[][] inA, double[] inB) {
    // // TODO
    // try {
    // RealMatrix A = new RealMatrixImpl(inA);
    // RealMatrix B = new RealMatrixImpl(inB);
    //
    // RealMatrix tA = A.transpose();
    // RealMatrix tAA = tA.multiply(A);
    //
    // RealMatrix X = tAA.inverse().multiply(tA).multiply(B);
    // return X.getColumn(0);
    // } catch (Throwable t) {
    // // ������
    // return null;
    // }
    // }

    public static double evalDist(DoublePair pair1, DoublePair pair2) {
        return Math.sqrt(Math.pow((pair1.v1 - pair2.v1), 2) + Math.pow((pair1.v2 - pair2.v2), 2));
    }

    public Motion predict2(Arena arena, String targetName) {
        // ���� ������ ����

        RoboHistory hist = arena.get(targetName);
        if (hist == null)
            return null;

        double refTime = hist.getRecent().time;
        RoboTraits[] ts = hist.getFromTime((long) (refTime - 8));
        int cnt = 0; // 8�����ӳ� �ӵ��� 1 ������ ���� 1���� ������ stuck motion
        for (int i = 0, len = ts.length; i < len; ++i) {
            // if (Math.abs(ts[i].velocity) <= 1)
            if (Math.abs(ts[i].velocity) <= 5)
                ++cnt;
        }
        Motion motion;
        if (cnt >= 1) {
            // System.out.println("regression");
            motion = new StuckMotion(hist.getRecent().xy);
            // motion = predict2(arena, targetName);// new StuckMotion(hist.getRecent().xy);

        } else
            motion = TrackMotion.createMotion(hist, fieldWidth, fieldHeight);

        return motion;
    }

    public Motion predict(Arena arena, String targetName) {
        return predictSectorProbability(arena, targetName);
// return predictLinearRegression(arena, targetName);
    }

    public Motion predictSectorProbability(Arena arena, String targetName) {
        RoboHistory iHist = arena.getMyself();
        RoboHistory eHist = arena.get(targetName);
        if (eHist == null)
            return null;

        BulletTraits[] bullets = arena.getFireHistory().getBulletTraits(targetName);
        ArrayList<PredictionFeature> predictionFeatures = new ArrayList<PredictionFeature>(bullets.length);
        {
            // index�� ���� ���� �ֽ�
            for (int i = 0, len = bullets.length; i < len; ++i) {
                BulletTraits b = bullets[i];
                if (b.bulletMotion.expectedHitTime > eHist.getRecent().time) // HitTime�� ���� �ʾ����� skip
                    continue;
                if (b._predictionFeature == null) {
                    BulletMotion bm = b.bulletMotion;
                    RoboTraits initT = eHist.getNearTime(bm.fireTime);
                    RoboTraits finalT = eHist.getNearTime(bm.expectedHitTime);
                    RoboTraits initMyT = iHist.getNearTime(bm.fireTime);

                    double dTime = bm.expectedHitTime - bm.fireTime;
                    DoublePair dPolarPos = Tool.rectToPolar(finalT.x, finalT.y, initT.x, initT.y);
                    double meToEnemyHeading = Tool.rectToPolar(initT.x, initT.y, initMyT.x, initMyT.y).v2;
                    dPolarPos = new DoublePair(dPolarPos.v1, Tool.toRelRad(dPolarPos.v2, meToEnemyHeading));
                    double initRelRad = Tool.toRelRad(initT.heading, meToEnemyHeading);
                    double initVelocity = initT.velocity;
                    b._predictionFeature = new PredictionFeature(dTime, dPolarPos, initRelRad, initVelocity, bm.power, bm.hitPolarPosPair.v1); // cache
                }
                predictionFeatures.add(b._predictionFeature);
// if (predictionFeatures.size() > 30) // �ִ� �� ����
// break;
            }
        }

        RoboTraits me = iHist.getRecent();
        RoboTraits enemy = eHist.getRecent();
        DoublePair meToEnemy = Tool.rectToPolar(enemy.x, enemy.y, me.x, me.y);
        double eRelHead = Tool.toPrincipleRad(Tool.toRelRad(enemy.heading, meToEnemy.v2) + ((Math.signum(enemy.velocity) < 0) ? Math.PI : 0));

        int sector = (int) Math.round(eRelHead / (Math.PI * .5)) % 4;
        System.out.println("\ne" + sector);

        double sumDist = 0;
        double sumTh = 0;
        double cnt = 0;
        Iterator<PredictionFeature> itr = predictionFeatures.iterator();
        while (itr.hasNext()) {
            PredictionFeature p = itr.next();
            double relHead = Tool.toPrincipleRad(p.initRelRad + (Math.signum(p.initVelocity) < 0 ? Math.PI : 0));
            int pSector = (int) Math.round(relHead / (Math.PI * .5)) % 4;
            System.out.print(" en" + pSector);
            if (sector == pSector) {
                sumDist += p.dPolarPos.v1;
                sumTh += p.dPolarPos.v2;
                cnt++;
            }
        }

        if (cnt == 0)
            return new LinearMotion(enemy);
// return predictLinearRegression(arena, targetName);
        else {
// return new LinearMotion(enemy.x, enemy.y, Tool.toRelRad(sumTh / cnt, meToEnemy.v2), sumDist / cnt, enemy.time, fieldWidth, fieldWidth);
            return new StuckMotion(Tool.polarToRect(sumDist / cnt, sumTh / cnt, enemy.x, enemy.y));
        }
    }

    public Motion predictLinearRegression(Arena arena, String targetName) {
        // System.out.println("predict2");
        RoboHistory iHist = arena.getMyself();
        RoboHistory eHist = arena.get(targetName);
        if (eHist == null)
            return null;

        BulletTraits[] bullets = arena.getFireHistory().getBulletTraits(targetName);
        ArrayList<PredictionFeature> predictionFeatures = new ArrayList<PredictionFeature>(bullets.length);
        {
            // index�� ���� ���� �ֽ�
            for (int i = 0, len = bullets.length; i < len; ++i) {
                BulletTraits b = bullets[i];
                if (b.bulletMotion.expectedHitTime > eHist.getRecent().time) // HitTime�� ���� �ʾ����� skip
                    continue;
                if (b._predictionFeature == null) {
                    BulletMotion bm = b.bulletMotion;
                    RoboTraits initT = eHist.getNearTime(bm.fireTime);
                    RoboTraits finalT = eHist.getNearTime(bm.expectedHitTime);
                    RoboTraits initMyT = iHist.getNearTime(bm.fireTime);

                    double dTime = bm.expectedHitTime - bm.fireTime;
                    DoublePair dPolarPos = Tool.rectToPolar(finalT.x, finalT.y, initT.x, initT.y);
                    double meToEnemyHeading = Tool.rectToPolar(initT.x, initT.y, initMyT.x, initMyT.y).v2;
                    dPolarPos = new DoublePair(dPolarPos.v1, Tool.toRelRad(dPolarPos.v2, meToEnemyHeading));
                    double initRelRad = Tool.toRelRad(initT.heading, meToEnemyHeading);
                    double initVelocity = initT.velocity;
                    b._predictionFeature = new PredictionFeature(dTime, dPolarPos, initRelRad, initVelocity, bm.power, bm.hitPolarPosPair.v1); // cache
                }
                predictionFeatures.add(b._predictionFeature);
                if (predictionFeatures.size() > 30) // �ִ� 12����
                    break;
            }
        }

        // input - ((initRelRad, initVel), dist) -> output - combination of (r, th) -> -> stuck motion
        LinearRegression lr = new LinearRegression();
        // MultipleLinearRegression lr = new MultipleLinearRegression();
        {
            // Iterator itr = predictionFeatures.iterator();
            // double sumX = 0;
            // double sumXX = 0;
            // double n = 0;
            // while (itr.hasNext()) {
            // PredictionFeature pf = (PredictionFeature) itr.next();
            // double rz = (pf.dPolarPos.v1 * Math.sin(pf.dPolarPos.v2));//
            // sumX += rz;
            // sumXX += rz * rz;
            // ++n;
            // }
            //
            // double mean = sumX / n;
            // double sigma = Math.sqrt((sumXX / n) - ((sumX / n) * (sumX / n)));

            Iterator<PredictionFeature> itr = predictionFeatures.iterator();
            while (itr.hasNext()) {
                PredictionFeature pf = itr.next();
                // double rx = pf.hitDist;
                double ry = pf.initVelocity * (pf.initRelRad >= 0 ? 1 : -1);
                double rz = (pf.dPolarPos.v1 * Math.sin(pf.dPolarPos.v2));//
                // * ((pf.hitDist + (pf.dPolarPos.v1 * Math.cos(pf.dPolarPos.v2) / 2)) / (pf.hitDist + (pf.dPolarPos.v1 * Math.cos(pf.dPolarPos.v2))));

                // if ((rz - mean) / sigma > 2 * sigma || (rz - mean) / sigma < 2 * sigma) {
                // System.out.println(rz + " " + mean + " " + sigma);
                // continue;
                // }

                lr.addSample(ry, rz);
                // lr.addSample(rx, ry, rz);
            }
        }

        try {
            RoboTraits me = iHist.getRecent();
            RoboTraits enemy = eHist.getRecent();

            DoublePair meToEnemy = Tool.rectToPolar(enemy.x, enemy.y, me.x, me.y);
            // double rx = evalDist(me.xy, enemy.xy);
            double ry = enemy.velocity * (Tool.toRelRad(enemy.heading, meToEnemy.v2) >= 0 ? 1 : -1);
            // double rz = lr.estimateZ(rx, ry);
            double rz = lr.estimateY(ry) * 1.1397;// * rx / 350;
            // System.out.println(rz);

            if (Math.abs(rz) > 85) {
                return predict2(arena, targetName);
            }

            // double maxRz = 70;// Spec.MAX_BODY_SPEED * meToEnemy.v1 / Spec.getBulletSpeed(0.2);
            // if (rz > maxRz)
            // rz = maxRz;
            // else if (rz < -maxRz)
            // rz = -maxRz;
            // System.out.println(rx + " " + ry + " " + rz + " " + maxRz);

            DoublePair expected = Tool.polarToRect(rz, Tool.toPrincipleRad(meToEnemy.v2 + Math.PI / 2), enemy.x, enemy.y);
            return new StuckMotion(expected);
        } catch (NoRegressionException e) {
            // System.out.println("no regression");
            // RoboTraits et = eHist.getRecent();
            // return new LinearMotion(et.x, et.y, et.heading, et.velocity / 2, et.time, fieldWidth, fieldHeight);
            return new StuckMotion(eHist.getRecent().xy);
        }
    }

    // public Motion predict(Arena arena, String targetName) {
    // final RoboHistory eHist = arena.get(targetName);
    // if (eHist == null)
    // return null;
    //
    // RoboTraits eT = eHist.getRecent();
    // final double endTime = eT.time;
    // DoublePair endPos = eT.xy;
    //
    // int phase = 0;
    //
    // double lastTime = endTime;
    // double predist = 0;
    // Iterator itr = eHist.getRecentOrderIterator();
    // while (itr.hasNext()) {
    // RoboTraits lt = (RoboTraits) itr.next();
    // lastTime = lt.time;
    // double dist = evalDist(endPos, lt.xy);
    // if (phase == 0 && predist > dist)
    // phase = 1;
    // else if (phase == 1 && predist < dist) {
    // phase = 2;
    // break;
    // }
    // predist = dist;
    // }
    //
    // final double period = endTime - lastTime;
    //
    // if (phase == 2 && period < 30) {
    //
    // // final double bT = (eT.time - period);
    // // System.out.println(period +" "+bT);
    //
    // Motion m = new Motion() {
    // public DoublePair eval(double time) {
    // // double cT = (bT + (time - endTime));
    // double cT = time - period;
    // RoboTraits nt = eHist.getNearTime(cT);
    //
    // return nt.xy;
    // }
    // };
    //
    // return m;
    // } else {
    // return new StuckMotion(eHist.getRecent().xy);
    // }
    // }

    public Motion predictMe(Arena arena, String enemyName, double power) {
        // ���� �����ϴ� ���� ������ ����

        // TODO ������ �����ϴ� �� - ���� ��� ������ ������ �����ϰ� �������.. �ϴ� ���� ���� ��ġ��
        // TODO ���߿� �κ����� �ٸ��� motion�� ����

        Double offsetO = (Double) avoidOffset.get(enemyName);
        double offset = (offsetO == null) ? 0 : offsetO.doubleValue();
        // double offset = avoidOffset.get(enemyName);

        int hitScore = arena.getHitScoreBy(enemyName);
        if (hitScore >= 2) {
            arena.resetHitScoreBy(enemyName);
            // random
            if (offset == 0) {
                offset = 85;
            } else if (offset == 85) {
                offset = -85;
            } else {
                offset = 0;
            }

            avoidOffset.put(enemyName, offset);
        }

        // System.out.println(offset);
        if (offset == 0)
            return new StuckMotion(arena.getMyself().getRecent().xy);
        else {
            RoboHistory iHist = arena.getMyself();
            RoboHistory eHist = arena.get(enemyName);
            if (eHist == null)
                return new StuckMotion(arena.getMyself().getRecent().xy);

            RoboTraits et = eHist.getRecent();
            RoboTraits it = iHist.getRecent();

            double theta = Tool.toPrincipleRad((Tool.rectToPolar(it.x, it.y, et.x, et.y).v2 - Math.PI / 2));

            return new StuckMotion(Tool.polarToRect(offset, theta, it.x, it.y));
        }
    }

    private HashMap<String, Double> avoidOffset = new HashMap<String, Double>();

}
