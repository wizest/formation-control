/*
 * Created on 2007. 06. 07
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.math;

import java.util.Vector;

interface StateEquations {

    void doStart(); // to set x0

    Vector<Double> evalDifference(int step, Vector<Double> x, Vector<Double> u);

    Vector<Double> evalOutput(int step, Vector<Double> x, Vector<Double> u);

    void doTerminate();
}
                                