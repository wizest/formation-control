/*
 * Created on 2007. 06. 19
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.math;

public class Trajectory {

}
