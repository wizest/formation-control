/*
 * Created on 2007. 06. 26
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.math;

import java.util.Vector;

import wz.Spec;

public class BodyDynamics implements StateEquations {

    public void doStart() {}

    public void doTerminate() {}

    public Vector<Double> evalDifference(int step, Vector<Double> x, Vector<Double> u) {
        // states
        double x1 = x.get(0);
        double y1 = x.get(1);
        double th1 = x.get(2);
        double v1 = x.get(3);

        // inputs
        double phi = u.get(0);
        double s = u.get(1);

        // updates
        double x2 = x1 + v1 * Math.sin(th1);
        double y2 = y1 + v1 * Math.cos(th1);
        double th2 = th1 + satTurnRate(v1, phi);
        double v2 = v1 + satVelocityRate(v1, s);

        Vector<Double> newX = new Vector<Double>(4);
        newX.add(x2);
        newX.add(y2);
        newX.add(th2);
        newX.add(v2);
        return newX;
    }

    private double satTurnRate(double v1, double phi) {
        double bound = Spec.getMaxBodyTurnRate(v1);

        // saturated -bound ~ +bound
        return Math.max(-bound, Math.min(bound, phi));
    }

    private double satVelocityRate(double v1, double s) {
        double dv = s - v1;
        double bound;
        if (Math.abs(v1) < Math.abs(s)) // ENaccl
            bound = Spec.ENACCL_BODY_SPEED;
        else
            bound = Spec.DEACCL_BODY_SPEED; // DEaccl

        // saturated -bound ~ +bound
        return Math.max(-bound, Math.min(bound, dv));
    }

    public Vector<Double> evalOutput(int step, Vector<Double> x, Vector<Double> u) {
        return x;
    }

}
