/*
 * Created on 2007. 06. 07
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.math;

/**
 * Discrete State Equation Solver
 */
public class Solver {

    public Trajectory solve(StateEquations f, int nStep) {
        return null;
    }

}
