/*
 * Created on 2006. 05. 30
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.motion;

import wz.Arena;
import wz.DoublePair;
import wz.LovePoint;
import wz.MotionEvaluator;
import wz.RoboHistory;
import wz.RoboTraits;
import wz.Spec;

public class EnemyAvoidanceMotion implements Motion {

    // private static EnemyAvoidanceMotion instance;

    // private LovePoint self;
    private final double fieldHeight;
    private final double fieldWidth;
    // private final Motion randomMotion;

    private final Motion[] regionalMotions;
    private final DoublePair[] regionalCenter;

    private LovePoint self;

    // public synchronized static EnemyAvoidanceMotion getInstance(LovePoint self) {
    // if (instance == null)
    // instance = new EnemyAvoidanceMotion(self);
    // return instance;
    // }

    public EnemyAvoidanceMotion(LovePoint self) {
        this.self = self;

        this.fieldWidth = self.getBattleFieldWidth();
        this.fieldHeight = self.getBattleFieldHeight();

        // this.randomMotion = new RandomMotion(fieldWidth, fieldHeight);

        regionalMotions = new RegionalRandomMotion[16];
        regionalCenter = new DoublePair[16];

        int i = 0;
        final double dW = self.getBattleFieldWidth() / 4;
        final double dH = self.getBattleFieldHeight() / 4;
        for (int x = 0; x < 4; ++x)
            for (int y = 0; y < 4; ++y) {
                regionalMotions[i] = new RegionalRandomMotion(dH * y, dH * y + dH, dW * x, dW * x + dW);
                regionalCenter[i] = new DoublePair((dH * x) + (dH / 2), (dH * y) + (dH / 2));
                ++i;
            }
    }

    public double evalHeading(double time) {
        return -1;
    }

    private DoublePair evalGoodRegionIndexAndValue() {
        double maxValue = 0; // magic big number
        int maxIndex = 0;

        for (int i = 0, len = regionalCenter.length; i < len; ++i) {
            // DoublePair result = analyzeEnemyAngles(regionalCenter[i]);
            DoublePair result = analyzeEnemyDists(regionalCenter[i]);
            double value = result.v1;
            // self.out.println(i + " " + result);
            if (value > maxValue) {
                maxValue = value;
                maxIndex = i;
            }
        }

        // self.out.println(maxValue + " " + maxIndex);
        return new DoublePair(maxIndex, maxValue);
    }

    private DoublePair analyzeEnemyDists(DoublePair refPos) {
        Arena arena = self.getArena();
        RoboHistory[] hists = arena.getOthers();
        double sumDists = 0;
        double sumDistsPow = 0;
        double length = 0;

        for (int i = 0, len = hists.length; i < len; ++i) {
            RoboTraits traits = hists[i].getRecent();
            if (traits != null) {
                double dist = MotionEvaluator.evalDist(refPos, traits.xy);
                sumDists += dist;
                sumDistsPow += dist * dist;
                ++length;
            }
        }

        double mean = sumDists / length;
        double variance = (sumDistsPow / length) - (mean * mean); // var(X) = E(X^2)-(E(X)^2)
        return new DoublePair(mean, Math.sqrt(variance));
    }

    // /**
    // * @return mean, variance
    // */
    // private DoublePair analyzeEnemyAngles(DoublePair refPos) {
    // Arena arena = self.getArena();
    // RoboHistory[] hists = arena.getOthers();
    // double sumHeading = 0;
    // double sumHeading2 = 0;
    //
    // double refX = refPos.v1;
    // double refY = refPos.v2;
    // for (int i = 0, len = hists.length; i < len; ++i) {
    // RoboTraits traits = hists[i].getRecent();
    // double heading = Tool.rectToPolar(traits.x, traits.y, refX, refY).v2;
    // sumHeading += heading;
    // sumHeading2 += heading * heading;
    // }
    //
    // double mean = sumHeading / hists.length;
    // double variance = (sumHeading2 / hists.length) - (mean * mean); // var(X) = E(X^2)-(E(X)^2)
    // DoublePair result = new DoublePair(mean, variance);
    // // self.out.println(result);
    // return result;
    //
    // }

    // private int prevIndex = 0;
    // private double prevValue = 0;
    // private static double thrsNewIndexDValue = Spec.BODY_RADIUS;

    public DoublePair evalXY(double time) {
        DoublePair result = evalGoodRegionIndexAndValue();
        int index = (int) result.v1;
        // double value = result.v2;

        // if (prevIndex != index) {
        // if (Math.abs(prevValue - value) > thrsNewIndexDValue) {
        // prevIndex = index;
        // prevValue = value;
        // } else {
        // self.out.println(index +" "+ prevIndex);
        // index = prevIndex;
        // }
        // } else
        // prevValue = value;

        Motion regionalMotion = regionalMotions[index];
        DoublePair dest;
        while (true) {
            dest = regionalMotion.evalXY(time);
            if (!isOutOfWalls(dest))
                break;
        }
        return dest;

        // TODO ȸ�� ������
        // TODO ���� ���ϰ� �ָ�... �������� ū �� �ϼ���!
        // TODO ���ݰ� ���� ������ ��ġ�� - ���� �����ϱ�: �ٸ� ��� �κ��� ���� ���� ������ ��ĵ�� �� �ִ� �������� �̵�

        // DoublePair enemyAngle = analyzeEnemyAngles(self.getXY());
        // DoublePair dest = Tool.polarToRect(30, enemyAngle.v1 + Math.PI, self.getX(), self.getY());
        // if (isOutOfWalls(dest))
        // return randomMotion.eval(time);
        // else
        // return dest;

        // new RegionalRandomMotion(30, 300, 30, 300);//

        // �ӽ÷�...
        // return randomMotion.eval(time);

        // try {
        // RoboHistory[] hists = self.getArena().evalAdjacentEnemies(self.getName());
        // for (int i = 0, len = hists.length; i < len; ++i) {
        // if (hists[i].get(0).time - hists[i].get(1).time > 1)
        // return randomMotion.eval(time);
        // }
        // return self.getXY();
        //
        // } catch (Exception e) {
        // return randomMotion.eval(time);
        // }
    }

    public boolean isOutOfWalls(DoublePair xy) {
        if (xy.v1 < Spec.BODY_RADIUS * 2.2)
            return true;
        else if (xy.v1 > fieldWidth - Spec.BODY_RADIUS * 2.2)
            return true;
        else if (xy.v2 < Spec.BODY_RADIUS * 2.2)
            return true;
        else if (xy.v2 > fieldHeight - Spec.BODY_RADIUS * 2.2)
            return true;

        return false;
    }

    // private static DoublePair evalBasicPosition(double fieldWidth, double fieldHeight, double proportion, double theta, DoublePair refXY) {
    // double ny = (theta > Math.PI / 2 && theta < Math.PI * 3 / 2) ? 0 : fieldHeight; // �Ʒ��� ���� ��, ���� ���� ��
    // double dy = ny - refXY.v2;
    // double dx = dy * Math.tan(theta);
    // double nx = refXY.v1 + dx;
    //
    // if (nx < 0) {
    // ny -= nx / Math.tan(theta);
    // nx = 0;
    // } else if (nx > fieldWidth) {
    // ny -= (nx - fieldWidth) / Math.tan(theta);
    // nx = fieldWidth;
    // }
    //
    // double r = MotionEvaluator.evalDist(new DoublePair(nx, ny), refXY);
    // return Tool.polarToRect(r * proportion, theta, refXY.v1, refXY.v2);
    // }
    //
    // public static void main(String[] args) {
    //
    // final JFrame f = new JFrame("Test");
    //
    // final WindowListener wa = new WindowAdapter() {
    // public void windowClosing(WindowEvent e) {
    // super.windowClosing(e);
    // System.out.println(e);
    // System.exit(0);
    // }
    // };
    //
    // f.addWindowListener(wa);
    //
    // final JComponent c = new JComponent() {
    //
    // protected void paintComponent(Graphics g) {
    // g.setColor(getBackground());
    // g.fillRect(0, 0, getWidth(), getHeight());
    //
    // g.setColor(Color.black);
    //
    // for (int i = 0; i < 360; i += 5) {
    // double theta = i * Math.PI / 180;
    // DoublePair dest = evalBasicPosition(800, 600, 0.7, theta, new DoublePair(100, 100));
    // System.out.println(i + " " + dest);
    // g.drawString(String.valueOf(i), (int) dest.v1, getHeight() - (int) dest.v2);
    //
    // }
    //
    // }
    // };
    //
    // f.add(c);
    // f.setSize(800, 600);
    // f.setVisible(true);
    //
    // }
}
