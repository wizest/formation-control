/*
 * Created on 2006. 05. 24
 */
package wz.motion;

import wz.DoublePair;
import wz.RoboHistory;
import wz.RoboTraits;
import wz.Tool;

public class RealMotion implements Motion {

    private RoboHistory hist;

    public RealMotion(RoboHistory hist) {
        this.hist = hist;
    }

    public DoublePair evalXY(double time) {
        RoboTraits t = hist.getNearTime(time);
        return t.xy;

    }

    public double evalHeading(double time) {
        RoboTraits t = hist.getNearTime(time);
        return Tool.toPrincipleRad(t.heading);
    }
}
