/*
 * Created on 2006. 05. 10
 */
package wz.motion;

import wz.DoublePair;
import wz.Tool;
import wz.Spec;

public class BulletMotion implements Motion {

    public final double fireTime;
    public final double velocity;
    public final double heading;
    private final double initX;
    private final double initY;
    public final DoublePair initXY;
    public final double power;
    public final double expectedHitTime;
    public final DoublePair hitPolarPosPair; // ������ initX, initY���� �� polar coord�� �� hit position

    public BulletMotion(double x, double y, double heading, double power, double fireTime, double expectedHitTime, DoublePair hitPolarPosPair) {
        this.fireTime = fireTime;
        this.heading = heading;
        this.initX = x;
        this.initY = y;
        this.velocity = Spec.getBulletSpeed(power);
        this.initXY = new DoublePair(initX, initY);
        this.power = power;
        this.expectedHitTime = expectedHitTime;
        this.hitPolarPosPair = hitPolarPosPair;
    }

    public DoublePair evalXY(double time) {
        double diff = time - this.fireTime;
        return Tool.polarToRect(this.velocity * diff, this.heading, this.initX, this.initY);
    }

    public DoublePair evalByDist(double dist) {
        // dist��ŭ �ʱ�ġ���� �������� ��� ��� ������..
        return Tool.polarToRect(dist, this.heading, this.initX, this.initY);
    }

    public String toString() {
        return "{fireTime=" + fireTime + ",velocity=" + velocity + ",heading=" + heading + ",power=" + power + ",initXY=" + initXY + ",expectedHitTime=" + expectedHitTime + ",hitPolarPosPair=" + hitPolarPosPair + "}";
    }

    public double evalHeading(double time) {
        return Tool.toPrincipleRad(heading);
    }
}
