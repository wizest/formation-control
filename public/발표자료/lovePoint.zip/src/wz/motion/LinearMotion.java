/*
 * Created on 2006. 05. 07
 */
package wz.motion;

import wz.DoublePair;
import wz.Tool;
import wz.RoboTraits;
import wz.Spec;

public class LinearMotion implements Motion {
    private final double fieldWidth;

    private final double fieldHeight;

    private double fromTime;

    private double velocity;

    private double heading;

    private double x;

    private double y;

    public LinearMotion(RoboTraits p, double fieldWidth, double fieldHeight) {
        this(p.x, p.y, p.heading, p.velocity, p.time, fieldWidth, fieldHeight);
    }

    public LinearMotion(double x, double y, double heading, double velocity, double fromTime, double fieldWidth, double fieldHeight) {
        this.fromTime = fromTime;
        this.velocity = velocity;
        this.heading = heading;
        this.x = x;
        this.y = y;
        this.fieldHeight = fieldHeight;
        this.fieldWidth = fieldWidth;
    }

    public LinearMotion(RoboTraits p) {
        this(p.x, p.y, p.heading, p.velocity, p.time, 0xFFF, 0xFFF);
    }

    public DoublePair evalXY(double time) {
        double diff = time - fromTime;
        DoublePair pair = Tool.polarToRect(velocity * diff, heading, x, y);

        if (diff > 0)
            if (testInField(pair))
                return pair;
            else {
                do {
                    --diff;
                    pair = Tool.polarToRect(velocity * diff, heading, x, y);
                    if (testInField(pair))
                        return pair;
                } while (diff > 0);
                return new DoublePair(x, y);
            }
        else
            return pair;
    }

    private boolean testInField(DoublePair pair) {
        // �� �ܺο� ��ġ�� ���
        if ((pair.v1 < Spec.BODY_RADIUS) || (pair.v1 > fieldWidth - Spec.BODY_RADIUS) || (pair.v2 < Spec.BODY_RADIUS) || (pair.v2 > fieldHeight - Spec.BODY_RADIUS))
            return false;
        else
            return true;
    }

    public double evalHeading(double time) {
        return Tool.toPrincipleRad(heading);
    }

}
