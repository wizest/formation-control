/*
 * Created on 2007. 07. 19
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.motion;

import wz.DoublePair;
import wz.LovePoint;

public class StopMotion implements Motion {

    private LovePoint self;

    public StopMotion(LovePoint self) {
        this.self = self;
    }

    public double evalHeading(double time) {
        return self.getHeadingRadians();
    }

    public DoublePair evalXY(double time) {
        return self.getXY();
    }

}
