/*
 * Created on 2006. 05. 07
 */
package wz.motion;

import wz.DoublePair;

public interface Motion {
    /**
     * @param time
     * @return heading at time, �����̸� �ǹ� ����. 0~2pi �� �� (principle rad)
     */
    double evalHeading(double time);

    /**
     * @param time
     * @return ��ǥ at time
     */
    DoublePair evalXY(double time);
}
