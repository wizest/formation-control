/*
 * Created on 2006. 05. 08
 */
package wz.motion;

import java.util.ArrayList;
import java.util.Iterator;

import wz.DoublePair;
import wz.Tool;
import wz.RoboHistory;
import wz.RoboTraits;
import wz.Spec;
import wz.deprecated.LinearRegression;
import wz.deprecated.NoRegressionException;

public class TrackMotion implements Motion {
    private final double fieldWidth;

    private final double fieldHeight;

    private Polynomial velocity;

    private Polynomial heading;

    private RoboTraits traits;

    public TrackMotion(RoboTraits current, Polynomial heading, Polynomial velocity, double fieldWidth, double fieldHeight) {
        this.traits = current;
        this.heading = heading;
        this.velocity = velocity;
        this.fieldHeight = fieldHeight;
        this.fieldWidth = fieldWidth;
    }

    public double evalHeading(double time) {
        if (traits.time < time) {
            RoboTraits current = traits;
            for (;;) {
                current = afterOneTick(current);
                if (current.time >= time)
                    break;
            }
            return Tool.toPrincipleRad(current.heading);
        } else if (traits.time == time)
            return Tool.toPrincipleRad(traits.heading);
        else {
            RoboTraits current = traits;
            for (;;) {
                current = beforeOneTick(current);
                if (current.time <= time)
                    break;
            }
            return Tool.toPrincipleRad(current.heading);
        }
    }

    public DoublePair evalXY(double time) {
        if (traits.time < time) {
            RoboTraits current = traits;
            for (;;) {
                current = afterOneTick(current);
                if (current.time >= time)
                    break;
            }
            return current.xy;
        } else if (traits.time == time)
            return traits.xy;
        else {
            RoboTraits current = traits;
            for (;;) {
                current = beforeOneTick(current);
                if (current.time <= time)
                    break;
            }
            return current.xy;
        }
    }

    private RoboTraits afterOneTick(RoboTraits current) {
        DoublePair pair = Tool.polarToRect(current.velocity * 1, current.heading, current.x, current.y);
        long nextTime = current.time + 1;

        double v = velocity.eval(nextTime);
        if (current.velocity >= 0) {
            if (current.velocity > v) {
                if (current.velocity - v > Spec.DEACCL_BODY_SPEED)
                    v = current.velocity - Spec.DEACCL_BODY_SPEED;
            } else if (v - current.velocity > Spec.ENACCL_BODY_SPEED)
                v = current.velocity + Spec.ENACCL_BODY_SPEED;
        } else {
            if (current.velocity > v) {
                if (current.velocity - v > Spec.ENACCL_BODY_SPEED)
                    v = current.velocity - Spec.ENACCL_BODY_SPEED;
            } else if (v - current.velocity > Spec.DEACCL_BODY_SPEED)
                v = current.velocity + Spec.DEACCL_BODY_SPEED;
        }

        v = Math.max(Math.min(v, Spec.MAX_BODY_SPEED), -Spec.MAX_BODY_SPEED);

        double maxTurn = Spec.getMaxBodyTurnRate(current.velocity);
        double h = heading.eval(nextTime);
        if (current.heading > h) {
            if (current.heading - h > maxTurn)
                h = current.heading - maxTurn;
        } else if (h - current.heading > maxTurn)
            h = current.heading + maxTurn;

        double e = current.energy;
        // �� �ܺο� ��ġ�� ���
        if (pair.v1 < Spec.BODY_RADIUS) {
            pair = new DoublePair(Spec.BODY_RADIUS, pair.v2);
            e = Math.max(0, e - Spec.getWallDamage(v));
            v = 0;
        } else if (pair.v1 > fieldWidth - Spec.BODY_RADIUS) {
            pair = new DoublePair(fieldWidth - Spec.BODY_RADIUS, pair.v2);
            e = Math.max(0, e - Spec.getWallDamage(v));
            v = 0;
        }
        if (pair.v2 < Spec.BODY_RADIUS) {
            pair = new DoublePair(pair.v1, Spec.BODY_RADIUS);
            e = Math.max(0, e - Spec.getWallDamage(v));
            v = 0;
        } else if (pair.v2 > fieldHeight - Spec.BODY_RADIUS) {
            pair = new DoublePair(pair.v1, fieldHeight - Spec.BODY_RADIUS);
            e = Math.max(0, e - Spec.getWallDamage(v));
            v = 0;
        }
        return new RoboTraits(pair.v1, pair.v2, h, v, e, nextTime);
    }

    /**
     * ���ŷ� ���� ���� �� ���� �����Ƿ� ���� ��.��''
     * 
     * @param current
     * @return
     */
    private RoboTraits beforeOneTick(RoboTraits current) {
        DoublePair pair = Tool.polarToRect(-current.velocity * 1, current.heading, current.x, current.y);
        long prevTime = current.time - 1;

        double v = velocity.eval(prevTime);
        // if (current.velocity > v) {
        // if (current.velocity - v > Spec.ENACCL_BODY_SPEED)
        // v = current.velocity - Spec.ENACCL_BODY_SPEED;
        // } else if (v - current.velocity > Spec.DEACCL_BODY_SPEED)
        // v = current.velocity + Spec.DEACCL_BODY_SPEED;
        //        
        v = Math.max(Math.min(v, Spec.MAX_BODY_SPEED), -Spec.MAX_BODY_SPEED);

        double maxTurn = Spec.getMaxBodyTurnRate(current.velocity);
        double h = heading.eval(prevTime);
        if (current.heading > h) {
            if (current.heading - h > maxTurn)
                h = current.heading - maxTurn;
        } else if (h - current.heading > maxTurn)
            h = current.heading + maxTurn;

        return new RoboTraits(pair.v1, pair.v2, h, v, current.energy, prevTime);
    }

    public static Motion createMotion(RoboHistory hist, double fieldWidth, double fieldHeight) {
        // TODO hist���� evaluate �ϱ� ���� ������ position �̴� ���� ���߿� ����
        RoboTraits[] ps = getEvalutionSource(hist);

        int len = ps.length;
        double[] time = new double[len];
        double[] heading = new double[len];
        double[] velocity = new double[len];

        LinearRegression hlr = new LinearRegression();
        LinearRegression vlr = new LinearRegression();
        for (int i = 0; i < len; ++i) {
            RoboTraits p = ps[i];

            hlr.addSample(p.time, p.heading);
            vlr.addSample(p.time, p.velocity);

            time[i] = p.time;
            heading[i] = p.heading;
            velocity[i] = p.velocity;
        }

        //        
        // double[] hCoeff = MotionEvaluator.doCurveFitting(time, heading, 1);
        // // order
        // double[] vCoeff = MotionEvaluator.doCurveFitting(time, velocity, 1);
        // // order

        try {
            double[] hCoeff = hlr.getCoeffs();
            double[] vCoeff = vlr.getCoeffs();

            if (hCoeff == null || vCoeff == null) {
                // System.out.println("alternative motion");
                return new LinearMotion(ps[0], fieldWidth, fieldHeight);
                // return new AcclMotion(ps[0], hist.isAccelerating(),
                // fieldWidth, fieldHeight);
            }

            return new TrackMotion(ps[0], new Polynomial(hCoeff), new Polynomial(vCoeff), fieldWidth, fieldHeight);
        } catch (NoRegressionException e) {
            return new LinearMotion(ps[0], fieldWidth, fieldHeight);
            // return new AcclMotion(ps[0], hist.isAccelerating(),
            // fieldWidth, fieldHeight);

        }
    }

    private static RoboTraits[] getEvalutionSource(RoboHistory hist) {
        ArrayList<RoboTraits> l = new ArrayList<RoboTraits>(100);
        Iterator<RoboTraits> i = hist.getRecentOrderIterator();

        RoboTraits current = i.next();
        l.add(current);
        while (i.hasNext()) {
            RoboTraits p = i.next();
            l.add(p);
            if (p.velocity == 0 || p.time < current.time - 10) // 15 magic
                break;
        }

        return l.toArray(new RoboTraits[0]);
    }

}

class Polynomial {

    private double[] coeff;

    public Polynomial(double[] coeff) {
        this.coeff = coeff;
    }

    public double[] getCoeffs() {
        return coeff;
    }

    public double eval(double time) {
        double sum = 0;
        for (int i = 0, len = coeff.length; i < len; ++i)
            sum += coeff[i] * Math.pow(time, i);
        return sum;
    }
}
