/*
 * Created on 2006. 05. 23
 */
package wz.motion;

import java.util.Random;

import wz.DoublePair;
import wz.Spec;
import wz.Tool;

public class RandomMotion implements Motion {

    private static Random rand = Tool.rand;

    private double[] left;
    private double[] right;
    private double[] top;
    private double[] bottom;

    public RandomMotion(double battleWidth, double battleHeight) {
        left = new double[] { Spec.BODY_RADIUS, Spec.BODY_RADIUS, Spec.BODY_RADIUS, battleWidth / 2 };
        right = new double[] { battleWidth - Spec.BODY_RADIUS, battleWidth / 2, battleWidth - Spec.BODY_RADIUS, battleWidth - Spec.BODY_RADIUS };
        top = new double[] { battleHeight - Spec.BODY_RADIUS, battleHeight - Spec.BODY_RADIUS, battleHeight / 2, battleHeight - Spec.BODY_RADIUS };
        bottom = new double[] { battleHeight / 2, Spec.BODY_RADIUS, Spec.BODY_RADIUS, Spec.BODY_RADIUS };
    }

    private static final int CALL_THRS = 18; // ex) 20�� �ݸ��� �ѹ��� ��ġ�� �ٲ�� �ȴ�.
    private static final int REGIONAL_THRS = 12; // ex) CALL_THRS * 5�� ���� ������ ����
    private int cnt = 0;
    private int rcnt = 0;
    private DoublePair prev;
    private int region; // 0:top, 1:left, 2:bottom, 3:right

    public DoublePair evalXY(double time) {
        if (cnt == 0) {
            if (rcnt == 0) {
                region = rand.nextInt(4);
                rcnt = REGIONAL_THRS;
                // System.out.println(region);
            } else
                --rcnt;

            double x = left[region] + (right[region] - left[region]) * rand.nextDouble();
            double y = bottom[region] + (top[region] - bottom[region]) * rand.nextDouble();
            cnt = CALL_THRS;
            prev = new DoublePair(x, y);
            return prev;
        } else {
            --cnt;
            return prev;
        }
    }

    public double evalHeading(double time) {
        return -1;
    }
    
}
