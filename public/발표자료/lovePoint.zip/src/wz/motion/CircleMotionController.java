/*
 * Created on 2007. 07. 19
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.motion;

import wz.DoublePair;
import wz.LovePoint;

public class CircleMotionController implements MotionController {

    public DoublePair getControlVandW(LovePoint self) {
        return new DoublePair(100,1);
    }

}
