/*
 * Created on 2007. 07. 19
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.motion;

import wz.DoublePair;
import wz.LovePoint;
import wz.Spec;
import wz.Tool;

public class TrackingController implements MotionController {

    private Motion ref;

    public TrackingController(Motion ref) {
        this.ref = ref;
    }

    private Motion selectReferenceMotion() {
        return ref;
    }

    /*
     * return next control
     */
    protected DoublePair onMotionConverged() {
        return new DoublePair(0, 0);
    }

    public DoublePair getControlVandW(LovePoint self) {
        Motion ref = selectReferenceMotion();

        if (ref == null)
            return new DoublePair(0, 0);
        else {
            // TODO �ٽ� �����

            // 1st iteration
            DoublePair dest = ref.evalXY(self.getTime() + 1);
            DoublePair polar = Tool.rectToPolar(dest.v1, dest.v2, self.getX(), self.getY());
            double turn = Tool.toRelRad(polar.v2, self.getHeadingRadians());
            double dist = polar.v1 * Math.cos(turn);

            // 2nd iteration
            dest = ref.evalXY(self.getTime() + dist / (.5 * (Math.abs(self.getVelocity()) + Spec.MAX_BODY_SPEED)));
            polar = Tool.rectToPolar(dest.v1, dest.v2, self.getX(), self.getY());
            turn = Tool.toRelRad(polar.v2, self.getHeadingRadians());
            dist = polar.v1 * Math.cos(turn);

            // backward
            if (dist < 0)
                if (turn > 0)
                    turn = turn - 2 * Math.PI;
                else
                    turn = 2 * Math.PI + turn;

            // bound
            // dist = Math.min(Spec.MAX_BODY_SPEED , Math.max(-Spec.MAX_BODY_SPEED , dist));
            double maxTurn = Spec.getMaxBodyTurnRate(self.getVelocity());
            turn = Math.min(maxTurn, Math.max(-maxTurn, turn));

            if (dist != 0) {
                if (Math.abs(dist) < Spec.BODY_RADIUS / 4)
                    return onMotionConverged();
                else
                    return new DoublePair(dist, turn);
            } else
                return onMotionConverged();
        }
    }
}
