/*
 * Created on 2006. 06. 23
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.motion;

import java.util.Random;

import wz.DoublePair;
import wz.Tool;

public class RegionalRandomMotion implements Motion {
    private static Random rand = Tool.rand;// new Random(System.currentTimeMillis());

    private double bottom;
    private double left;
    private double width;
    private double height;

    private DoublePair current;
    private int thrsNew = 0;

    public RegionalRandomMotion(double bottom, double top, double left, double right) {
        this.bottom = bottom;
        this.left = left;

        this.width = Math.abs(right - left);
        this.height = Math.abs(top - bottom);
    }

    public DoublePair evalXY(double time) {
        if (thrsNew == 0) {
            current = new DoublePair(left + rand.nextDouble() * width, bottom + rand.nextDouble() * height);
            thrsNew = 11 + rand.nextInt(10); // 60�� call�� �ѹ��� ����

        } else
            --thrsNew;
        return current;
    }

    public double evalHeading(double time) {
        return -1;
    }
}
