/*
 * Created on 2006. 05. 22
 */
package wz.motion;

import wz.DoublePair;

public class StuckMotion implements Motion {

    private DoublePair dest;

    public StuckMotion(DoublePair dest) {
        this.dest = dest;
    }

    public DoublePair evalXY(double time) {
        return dest;
    }

    public double evalHeading(double time) {
        return -1;
    }



}
