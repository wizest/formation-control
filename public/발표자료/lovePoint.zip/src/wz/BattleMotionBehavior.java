/*
 * Created on 2006. 05. 28
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import wz.motion.BulletMotion;
import wz.motion.EnemyAvoidanceMotion;
import wz.motion.Motion;
import wz.motion.MotionController;
import wz.motion.RandomMotion;
import wz.motion.StopMotion;
import wz.motion.StuckMotion;
import wz.motion.TrackingController;

public class BattleMotionBehavior extends MotionBehavior implements MotionController {
    private final LinkedList<BulletMotion> criticalBullets;
    private final double fieldWidth;
    private final double fieldHeight;

    private MotionController fundamentalMc;
// private MotionController circleMc;

    private BattleMotion fundamentalMotion;

    private MotionEvaluator predictor;

    private double controlW;
    private double controlV;
    private double controlT;

    public BattleMotionBehavior(LovePoint self) {
        super(self);
        this.criticalBullets = new LinkedList<BulletMotion>();
        this.fieldWidth = self.getBattleFieldWidth();
        this.fieldHeight = self.getBattleFieldHeight();

        this.predictor = new MotionEvaluator(self.getBattleFieldWidth(), self.getBattleFieldHeight());

        this.fundamentalMotion = new BattleMotion();
        this.fundamentalMc = new TrackingController(fundamentalMotion) {
//            @Override
//            protected DoublePair onMotionConverged() {
//            // ���� ���� ��������
//             double heading = evalHeadingForEnemies();
//             double h1 = Tool.toRelRad(heading - Math.PI / 2, self.getHeadingRadians());
//             double h2 = Tool.toRelRad(heading + Math.PI / 2, self.getHeadingRadians());
//             self.setTurnRightRadians(Math.abs(h1) < Math.abs(h2) ? h1 : h2);
//             
//            }
        };
// this.circleMc = new CircleMotionController();

        this.controlV = 100;
        this.controlW = 1;
        this.controlT = 30;
    }

    @Override
    public void onHitWall(HitWallEvent e) {
        super.onHitWall(e);
// controlW*=-1;
        controlV *= -1;
    }

    @Override
    public void onHitRobot(HitRobotEvent e) {
        super.onHitRobot(e);
        controlW *= -1;
        controlV *= -1;

    }

    public void onHitByBullet(HitByBulletEvent e) {
        controlW *= -1;
        self.getArena().incHitScoreBy(e.getName());
    }

    public synchronized void onBulletFired(String enemyName, BulletMotion bulletMotion) {
        // remove old bullets (5 sec)
        long now = self.getTime();
        try {
            for (int i = 0, len = criticalBullets.size(); i < len; ++len) {
                BulletMotion bm = criticalBullets.removeFirst();
                if (((double) now - bm.fireTime) <= 150) {// 150frame(5��) ���� ���� ������.
                    criticalBullets.addFirst(bm);
                    break;
                }
            }
        } catch (NoSuchElementException e) {}
        criticalBullets.addLast(bulletMotion);

        self.getArena().decHitScoreBy(enemyName);
    }

    public boolean isOutOfWalls(DoublePair xy) {
        if (xy.v1 < Spec.BODY_RADIUS * 2)
            return true;
        else if (xy.v1 > fieldWidth - Spec.BODY_RADIUS * 2)
            return true;
        else if (xy.v2 < Spec.BODY_RADIUS * 2)
            return true;
        else if (xy.v2 > fieldHeight - Spec.BODY_RADIUS * 2)
            return true;

        return false;
    }

    @Override
    protected MotionController selectMotionController() {
        return this;
    }

    public DoublePair getControlVandW(LovePoint self) {
        Motion m = fundamentalMotion.updateMotion();
//        if (m instanceof StopMotion) {
//            if (self.getTime() % controlT == 0) {
//                controlV = 100 * Math.signum((Tool.rand.nextDouble() - .5));
//                controlW = Math.PI / 2 * (Tool.rand.nextDouble() - .5);
//                controlT = 30 + Tool.rand.nextInt(30);
//            }
//
//        // if (isOutOfWalls(self.getXY())) {
//        // controlW *= -1;
//        // }
//
//            return new DoublePair(controlV, controlW);
//        } else
            return fundamentalMc.getControlVandW(self);
    }

    class BattleMotion implements Motion {
        private Motion battleMotion;
// private Motion spiralMotion;

        private Motion m;
        private StopMotion stopMotion;

        public BattleMotion() {

            this.battleMotion = new EnemyAvoidanceMotion(self);// EnemyAvoidanceMotion.getInstance(self);
            this.stopMotion = new StopMotion(self);
// this.spiralMotion = new SpiralMotion(self);
        }

        public synchronized Motion updateMotion() {
            Motion motion = makeHitAvoidanceMotion();

            if (motion == null)
                motion = makeRamAttackMotion();

            if (motion == null)
                if (self.getOthers() == 1)
// motion = randomMotion
// motion = spiralMotion;
                    motion = stopMotion;
                else
                    motion = battleMotion;

            // for Avoidance Motion Test
            // motion = new StuckMotion(self.getXY());
// motion = spiralMotion;
// motion = stopMotion;
            return this.m = motion;

        }

        public synchronized double evalHeading(double time) {
            return m.evalHeading(time);
        }

        public synchronized DoublePair evalXY(double time) {
            return m.evalXY(time);
        }

        private synchronized Motion makeHitAvoidanceMotion() {
            Motion motion = null;

            // e.g)
            // ��ź�� ���Ϸ��� 20pix������ ������ �־���Ѵ�.
            // ��ź�� �ӵ��� �ִ� 20 pix/frame ��� �ϰ�
            // ��ũ�� �ӵ��� �� 4 pix/frame ��� ������ ��
            // ��ź�� ���ϱ� ���� �ּ� 5 frame�� �ʿ��ϴ�.
            // �̶� ��ź�� �̵��ӵ��� 100 pix �̹Ƿ�
            // ��� ������ ���ϴ� �ݰ� 100 pix �̳��� ��ź�� �����ϰ� ��� ȸ���ؾ��Ѵ�.
            double hitAfterFrames = 0xFFF; // magic - large number
            DoublePair selfXY = self.getXY();
            DoublePair bulletXY;
            Iterator<BulletMotion> itr = criticalBullets.iterator();
            while (itr.hasNext()) {
                BulletMotion bm = itr.next();
                bulletXY = bm.evalXY(self.getTime() + 1);

                double thresAvoidDist = bm.velocity * 10.11; // 10.11 11.11 frame, 40.1/r rad�� ����
                double thresAvoidAngleConst = 41.17;// 43.22;// 40.1;
                double distSelfToBullet = MotionEvaluator.evalDist(selfXY, bulletXY);
                if ((distSelfToBullet / bm.velocity < hitAfterFrames) // �� ���� �����ұ�? - ����: ���� ���� ������ ��ź 1���� ȸ��
                        && (distSelfToBullet <= thresAvoidDist) // ȸ�� �����ΰ�?
                        && (MotionEvaluator.evalDist(selfXY, bm.initXY) > MotionEvaluator.evalDist(bulletXY, bm.initXY))) // ������ ��ź�ΰ�?
                {
                    hitAfterFrames = distSelfToBullet / bm.velocity;

                    double relH = Tool.toRelRad(Tool.rectToPolar(selfXY.v1, selfXY.v2, bm.initXY.v1, bm.initXY.v2).v2, bm.heading);
                    double r = Math.max(thresAvoidDist + Spec.BODY_RADIUS * 2, MotionEvaluator.evalDist(selfXY, bm.initXY)); // thresAoidDist���� ū �ݰ����� - �ʹ� ������ �ʰ�
                    double theta = bm.heading + (relH > 0 ? thresAvoidAngleConst / r : -thresAvoidAngleConst / r);

                    DoublePair dest = Tool.polarToRect(r, theta, bm.initXY.v1, bm.initXY.v2);

                    if (MotionEvaluator.evalDist(selfXY, bm.evalByDist(MotionEvaluator.evalDist(bm.initXY, selfXY))) > (r * theta + Spec.MAX_BODY_SPEED))
                        motion = null; // ȸ�� ������ �ƴ�
                    else if (isOutOfWalls(dest)) {
                        // ���� �ݴ�������
                        theta = bm.heading - (relH > 0 ? thresAvoidAngleConst / r : -thresAvoidAngleConst / r);
                        dest = Tool.polarToRect(r, theta, bm.initXY.v1, bm.initXY.v2);

                        // �׷��� �� ���̸� randomMotion
                        if (isOutOfWalls(dest))
                            motion = new RandomMotion(self.getBattleFieldWidth(), self.getBattleFieldHeight());

                        else
                            motion = new StuckMotion(dest);
                    } else
                        motion = new StuckMotion(dest);
                }
            }

            return motion;
        }

        private Motion makeRamAttackMotion() {
            Arena arena = self.getArena();
            RoboHistory[] hists = arena.evalAdjacentEnemies(self.getName());

            for (int i = 0, len = hists.length; i < len; ++i) {
                RoboHistory hist = hists[i];
                if (hist.getRecent().energy < Spec.RAM_DAMAGE && self.getEnergy() > Spec.RAM_DAMAGE // energy condition
                        && arena.isMostAdjacent(hist.name, self.getName())) {// distance condition

                    return predictor.predict(arena, hist.name);
                }
            }

            return null;
        }

    }

}
