/*
 * Created on 2006. 06. 24
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz;

import java.io.Serializable;

import robocode.Bullet;
import wz.motion.BulletMotion;

public class BulletTraits implements Serializable {
    public final double fireTime;
    public final Bullet bullet;
    public final BulletMotion bulletMotion;

    public PredictionFeature _predictionFeature; // for cache

    public BulletTraits(double fireTime, Bullet bullet, BulletMotion bulletMotion) {
        this.fireTime = fireTime;
        this.bullet = bullet;
        this.bulletMotion = bulletMotion;
    }

    public String toString() {
        return "{time=" + fireTime + ", bullet=" + bullet + ", bulletMotion=" + bulletMotion + ", predictionFeature=" + _predictionFeature + "}";
    }
}

/*
 * Created on 2006. 06. 24
 * 
 * Kim,Sanghoon (wizest@gmail.com) http://blog.naver.com/wizest
 */

class PredictionFeature {
    public final double dTime;
    public final double initRelRad; // ��ź ��� �κ��� ������� ����
    public final double initVelocity;
    public final DoublePair dPolarPos;
    public final double power;
    public final double hitDist;

    public PredictionFeature(double dTime, DoublePair dPolarPos, double initRelRad, double initVelocity, double power, double hitDist) {
        this.dTime = dTime;
        this.initRelRad = initRelRad;
        this.initVelocity = initVelocity;
        this.dPolarPos = dPolarPos;
        this.power = power;
        this.hitDist = hitDist;
    }

    public String toString() {
        return "{dTime=" + dTime + ",dPolarPos=" + dPolarPos + ",initRelRad=" + initRelRad + ",initVelocity=" + initVelocity + ",power=" + power + ",hitDist=" + hitDist + "}";
    }
}
