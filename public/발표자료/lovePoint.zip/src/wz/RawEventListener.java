/*
 * Created on 2006. 5. 3
 */
package wz;

import robocode.BulletHitBulletEvent;
import robocode.BulletHitEvent;
import robocode.BulletMissedEvent;
import robocode.CustomEvent;
import robocode.DeathEvent;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import robocode.MessageEvent;
import robocode.RobotDeathEvent;
import robocode.ScannedRobotEvent;
import robocode.SkippedTurnEvent;
import robocode.WinEvent;

public interface RawEventListener {

    void onCustomEvent(CustomEvent e);

    void onDeath(DeathEvent e);

    void onSkippedTurn(SkippedTurnEvent e);

    void onBulletHit(BulletHitEvent e);

    void onBulletHitBullet(BulletHitBulletEvent e);

    void onBulletMissed(BulletMissedEvent e);

    void onHitByBullet(HitByBulletEvent e);

    void onHitRobot(HitRobotEvent e);

    void onHitWall(HitWallEvent e);

    void onRobotDeath(RobotDeathEvent e);

    void onScannedRobot(ScannedRobotEvent e);

    void onWin(WinEvent e);

    void onMessageReceived(MessageEvent e);

    void onTick();
}
