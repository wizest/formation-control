/*
 * Created on 2006. 06. 25
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.deprecated;

public class MultipleLinearRegression {
    // http://en.wikipedia.org/wiki/Linear_regression

    private double sumX, sumY, sumXY, sumXX, sumYY, n;
    private double sumXZ, sumYZ, sumZ;
    private double coeffA, coeffB, coeffC;
    private boolean dirty;

    public MultipleLinearRegression() {
        sumX = sumY = sumXY = sumXX = sumYY = n = 0;
        sumXZ = sumYZ = sumZ = 0;
        coeffA = coeffB = coeffC = 0;
        dirty = false;
    }

    public synchronized void addSample(double x, double y, double z) {
        sumX += x;
        sumY += y;
        sumXY += x * y;
        sumXX += x * x;
        sumYY += y * y;
        n += 1;

        sumXZ += x * z;
        sumYZ += y * z;
        sumZ += z;

        dirty = true;
    }

    public synchronized double estimateZ(double x, double y) throws NoRegressionException {
        if (dirty)
            reparameter();

        double z = (coeffA * x) + (coeffB * y) + coeffC;
        return z;
    }

    /**
     * coeffA, coeffB, coeffC ���
     */
    private void reparameter() throws NoRegressionException {
        // Inversion of 3 x 3 matrices - http://en.wikipedia.org/wiki/Inverse_matrix
        double a = sumXX, b = sumXY, c = sumX;
        double d = sumXY, e = sumYY, f = sumY;
        double g = sumX, h = sumY, i = n;
        double det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g);
        if (det == 0)
            throw new NoRegressionException("no regression");

        coeffA = (sumXZ * (e * i - f * h) + sumYZ * (c * h - b * i) + sumZ * (b * f - c * e)) / det;
        coeffB = (sumXZ * (f * g - d * i) + sumYZ * (a * i - c * g) + sumZ * (c * d - a * f)) / det;
        coeffC = (sumXZ * (d * h - e * g) + sumYZ * (b * g - a * h) + sumZ * (a * e - b * d)) / det;

        dirty = false;
    }

    // public static void main(String[] args) throws Exception {
    // // test
    // MultipleLinearRegression lr = new MultipleLinearRegression();
    // lr.addSample(1, 11.05, 111);
    // lr.addSample(2, 122.2, 211);
    // lr.addSample(3, 11.01, 3);
    // lr.addSample(4, 20.0, 4);
    // lr.addSample(5, 11.1, 5);
    //
    // System.out.println(lr.estimateZ(1, 1.1));
    // }

}
