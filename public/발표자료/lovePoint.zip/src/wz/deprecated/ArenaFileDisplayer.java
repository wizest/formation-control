/*
 * Created on 2006. 5. 6
 */
package wz.deprecated;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.JFrame;

import wz.Arena;
import wz.DoublePair;
import wz.MotionEvaluator;
import wz.RoboHistory;
import wz.RoboTraits;
import wz.motion.Motion;

public class ArenaFileDisplayer {

    private final static String FN = "D:/research/lovePoint/bin/wz/LovePoint.data/wz.LovePoint.arena";
    private final static String FN2 = "D:/research/lovePoint/bin/wz/LovePoint.data/wz.LovePoint (1).arena";

    public static void main(final String[] args) throws Exception {
        final ArenaFileDisplayer disp = new ArenaFileDisplayer();
        disp.disp();
    }

    MotionEvaluator me = new MotionEvaluator(1000, 800);

    public void showPredictedMotion(Graphics g, Arena arena, String name, int width, int height) {
        // MotionEvaluator mp = new MotionEvaluator(width, height);
        Motion m = me.predict(arena, name);

        RoboHistory hist = arena.get(name);
        double initTime = hist.getRecent().time;
        g.setColor(Color.CYAN);
        for (int k = 0, klen = 30; k < klen; ++k) {
            // DoublePair pair = m.eval(initTime + Math.signum(k) * Math.sqrt(Math.abs(k)));
            DoublePair pair = m.evalXY(initTime + k);
            if (k == 0)
                g.setColor(Color.GREEN);
            if (k > 19)
                g.setColor(Color.RED);
            g.drawString("+", (int) pair.v1, height - (int) pair.v2);
        }

    }

    @SuppressWarnings("unchecked")
    private void disp() throws Exception {

        final JFrame f = new JFrame("Arena");

        final WindowListener wa = new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.out.println(e);
                System.exit(0);
            }
        };

        f.addWindowListener(wa);

        final Vector v = new Vector();
        final JComponent c = new JComponent() {
            private Arena getArena() {
                try {
                    return (Arena) v.get(0);
                } catch (ArrayIndexOutOfBoundsException e) {
                    return null;
                }
            }

            protected void paintComponent(Graphics g) {
                Arena a = getArena();
                if (a != null) {
                    g.setColor(getBackground());
                    g.fillRect(0, 0, getWidth(), getHeight());

                    RoboHistory[] hists = a.getAll();
                    for (int idx = 0, len = hists.length; idx < len; ++idx) {
                        RoboHistory hist = hists[idx];
                        Iterator i = hist.getRecentOrderIterator();

                        RoboTraits prev = (RoboTraits) i.next();
                        g.setColor(Color.BLACK);
                        g.drawString(hist.name, (int) prev.x, getHeight() - (int) prev.y);

                        g.setColor(Color.BLUE);
                        if (prev != null)
                            g.drawString("*", (int) prev.x, getHeight() - (int) prev.y);

                        while (i.hasNext()) {
                            RoboTraits p = (RoboTraits) i.next();

                            g.setColor(Color.MAGENTA);
                            if (prev != null)
                                g.drawLine((int) prev.x, getHeight() - (int) prev.y, (int) p.x, getHeight() - (int) p.y);

                            g.setColor(Color.BLUE);
                            if (p != null)
                                g.drawString("*", (int) p.x, getHeight() - (int) p.y);

                            prev = p;
                        }

                        showPredictedMotion(g, a, hist.name, getWidth(), getHeight());
                    }
                }
            }
        };

        f.add(c);
        f.setSize(800, 600);
        f.setVisible(true);

        Arena a = null;

        while (true) {
            try {
                File f1 = new File(FN);
                File f2 = new File(FN2);
                if (f2.lastModified() > f1.lastModified())
                    f1 = f2;

                final FileInputStream is = new FileInputStream(f1);
                final ObjectInputStream ois = new ObjectInputStream(is);
                final Object o = ois.readObject();
                ois.close();
                if (o != null) {
                    a = (Arena) o;
                    // System.out.println(a);
                    v.removeAllElements();
                    v.add(a);
                    f.repaint();
                }

            } catch (final Exception e) {
                System.err.println(e);
            }

            Thread.sleep(1000 / 5);
        }
    }
}
