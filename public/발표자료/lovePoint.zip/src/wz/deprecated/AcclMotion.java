/*
 * Created on 2006. 05. 24
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.deprecated;

import wz.DoublePair;
import wz.Tool;
import wz.RoboTraits;
import wz.Spec;
import wz.motion.Motion;

public class AcclMotion implements Motion {
    private final double fieldWidth;
    private final double fieldHeight;

    private double fromTime;
    private double velocity;
    private boolean enaccl; // ���� enaccl��?

    private double heading;
    private DoublePair xy;

    public AcclMotion(RoboTraits p, boolean enaccl, double fieldWidth, double fieldHeight) {
        this(p.x, p.y, p.heading, p.velocity, enaccl, p.time, fieldWidth, fieldHeight);
    }

    private AcclMotion(double x, double y, double heading, double velocity, boolean enaccl, double fromTime, double fieldWidth, double fieldHeight) {
        this.fromTime = fromTime;
        this.velocity = velocity;
        this.heading = heading;
        this.xy = new DoublePair(x, y);
        this.fieldHeight = fieldHeight;
        this.fieldWidth = fieldWidth;
        this.enaccl = enaccl;
    }

    public AcclMotion(RoboTraits p, boolean enaccl) {
        this(p.x, p.y, p.heading, p.velocity, enaccl, p.time, 0xFFF, 0xFFF);
    }

    public double evalHeading(double time) {
        return Tool.toPrincipleRad(heading);
    }

    public DoublePair evalXY(double time) {
        double diff = time - fromTime;

        if (Math.abs(velocity) == Spec.MAX_BODY_SPEED) {
            DoublePair pair = Tool.polarToRect(velocity * diff, heading, xy.v1, xy.v2);

            if (diff > 0)
                if (testInField(pair))
                    return pair;
                else {
                    do {
                        --diff;
                        pair = Tool.polarToRect(velocity * diff, heading, xy.v1, xy.v2);
                        if (testInField(pair))
                            return pair;
                    } while (diff > 0);
                    return xy;
                }
            else
                return pair;
        } else {
            double acclT, unifT, dist;
            if (velocity > 0) {
                if (enaccl) {
                    acclT = Math.min(diff, (Spec.MAX_BODY_SPEED - velocity) / Spec.ENACCL_BODY_SPEED);
                    unifT = diff - acclT;
                    dist = velocity * acclT + Spec.ENACCL_BODY_SPEED * acclT * acclT / 2;
                    dist += Spec.MAX_BODY_SPEED * unifT;
                } else {
                    acclT = Math.min(diff, velocity / Spec.DEACCL_BODY_SPEED);
                    unifT = diff - acclT;
                    dist = velocity * acclT - Spec.DEACCL_BODY_SPEED * acclT * acclT / 2;
                    dist += 0 * unifT;
                }

                return Tool.polarToRect(dist, heading, xy.v1, xy.v2);
            } else if (velocity < 0) {
                if (enaccl) {
                    acclT = Math.min(diff, (Spec.MAX_BODY_SPEED + velocity) / Spec.ENACCL_BODY_SPEED);
                    unifT = diff - acclT;
                    dist = velocity * acclT - Spec.ENACCL_BODY_SPEED * acclT * acclT / 2;
                    dist += -Spec.MAX_BODY_SPEED * unifT;
                } else {
                    acclT = Math.min(diff, -velocity / Spec.DEACCL_BODY_SPEED);
                    unifT = diff - acclT;
                    dist = velocity * acclT + Spec.DEACCL_BODY_SPEED * acclT * acclT / 2;
                    dist += 0 * unifT;
                }
                return Tool.polarToRect(dist, heading, xy.v1, xy.v2);
            } else
                // velocity == 0
                return xy;

        }
    }

    private boolean testInField(DoublePair pair) {
        // �� �ܺο� ��ġ�� ���
        if ((pair.v1 < Spec.BODY_RADIUS) || (pair.v1 > fieldWidth - Spec.BODY_RADIUS) || (pair.v2 < Spec.BODY_RADIUS) || (pair.v2 > fieldHeight - Spec.BODY_RADIUS))
            return false;
        else
            return true;
    }


}
