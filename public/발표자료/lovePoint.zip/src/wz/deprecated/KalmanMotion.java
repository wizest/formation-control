/*
 * Created on 2006. 05. 12
 */
package wz.deprecated;

import wz.DoublePair;
import wz.motion.Motion;

/**
 * Kalman filter
 * 
 * @author Sanghoon, Kim
 */
public class KalmanMotion implements Motion {

    public DoublePair evalXY(double time) {
        // TODO http://en.wikipedia.org/wiki/Kalman_filter
        return null;
    }

    public double evalHeading(double time) {
        return -1;
    }

}
