/*
 * Created on 2006. 5. 6
 */
package wz.deprecated;

import java.io.File;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import robocode.RobocodeFileOutputStream;
import wz.Arena;
import wz.LovePoint;
import wz.RawEventAdapter;

public class ArenaFileDispatcher extends RawEventAdapter {

    private LovePoint self;
    private String fileName;

    public ArenaFileDispatcher(LovePoint self, String fileName) {
        this.self = self;
        this.fileName = fileName;
    }

    private void dispatchObject(Object o) throws Throwable {
        OutputStream os = null;

        File file = self.getDataFile(fileName);
        // self.out.println(file);
        os = new RobocodeFileOutputStream(file);
        ObjectOutputStream oos = new ObjectOutputStream(os);
        oos.writeObject(o);
        oos.flush();
        oos.close();
    }

    private int cnt = 0;

    public void onTick() {
        if (++cnt > 3) {
            Arena a = self.getArena();
            try {
                dispatchObject(a);
            } catch (Throwable e) {
                // self.out.println(e);
                e.printStackTrace();
            }
            cnt = 0;
        }
    }

}
