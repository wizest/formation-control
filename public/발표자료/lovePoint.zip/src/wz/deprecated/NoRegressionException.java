/*
 * Created on 2006. 06. 25
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.deprecated;

public class NoRegressionException extends Exception {
    public NoRegressionException(String s) {
        super(s);
    }

}
