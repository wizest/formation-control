/*
 * Created on 2006. 06. 25
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz.deprecated;

public class LinearRegression {
    // http://en.wikipedia.org/wiki/Linear_regression

    private double sumX, sumXX, sumXY, sumY, n;
    private double coeffA, coeffB;
    private boolean dirty;

    public LinearRegression() {
        sumX = sumY = sumXY = sumXX = n = 0;
        coeffA = coeffB = 0;
        dirty = false;
    }

    public synchronized void addSample(double x, double y) {
        sumX += x;
        sumY += y;
        sumXY += x * y;
        sumXX += x * x;
        n += 1;

        dirty = true;
    }

    public synchronized double estimateY(double x) throws NoRegressionException {
        if (dirty)
            reparameter();

        double y = coeffA + (coeffB * x);
        return y;
    }

    /**
     * coeffA, coeffB
     */
    private void reparameter() throws NoRegressionException {
        double t1 = n * sumXX - sumX * sumX;
        if (t1 == 0 || n == 0)
            throw new NoRegressionException("no regression");
        coeffB = (n * sumXY - sumX * sumY) / (t1);
        coeffA = (sumY - coeffB * sumX) / n;
    }

    public double[] getCoeffs() throws NoRegressionException {
        if (dirty)
            reparameter();

        return new double[] { coeffA, coeffB };
    }

    // public static void main(String[] args) throws Exception {
    // // test
    //
    // LinearRegression lr = new LinearRegression();
    // lr.addSample(1, 2);
    // lr.addSample(2, 3);
    // lr.addSample(3, 4);
    //
    // System.out.println(lr.estimateY(6));
    //
    // }
}
