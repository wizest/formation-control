/*
 * Created on 2006. 5. 6
 */
package wz.deprecated;

import robocode.BulletHitBulletEvent;
import robocode.BulletHitEvent;
import robocode.BulletMissedEvent;
import robocode.CustomEvent;
import robocode.DeathEvent;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import robocode.MessageEvent;
import robocode.RobotDeathEvent;
import robocode.ScannedRobotEvent;
import robocode.SkippedTurnEvent;
import robocode.WinEvent;
import wz.ArenaListener;
import wz.LovePoint;
import wz.RawEventListener;

public class DebugListener implements RawEventListener, ArenaListener {

    private LovePoint self;

    public DebugListener(LovePoint self) {
        this.self = self;
    }

    public void onCustomEvent(CustomEvent e) {
        self.out.println(e);
    }

    public void onDeath(DeathEvent e) {
        self.out.println(e);
    }

    public void onSkippedTurn(SkippedTurnEvent e) {
        self.out.println(e);
    }

    public void onBulletHit(BulletHitEvent e) {
        self.out.println(e);
    }

    public void onBulletHitBullet(BulletHitBulletEvent e) {
        self.out.println(e);
    }

    public void onBulletMissed(BulletMissedEvent e) {
        self.out.println(e);
    }

    public void onHitByBullet(HitByBulletEvent e) {
        self.out.println(e);
    }

    public void onHitRobot(HitRobotEvent e) {
        self.out.println(e);
    }

    public void onHitWall(HitWallEvent e) {
        self.out.println(e);
    }

    public void onRobotDeath(RobotDeathEvent e) {
        self.out.println(e);
    }

    public void onScannedRobot(ScannedRobotEvent e) {
        // self.out.print(System.currentTimeMillis() + e.getTime() + " ");
        self.out.println(e);
    }

    public void onWin(WinEvent e) {
        self.out.println(e);
    }

    public void onMessageReceived(MessageEvent e) {
        self.out.println(e);
    }

    public void onTick() {
    // self.out.println("Time: " + self.getTime());
    }

    public void onArenaRobotUpdated(String updatedName) {
        self.out.println(self.getArena().get(updatedName));
    }

    public void onArenaRobotRemoved(String robotName) {
        self.out.println(robotName);
    }

}
