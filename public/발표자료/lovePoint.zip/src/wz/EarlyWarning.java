/*
 * Created on 2006. 05. 22
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz;

import java.util.Vector;

import wz.motion.BulletMotion;
import wz.motion.Motion;

public class EarlyWarning implements ArenaListener {

    private LovePoint self;
    private MotionEvaluator predictor;

    public EarlyWarning(LovePoint self) {
        this.self = self;
        this.predictor = new MotionEvaluator(self.getBattleFieldWidth(), self.getBattleFieldHeight());
    }

    public void onArenaRobotRemoved(String robotName) {}

    private transient Vector<EarlyWarningListener> fEarlyWarningListeners;

    public synchronized void addEarlyWarningListener(EarlyWarningListener l) {
        @SuppressWarnings("unchecked")
        Vector<EarlyWarningListener> v = fEarlyWarningListeners == null ? new Vector<EarlyWarningListener>(2) : (Vector<EarlyWarningListener>) fEarlyWarningListeners.clone();
        if (!v.contains(l)) {
            v.addElement(l);
            fEarlyWarningListeners = v;
        }
    }

    public synchronized void removeEarlyWarningListener(EarlyWarningListener l) {
        if (fEarlyWarningListeners != null && fEarlyWarningListeners.contains(l)) {
            @SuppressWarnings("unchecked")
            Vector<EarlyWarningListener> v = (Vector<EarlyWarningListener>) fEarlyWarningListeners.clone();
            v.removeElement(l);
            fEarlyWarningListeners = v;
        }
    }

    protected void fireBulletFired(String enemyName, BulletMotion bulletMotion) {
        if (fEarlyWarningListeners != null) {
            Vector< ? > listeners = fEarlyWarningListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++) {
                ((EarlyWarningListener) listeners.elementAt(i)).onBulletFired(enemyName, bulletMotion);
            }
        }
    }

    public void onArenaRobotUpdated(String robotName) {
        Arena arena = self.getArena();
        RoboHistory hist = arena.get(robotName);
        if (hist == null)
            return;
        RoboTraits newP, oldP;
        synchronized (hist) {
            newP = hist.get(0);
            if (hist.size() > 1)
                oldP = hist.get(1);
            else
                oldP = newP;
        }

        if (arena.isMostAdjacent(robotName, self.getName()) // ���� ������ ���� ����� ��
                && newP.time - oldP.time <= 4) {// frame ������ 4 ������ ��
            double diffE = oldP.energy - newP.energy;
            if (diffE >= 0.099 && diffE <= 3.001) {
                // TODO ���� ��� �������� �ذ��� ���� ���� ��� �پ�� ���� �Ǵ��ϴ� �ڵ� �ʿ�
                // BulletTraits[] bulletTraits = arena.getFireHistory().getBulletTraits(robotName);
                // �ϴ� ������ ���� ��Ŷ� �����ϰ�!
                double power = Spec.getBulletEnergyToPower(diffE);

                double shooterGunHeading = Tool.rectToPolar(self.getX(), self.getY(), newP.x, newP.y).v2;

                // first candidate
                Motion myMotion = predictor.predictMe(arena, robotName, power);
                BulletMotion bulletMotion = MotionEvaluator.evalBulletHit(oldP, 0, shooterGunHeading, myMotion, power);
                fireBulletFired(robotName, bulletMotion);

                // second candidate
                // myMotion = new LinearMotion(arena.getMyself().getRecent());// predictor.predictMe(arena, robotName, power);
                // bulletMotion = MotionEvaluator.evalBulletHitMotion(oldP, false, 0, shooterGunHeading, myMotion, power);
                // fireBulletFired(robotName, bulletMotion);
            }
        }
    }
}
