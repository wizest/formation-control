/*
 * Created on 2006. 05. 28
 *
 * Kim,Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz;

import robocode.Bullet;
import robocode.CustomEvent;
import robocode.TurnCompleteCondition;
import wz.motion.MotionController;
import wz.motion.StuckMotion;
import wz.motion.TrackingController;

public class WinCeremonyMotionBehavior extends MotionBehavior {

    private final static int[][] region = { { 2, 1 }, { 3, 0 } };
    private final double fromX;
    private final double toX;
    private final double fromY;
    private final double toY;

    private boolean isFireReady = false;
    private int cntFire = 0;

    private MotionController mc;

    public WinCeremonyMotionBehavior(final LovePoint self) {
        super(self);

        int rg = evalRegion(self.getX(), self.getY());

        double[] fromXs = new double[] { self.getBattleFieldWidth(), 0, 0, self.getBattleFieldWidth() };
        double[] toXs = new double[] { 0, self.getBattleFieldWidth(), self.getBattleFieldWidth(), 0 };

        double[] fromYs = new double[] { self.getBattleFieldHeight(), self.getBattleFieldHeight(), 0, 0 };
        double[] toYs = new double[] { 0, 0, self.getBattleFieldHeight(), self.getBattleFieldHeight() };

        fromX = fromXs[rg];
        fromY = fromYs[rg];
        toX = toXs[rg];
        toY = toYs[rg];

        double[] destXs = new double[] { self.getBattleFieldWidth() * 0.8, self.getBattleFieldWidth() * 0.2, self.getBattleFieldWidth() * 0.2, self.getBattleFieldWidth() * 0.8 };
        double[] destYs = new double[] { self.getBattleFieldHeight() * 0.8, self.getBattleFieldHeight() * 0.8, self.getBattleFieldHeight() * 0.2, self.getBattleFieldHeight() * 0.2 };

        this.mc = new TrackingController(new StuckMotion(new DoublePair(destXs[rg], destYs[rg]))) {
            @Override
            protected DoublePair onMotionConverged() {
                double ref = Tool.rectToPolar(toX, toY, fromX, fromY).v2;
                double a1 = Tool.toRelRad(ref + Math.PI / 2, self.getHeadingRadians());
                double a2 = Tool.toRelRad(ref - Math.PI / 2, self.getHeadingRadians());

                double th;
                if (Math.abs(a1) < Math.abs(a2))
                    th = a1;
// self.setTurnRightRadians(a1);
                else
                    th = a2;
// self.setTurnRightRadians(a2);

                isFireReady = true;

                return new DoublePair(0, th);
            }
        };

        self.addCustomEvent(new TurnCompleteCondition(self));
    }

    private int evalRegion(double x, double y) {
        return region[x > self.getBattleFieldWidth() / 2 ? 1 : 0][y > self.getBattleFieldHeight() / 2 ? 1 : 0];
    }

    public void onCustomEvent(CustomEvent e) {
        if (e.getCondition() instanceof TurnCompleteCondition) {
            if (isFireReady && self.getEnergy() > 0.11 && cntFire < 1) {
                Bullet b = self.fireBullet(0.1);
                if (b != null)
                    ++cntFire;
            }
        }
    }

    @Override
    protected MotionController selectMotionController() {
        double ref = Tool.rectToPolar(toX, toY, self.getX(), self.getY()).v2;
        self.setTurnGunRightRadians(Tool.toRelRad(ref, self.getGunHeadingRadians()));
        self.setTurnRadarRightRadians(Tool.toRelRad(ref, self.getRadarHeadingRadians()));

        return mc;
    }

}
