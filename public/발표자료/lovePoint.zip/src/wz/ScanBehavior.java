/*
 * Created on 2006. 5. 3
 */
package wz;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

import robocode.CustomEvent;
import robocode.DeathEvent;
import robocode.RadarTurnCompleteCondition;
import robocode.RobotDeathEvent;
import robocode.ScannedRobotEvent;

public class ScanBehavior extends RawEventAdapter {

    private final LovePoint self;
    private final LinkedList<ScanTarget> scanTargetQ;

    private final static double FULL_SCAN_ANGLE = (360 + 10) * Math.PI / 180; // 370 deg
    private final static long THRS_REFRESH_TIME = 15;
    private final static double TURN_MARGIN = 7.5 * Math.PI / 180; // 15 deg

    private ScanTarget current = null;

    public ScanBehavior(LovePoint self) {
        this.self = self;
        this.scanTargetQ = new LinkedList<ScanTarget>();

        self.addCustomEvent(new RadarTurnCompleteCondition(self));
        self.setTurnRadarRightRadians(FULL_SCAN_ANGLE);
    }

    private synchronized void checkEnemy(String name, RoboTraits position) {
        self.getArena().add(name, position);
    }

    private synchronized void scheduleScanSequence() {
        Arena arena = self.getArena();
        RoboHistory[] hists = arena.getOthers();

        // ���̴� ȸ�� ���� ���� �κ� �켱
        Arrays.sort(hists, new Comparator<RoboHistory>() {
            public int compare(RoboHistory hist0, RoboHistory hist1) {

                RoboTraits p0 = hist0.getRecent();
                RoboTraits p1 = hist1.getRecent();

                double myX = self.getX();
                double myY = self.getY();
                double radarHeading = self.getRadarHeadingRadians();

                double a0 = Tool.toRelRad(Tool.rectToPolar(p0.x, p0.y, myX, myY).v2, radarHeading);
                double a1 = Tool.toRelRad(Tool.rectToPolar(p1.x, p1.y, myX, myY).v2, radarHeading);

                return (a0 - a1) > 0 ? 1 : (a0 - a1) < 0 ? -1 : 0;
            }
        });

        for (int i = 0, len = hists.length; i < len; ++i)
            putScanTarget(new ScanTarget(hists[i].name, self.getTime()));
    }

    private synchronized void putScanTarget(ScanTarget st) {
        scanTargetQ.addLast(st);
    }

    private synchronized void removeScanTarget(String name) {
        for (int i = 0, len = scanTargetQ.size(); i < len; ++i) {
            ScanTarget s = scanTargetQ.get(i);
            if (name.equals(s.name)) {
                scanTargetQ.remove(i);
                break;
            }
        }
    }

    private synchronized ScanTarget getScanTarget() {
        try {
            return scanTargetQ.removeFirst();
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    public void onCustomEvent(CustomEvent e) {
        if (e.getCondition() instanceof RadarTurnCompleteCondition)
            scanNext();
    }

    public synchronized void scanNext() {
        for (;;) {
            if (self.getOthers() == 0)
                break;

            current = getScanTarget();
            if (current == null) {
                scheduleScanSequence();
                continue;
            }

            double targetAngle;
            if (current.name == null)
                targetAngle = FULL_SCAN_ANGLE;
            else {
                Arena arena = self.getArena();
                RoboHistory hist = arena.get(current.name);
                if (hist == null) {
                    targetAngle = FULL_SCAN_ANGLE;
                } else {
                    RoboTraits p = hist.getRecent();
                    if (self.getTime() - p.time > THRS_REFRESH_TIME) // ���� �ð��� ���� ��� full scan
                        targetAngle = FULL_SCAN_ANGLE;
                    else {
                        double myX = self.getX();
                        double myY = self.getY();
                        double radarHeading = self.getRadarHeadingRadians();
                        targetAngle = Tool.toRelRad(Tool.rectToPolar(p.x, p.y, myX, myY).v2, radarHeading);
                        targetAngle = (targetAngle > 0) ? targetAngle + TURN_MARGIN : targetAngle - TURN_MARGIN;
                    }
                }
            }
            self.setTurnRadarRightRadians(targetAngle);

            break;
        }
    }

    public void onRobotDeath(RobotDeathEvent e) {
        self.getArena().removeRobot(e.getName());
    }

    public void onDeath(DeathEvent e) {
        self.getArena().removeRobot(self.getName());
    }

    public synchronized void onScannedRobot(ScannedRobotEvent e) {
        DoublePair pair = Tool.polarToRect(e.getDistance(), Tool.enemyTheta(self.getHeadingRadians(), e.getBearingRadians()), self.getX(), self.getY());
        RoboTraits p = new RoboTraits(pair.v1, pair.v2, e.getHeadingRadians(), e.getVelocity(), e.getEnergy(), e.getTime());

        checkEnemy(e.getName(), p);
        removeScanTarget(e.getName());

        if (current != null && e.getName().equals(current.name))
            scanNext();
    }
}

class ScanTarget {
    public final String name; // target �̸� - null�� ��� full scan
    public final long time; // target �� �� �ð�

    public ScanTarget(String name, long time) {
        this.name = name;
        this.time = time;
    }

    public String toString() {
        return "{name=" + name + ", fireTime=" + time + "}";
    }
}
