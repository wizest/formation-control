/*
 * Created on 2006. 5. 3
 */
package wz;

import robocode.Bullet;
import robocode.CustomEvent;
import robocode.GunTurnCompleteCondition;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import wz.motion.BulletMotion;
import wz.motion.Motion;

public class FireBehavior extends RawEventAdapter implements ArenaListener {

    private LovePoint self;
    private MotionEvaluator predictor;

    private String targetName = null;
    private double shootingPower = 1;
    private BulletMotion bulletMotion = null;

    public FireBehavior(LovePoint self) {
        this.self = self;
        this.predictor = new MotionEvaluator(self.getBattleFieldWidth(), self.getBattleFieldHeight());

        self.addCustomEvent(new GunTurnCompleteCondition(self));
    }

    public synchronized void onArenaRobotUpdated(String updatedName) {
        try {
            if (!self.getName().equals(updatedName) // �ڻ��� �ȵ� #_#
                    && updatedName.indexOf("LovePoint") < 0) { // ������ ��� �ȵ��� +_+

                if (targetName == null)
                    setDefaultTarget(updatedName);
                else {
                    double THRS_NEW_TARGET_DIST = 50; // magic - ���� Ÿ�ٺ��� �Ÿ��� 50 �̻� �� ������ ������ �״�� ����

                    Arena arena = self.getArena();
                    if (arena.get(targetName) == null) // ���� Ÿ���� �׾�����
                        setDefaultTarget(updatedName);
                    else {
                        RoboTraits next = arena.get(targetName).getRecent();
                        RoboTraits updated = arena.get(updatedName).getRecent();

                        if (MotionEvaluator.evalDist(self.getXY(), updated.xy) + THRS_NEW_TARGET_DIST < MotionEvaluator.evalDist(self.getXY(), next.xy))
                            setDefaultTarget(updatedName);
                    }

                }
            }
        } catch (NullPointerException e) {}
        loadFire();
    }

    public void onHitRobot(HitRobotEvent e) {
        // �ε��� ������ Ÿ������..
        setDefaultTarget(e.getName());
    }

    // private static int thrsIdleFireTick = 0;
    //
    // public void onTick() {
    // // ������ target�� ���� ���� ��츦 ����Ͽ�
    // --thrsIdleFireTick;
    // if (thrsIdleFireTick <= 0) {
    // if (self.getArena().get(targetName) == null) { // died
    // // �߸��� Ÿ���� ���ο� Ÿ������
    // try {
    // setDefaultTarget(self.getArena().evalAdjacentEnemies(self.getName())[0].name);
    // loadFire();
    // } catch (Exception e) {}
    // }
    // thrsIdleFireTick = 100; // 100 �����Ӹ��� üũ
    // }
    // }

    public synchronized void onHitByBullet(HitByBulletEvent e) {
        String enemy = e.getName();
        Arena arena = self.getArena();
        if (arena.get(enemy) != null) // �� ���� ���� ��� �ִ°�?
            if (arena.isMostAdjacent(self.getName(), enemy)) // ������ �ִ°�?
                setDefaultTarget(enemy);
    }

    public synchronized void onArenaRobotRemoved(String robotName) {
        if (robotName.equals(targetName)) {
            Arena arena = self.getArena();
            double minDist = 0xFFFF; // magic;
            String minDistName = null;
            RoboHistory[] hists = arena.getOthers();
            for (int i = 0, len = hists.length; i < len; ++i) {
                double dist = MotionEvaluator.evalDist(self.getXY(), hists[i].getRecent().xy);
                if (dist < minDist) {
                    minDist = dist;
                    minDistName = hists[i].name;
                }
            }

            setDefaultTarget(minDistName);
        }
        if (!robotName.equals(self.getName()))
            loadFire();
    }

    private void setDefaultTarget(String name) {
        targetName = name;
    }

    private String findTarget() {
        // TODO Ÿ����
        // 1. ���� ���߷��� ���� ��
        // 2. ������ �ִ� �� v
        // 3. �������� ���� ���� ��
        // 4. ���� ��� �� v
        // 5. ���峭 �� (���߾� �ִ� ��)
        // 6. �ε��� �� v

        return targetName;
        // RoboHistory hist = self.getArena().get(targetName);
        // return hist;
    }

    private synchronized void loadFire() {
        String target = findTarget();
        if (target == null)
            return;

        Motion enemy = predictor.predict(self.getArena(), target);
        if (enemy == null)
            return;

        DoublePair myPosition = self.getXY();
        DoublePair enemyPosition = enemy.evalXY(self.getTime());

        // TODO how to choose shooting power

        double dist = MotionEvaluator.evalDist(myPosition, enemyPosition);
        shootingPower = (dist < Spec.BODY_RADIUS * 2) ? 0.1 : Math.max(0.1, Math.min(3, 400 / dist)); // 400
        BulletMotion bm = evalBulletHit(enemy);
        DoublePair hitPolarPair = bm.hitPolarPosPair;

        // 2nd iteration
        dist = MotionEvaluator.evalDist(myPosition, Tool.polarToRect(hitPolarPair.v1, hitPolarPair.v2, myPosition.v1, myPosition.v2));
        shootingPower = (dist < Spec.BODY_RADIUS * 2) ? 0.1 : Math.max(0.1, Math.min(3, 400 / dist)); // 400
        bm = evalBulletHit(enemy);
        hitPolarPair = bm.hitPolarPosPair;

        double turn = Tool.toRelRad(hitPolarPair.v2, self.getGunHeadingRadians());
        self.setTurnGunRightRadians(turn);

        this.bulletMotion = bm;
    }

    private BulletMotion evalBulletHit(Motion enemy) {
        RoboHistory hist = self.getArena().getMyself();
        RoboTraits selfTraits = hist.getRecent();
        BulletMotion motion = MotionEvaluator.evalBulletHit(selfTraits, self.getTurnRemainingRadians(), self.getGunHeadingRadians(), enemy, shootingPower);
        // return motion.hitPolarPosPair;
        return motion;
    }

    // private static DoublePair evalHitPosition(DoublePair myPosition, double myGunHeading, Motion enemy, double shootingPower, double nowTime) {
    // RoboTraits me;
    // // double myGunHeading = self.getGunHeadingRadians();
    // DoublePair enemyPosition = enemy.eval(nowTime);
    //
    // // 3-times iteration
    // for (int i = 0, len = 3; i < len; ++i) {
    // double enemyHeading = Tool.rectToPolar(enemyPosition.v1, enemyPosition.v2, myPosition.v1, myPosition.v2).v2;
    // double relAngle = Tool.toRelRad(enemyHeading, myGunHeading);
    // double turnTime = (signum(relAngle) == signum(self.getTurnRemainingRadians())) ? (Math.abs(relAngle / (Spec.GUN_TURN - Spec.getMaxBodyTurnRate(self.getVelocity())))) : (Math.abs(relAngle / (Spec.GUN_TURN -
    // Spec.getMaxBodyTurnRate(self.getVelocity()))));
    // double hitTime = nowTime + turnTime + MotionEvaluator.evalDist(myPosition, enemyPosition) / Spec.getBulletSpeed(shootingPower);
    // enemyPosition = enemy.eval(hitTime);
    // }
    //
    // DoublePair pair = Tool.rectToPolar(enemyPosition.v1, enemyPosition.v2, myPosition.v1, myPosition.v2);
    // return pair;
    // }

    private synchronized void fire() {
        // TODO ���� ���� ���� �� ��� ���� �������� ���� �� ���� -> �����ϰ� �� �ع����� ������ ���� - ���߿� ������
        // TODO ���߷� ����ؼ� ��� ���غ��� ������ �׳� �����ϼ�
        // TODO ���� ���� ������ �ٵ� �ٶ󺸰� ������ ���� ����!
        if (targetName != null && self.getEnergy() > shootingPower) {
            RoboHistory hist = self.getArena().get(targetName);

            // died?
            if (hist == null)
                return;

            // for Ram Attack
            if (hist.getRecent().energy < Spec.RAM_DAMAGE && self.getEnergy() > Spec.RAM_DAMAGE // energy condition
                    && self.getArena().isMostAdjacent(hist.name, self.getName())) // distance condition
                return;

            if (bulletMotion != null) {
                Bullet bullet = self.setFireBullet(shootingPower);
                if (bullet != null)
                    self.getArena().getFireHistory().add(targetName, self.getTime(), bullet, bulletMotion);
                bulletMotion = null;
            }
        }
    }

    public void onCustomEvent(CustomEvent e) {
        if (e.getCondition() instanceof GunTurnCompleteCondition) {
            fire();
            loadFire();
        }
    }
}
