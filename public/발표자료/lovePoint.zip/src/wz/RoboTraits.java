/*
 * Created on 2006. 5. 3
 */
package wz;

import java.io.Serializable;

public class RoboTraits implements Serializable {

    public final double x;
    public final double y;
    public final DoublePair xy;
    public final double heading;
    public final double velocity;
    public final double energy;
    public final long time;

    public String toString() {
        return "{x=" + x + ", y=" + y + ", h=" + heading + ", v=" + velocity + ", e=" + energy + ", t=" + time + "}";
    }

    public RoboTraits(double x, double y, double heading, double velocity, double energy, long time) {
        this.x = x;
        this.y = y;
        this.xy = new DoublePair(this.x, this.y);
        this.heading = heading;
        this.velocity = velocity;
        this.energy = energy;
        this.time = time;
    }

}
