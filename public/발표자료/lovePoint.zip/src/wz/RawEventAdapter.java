/*
 * Created on 2006. 5. 3
 */
package wz;

import robocode.BulletHitBulletEvent;
import robocode.BulletHitEvent;
import robocode.BulletMissedEvent;
import robocode.CustomEvent;
import robocode.DeathEvent;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import robocode.MessageEvent;
import robocode.RobotDeathEvent;
import robocode.ScannedRobotEvent;
import robocode.SkippedTurnEvent;
import robocode.WinEvent;

public class RawEventAdapter implements RawEventListener {

    public void onCustomEvent(CustomEvent e) {}

    public void onDeath(DeathEvent e) {}

    public void onSkippedTurn(SkippedTurnEvent e) {}

    public void onBulletHit(BulletHitEvent e) {}

    public void onBulletHitBullet(BulletHitBulletEvent e) {}

    public void onBulletMissed(BulletMissedEvent e) {}

    public void onHitByBullet(HitByBulletEvent e) {}

    public void onHitRobot(HitRobotEvent e) {}

    public void onHitWall(HitWallEvent e) {}

    public void onRobotDeath(RobotDeathEvent e) {}

    public void onScannedRobot(ScannedRobotEvent e) {}

    public void onWin(WinEvent e) {}

    public void onMessageReceived(MessageEvent e) {}

    public void onTick() {}

}
