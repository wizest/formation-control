/*
 * Created on 2006. 05. 28
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz;

import wz.motion.BulletMotion;
import wz.motion.MotionController;

public abstract class MotionBehavior extends RawEventAdapter implements EarlyWarningListener {

    protected final LovePoint self;

    public MotionBehavior(final LovePoint self) {
        this.self = self;
    }

    public void onBulletFired(String enemyName, BulletMotion bulletMotion) {}

    public final void onTick() {
        move();
    }

    protected abstract MotionController selectMotionController();

    private void move() {
        MotionController mc = selectMotionController();
        DoublePair u = mc.getControlVandW(self);
        self.setAhead(u.v1);
        self.setTurnRightRadians(u.v2);
    }

}
