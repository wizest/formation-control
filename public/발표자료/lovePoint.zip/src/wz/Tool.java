/*
 * Created on 2006. 5. 3
 */
package wz;

import java.util.Random;

public class Tool {

    public static final Random rand = new Random(System.currentTimeMillis());

    public static double enemyTheta(double myRobotHeading, double enemyBearing) {
        return toPrincipleRad(myRobotHeading + enemyBearing);
    }

    public static double gunTheta(double robotHeading, double gunBearing) {
        return toPrincipleRad(gunBearing - robotHeading);
    }

    public static DoublePair polarToRect(double r, double theta, double originX, double originY) {
        double x = originX + r * Math.sin(theta);
        double y = originY + r * Math.cos(theta);
        return new DoublePair(x, y);
    }

    public static double raderTheta(double robotHeading, double gunBearing, double raderBearing) {
        return toPrincipleRad(raderBearing - gunBearing + robotHeading);
    }

    public static DoublePair rectToPolar(double x, double y, double originX, double originY) {
        double r = Math.sqrt((Math.pow((x - originX), 2) + Math.pow((y - originY), 2)));
        // double th = toPrincipleRad(Math.PI / 2 - Math.atan2((initY - originY), (initX - originX)));
        double th = toPrincipleRad(Math.atan2((x - originX), (y - originY)));
        return new DoublePair(r, th);
    }

    /**
     * @param rad
     * @return 0 <= rad < 2*PI
     */
    public static double toPrincipleRad(double rad) {
        // double r = rad % (Math.PI * 2);
        // if (r >= 0)
        // return r;
        // else
        // return 2 * Math.PI + r;

        return (rad + Math.PI * 200) % (Math.PI * 2);
    }

    /**
     * @param targetAbsAngle
     *            ���� ���� ����
     * @param refAbsAngle
     *            ���� ���� ����
     * @return -Math.PI <= th < Math.PI
     */
    public static double toRelRad(double targetAbsAngle, double refAbsAngle) {
        return toPrincipleRad(targetAbsAngle - refAbsAngle + Math.PI) - Math.PI;
        // return ((targetAbsAngle - refAbsAngle + Math.PI) + Math.PI * 200) % (Math.PI * 2) - Math.PI;
    }

    private Tool() {}

    // public static void main(String[] args) {
    // for (int i = -720 * 2; i < 720 * 2; ++i)
    // System.out.println(toRelRad(0, (double) i * Math.PI / 180));
    // }
}
