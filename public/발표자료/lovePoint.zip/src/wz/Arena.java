/*
 * Created on 2006. 5. 3
 */
package wz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;

public class Arena implements Serializable {

    private HashMap<String, RoboHistory> diedEnemies;
    private HashMap<String, RoboHistory> enemies;
    private transient Vector<ArenaListener> fArenaListeners;
    private String myName = "LovePoint"; // default
    private FireHistory fireHistory;

    public Arena() {
        this.enemies = new HashMap<String, RoboHistory>(10);
        this.diedEnemies = new HashMap<String, RoboHistory>(10);
        this.fireHistory = new FireHistory();
    }

    protected void fireOnArenaRobotUpdated(String updatedName) {
        if (fArenaListeners != null) {
            Vector< ? > listeners = fArenaListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((ArenaListener) listeners.elementAt(i)).onArenaRobotUpdated(updatedName);
        }
    }

    protected void fireOnArenaRobotRemoved(String name) {
        if (fArenaListeners != null) {
            Vector< ? > listeners = fArenaListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++) {
                ((ArenaListener) listeners.elementAt(i)).onArenaRobotRemoved(name);
            }
        }
    }

    public void setMyRobotName(String n) {
        this.myName = n;
    }

    public synchronized void addArenaListener(ArenaListener l) {
        @SuppressWarnings("unchecked")
        Vector<ArenaListener> v = fArenaListeners == null ? new Vector<ArenaListener>(2) : (Vector<ArenaListener>) fArenaListeners.clone();
        if (!v.contains(l)) {
            v.addElement(l);
            fArenaListeners = v;
        }
    }

    public synchronized void add(String name, RoboTraits p) {
        RoboHistory hist = (RoboHistory) enemies.get(name);
        if (hist == null) {
            hist = new RoboHistory(name, p);
            enemies.put(name, hist);
        } else
            hist.add(p);
        fireOnArenaRobotUpdated(name);
    }

    public synchronized RoboHistory[] getAll() {
        return (RoboHistory[]) enemies.values().toArray(new RoboHistory[0]);
    }

    public RoboHistory[] getOthers() {
        return getOthers(myName);
    }

    public synchronized RoboHistory[] getOthers(String name) {
        // Collection co = enemies.values();
        // ArrayList list = new ArrayList();
        // Iterator itr = co.iterator();
        // while (itr.hasNext()) {
        // RoboHistory hist = (RoboHistory) itr.next();
        // if (!hist.name.equals(name))
        // list.add(hist);
        // }
        //
        // return (RoboHistory[]) list.toArray(new RoboHistory[0]);
        HashMap<String, RoboHistory> es = new HashMap<String, RoboHistory>(enemies);// enemies.clone();
        es.remove(name);
        return es.values().toArray(new RoboHistory[0]);
    }

    public RoboHistory getMyself() {
        return get(myName);
    }

    public synchronized RoboHistory get(String name) {
        return (RoboHistory) enemies.get(name);
    }

    public synchronized void removeArenaListener(ArenaListener l) {
        if (fArenaListeners != null && fArenaListeners.contains(l)) {
            @SuppressWarnings("unchecked")
            Vector<ArenaListener> v = (Vector<ArenaListener>) fArenaListeners.clone();
            v.removeElement(l);
            fArenaListeners = v;
        }
    }

    public synchronized void removeRobot(String name) {
        RoboHistory hist = (RoboHistory) enemies.remove(name);
        if (hist != null)
            diedEnemies.put(name, hist);
        fireOnArenaRobotRemoved(name);
    }

    public String toString() {
        return enemies.keySet().toString();
    }

    public FireHistory getFireHistory() {
        return fireHistory;
    }

    public synchronized RoboHistory[] evalAdjacentEnemies(String name) {
        if (aliveSize() == 1) // ��� �ִ°� 1�� �� ��
            return new RoboHistory[0];

        HashMap<String, RoboHistory> es = new HashMap<String, RoboHistory>(enemies);// (HashMap<String, RoboHistory>) enemies.clone();
        RoboHistory ref = (RoboHistory) es.remove(name);

        if (ref == null) // name�� �������� ���� ��
            return new RoboHistory[0];
        if (es.size() == 1) // name�� ������ ���� 1���� ��
            return (RoboHistory[]) es.values().toArray(new RoboHistory[0]);

        // �Ʒ� ���ʹ� ���� 1���� ����. ------------------------

        final DoublePair refXY = ref.getRecent().xy;
        PriorityQ<RoboHistory> pq = new PriorityQ<RoboHistory>(new Comparator<RoboHistory>() {
            public int compare(RoboHistory arg0, RoboHistory arg1) {
                return MotionEvaluator.evalDist(refXY, arg0.getRecent().xy) < MotionEvaluator.evalDist(refXY, arg1.getRecent().xy) ? -1 : 1;
            }
        });
        Iterator<RoboHistory> itr = es.values().iterator();
        while (itr.hasNext()) {
            RoboHistory o = itr.next();
            pq.push(o);
        }

        ArrayList<RoboHistory> list = new ArrayList<RoboHistory>();
        RoboHistory nearest = pq.pop();
        list.add(nearest);
        double thrsDist = MotionEvaluator.evalDist(refXY, nearest.getRecent().xy) + Spec.BODY_RADIUS * 4;

        RoboHistory hist;
        while ((hist = (RoboHistory) pq.pop()) != null) {
            if (MotionEvaluator.evalDist(refXY, hist.getRecent().xy) <= thrsDist)
                list.add(hist);
            else
                break;
        }

        return list.toArray(new RoboHistory[0]);
    }

    public synchronized RoboHistory[] evalAdjacentEnemies(final DoublePair refXY) {
        if (aliveSize() <= 1) // ��� �ִ°� 1�� �� ��
            return (RoboHistory[]) enemies.values().toArray(new RoboHistory[0]);

        // �Ʒ� ���ʹ� ���� 1���� ����. ------------------------
        PriorityQ<RoboHistory> pq = new PriorityQ<RoboHistory>(new Comparator<RoboHistory>() {
            public int compare(RoboHistory arg0, RoboHistory arg1) {
                return MotionEvaluator.evalDist(refXY, arg0.getRecent().xy) < MotionEvaluator.evalDist(refXY, arg1.getRecent().xy) ? -1 : 1;
            }
        });
        Iterator<RoboHistory> itr = enemies.values().iterator();
        while (itr.hasNext()) {
            RoboHistory o = itr.next();
            pq.push(o);
        }

        ArrayList<RoboHistory> list = new ArrayList<RoboHistory>();
        RoboHistory nearest = pq.pop();
        list.add(nearest);
        double thrsDist = MotionEvaluator.evalDist(refXY, nearest.getRecent().xy) + Spec.ADJACENT_DIST_THRS;

        RoboHistory hist;
        while ((hist = (RoboHistory) pq.pop()) != null) {
            if (MotionEvaluator.evalDist(refXY, hist.getRecent().xy) <= thrsDist)
                list.add(hist);
            else
                break;
        }

        return list.toArray(new RoboHistory[0]);
    }

    public synchronized boolean isMostAdjacent(String viewer, String target) {
        // viewer ���忡�� target�� adjacent�Ѱ�?

        if (viewer.equals(target))
            return false;
        else if (aliveSize() == 2) // �Ѹ� ��� �ִ�.
            return true;

        // name1�� ����
        RoboHistory[] hists = evalAdjacentEnemies(viewer);
        for (int i = 0, len = hists.length; i < len; ++i)
            if (hists[i].name.equals(target))
                return true;

        return false;
    }

    public synchronized boolean isMuallyMostAdjacent(String name1, String name2) {
        if (name1.equals(name2))
            return false;
        else if (aliveSize() == 2) // �Ѹ� ��� �ִ�.
            return true;

        // name1�� ����
        RoboHistory[] hists = evalAdjacentEnemies(name1);
        for (int i = 0, len = hists.length; i < len; ++i)
            if (hists[i].name.equals(name2)) {
                // name2���� ������ ��
                RoboHistory[] hists2 = evalAdjacentEnemies(name2);
                for (int j = 0, len2 = hists2.length; j < len2; ++j)
                    if (hists2[j].name.equals(name1))
                        return true;
                break;
            }

        return false;
    }

    private synchronized int aliveSize() {
        return enemies.size();
    }

    private HashMap<String, Integer> hitScoreMap = new HashMap<String, Integer>();

    public synchronized void incHitScoreBy(String robotName) {
        Integer s = hitScoreMap.get(robotName);
        // int ss = hitScoreMap.get(robotName);
        int ss = 0;
        if (s != null)
            ss = s.intValue();

        ss += 2;
        hitScoreMap.put(robotName, ss);
    }

    public synchronized void decHitScoreBy(String robotName) {
        Integer s = (Integer) hitScoreMap.get(robotName);
        int ss = 0;
        if (s != null)
            ss = s.intValue();

        hitScoreMap.put(robotName, new Integer(Math.max(0, --ss)));

    }

    public synchronized void resetHitScoreBy(String robotName) {
        hitScoreMap.put(robotName, new Integer(0));

    }

    public synchronized int getHitScoreBy(String robotName) {
        Integer s = (Integer) hitScoreMap.get(robotName);
        int ss = 0;
        if (s != null)
            ss = s.intValue();
        return ss;
    }
}

class PriorityQ<T> {

    private Comparator<T> comparator;
    private LinkedList<T> list;

    public PriorityQ(Comparator<T> comparator) {
        this.comparator = comparator;
        this.list = new LinkedList<T>();
    }

    public synchronized void push(T t) {
        for (int i = 0, len = list.size(); i < len; ++i) {
            if (comparator.compare(t, list.get(i)) < 0) {
                list.add(i, t);
                return;
            }
        }
        list.addLast(t);
    }

    public synchronized T pop() {
        if (list.size() > 0)
            return list.removeFirst();
        else
            return null;
    }

    public String toString() {
        return list.toString();
    }
}
