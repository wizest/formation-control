/*
 * Created on 2006. 05. 18
 */
package wz;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedList;

import robocode.Bullet;
import wz.motion.BulletMotion;

public class FireHistory implements Serializable {

    private HashMap<String, LinkedList<BulletTraits>> hist;

    public FireHistory() {
        this.hist = new HashMap<String, LinkedList<BulletTraits>>(10);
    }

    public synchronized void add(String targetName, long fireTime, Bullet bullet, BulletMotion bulletMotion) {
        LinkedList<BulletTraits> l = hist.get(targetName);
        if (l == null) {
            l = new LinkedList<BulletTraits>();
            hist.put(targetName, l);
        }
        l.addFirst(new BulletTraits(fireTime, bullet, bulletMotion));
    }

    public synchronized BulletTraits[] getBulletTraits(String targetName) {
        LinkedList<BulletTraits> l = hist.get(targetName);
        if (l == null) {
            l = new LinkedList<BulletTraits>();
            hist.put(targetName, l);
        }

        return (BulletTraits[]) l.toArray(new BulletTraits[0]);
    }
}
