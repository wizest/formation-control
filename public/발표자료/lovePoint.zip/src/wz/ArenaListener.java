/*
 * Created on 2006. 5. 3
 */
package wz;

public interface ArenaListener {

    void onArenaRobotUpdated(String robotName);

    void onArenaRobotRemoved(String robotName);

}
