/*
 * Created on 2006. 5. 3
 */
package wz;

/**
 * double-typed value pair
 * 
 * @author Sanghoon, Kim
 */
public class DoublePair {
    public final double v1;
    public final double v2;

    public DoublePair(double v1, double v2) {
        this.v1 = v1;
        this.v2 = v2;
    }

    public DoublePair(DoublePair pair) {
        this.v1 = pair.v1;
        this.v2 = pair.v2;
    }

    public String toString() {
        return "{v1=" + v1 + ", v2=" + v2 + "}";
    }
}
