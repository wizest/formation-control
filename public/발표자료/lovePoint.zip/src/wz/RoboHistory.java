/*
 * Created on 2006. 5. 6
 */
package wz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class RoboHistory implements Serializable {
    private final static int MAX_HIST_ENTRY = 30 * 10; // �ִ� ��Ʈ��, �ʰ��� ������ �� ����

    public final String name;
    private LinkedList<RoboTraits> list;

    public RoboHistory(String name, RoboTraits p) {
        this.name = name;
        this.list = new LinkedList<RoboTraits>();

        add(p);
    }

    public String toString() {
        return "{name=" + name + ",size=" + list.size() + ", first=" + list.getFirst() + ", last=" + list.getLast() + "}";
    }

    public synchronized int size() {
        return list.size();
    }

    // public RoboHistory copy() {
    // try {
    // return (RoboHistory) clone();
    // } catch (CloneNotSupportedException e) {
    // e.printStackTrace();
    // return null;
    // }
    // }

    public synchronized void add(RoboTraits p) {
        // find index - �ֱ� ���� ���� �ε�����
        int idx = 0;
        Iterator<RoboTraits> i = list.iterator();
        while (i.hasNext()) {
            RoboTraits t = i.next();
            if (p.time > t.time)
                break;
            ++idx;
        }

        list.add(idx, p);
        if (list.size() > MAX_HIST_ENTRY)
            list.removeLast();
    }

    public synchronized RoboTraits getRecent() {
        return list.getFirst();
    }

    public synchronized RoboTraits getOldest() {
        return list.getLast();
    }

    public synchronized Iterator<RoboTraits> getRecentOrderIterator() {
        return list.iterator();
    }

    /**
     * @param fromTime
     * @return fireTime recently-first-ordering
     */
    public synchronized RoboTraits[] getFromTime(long fromTime) {
        ArrayList<RoboTraits> l = new ArrayList<RoboTraits>(100);
        Iterator<RoboTraits> i = list.iterator();

        while (i.hasNext()) {
            RoboTraits p = i.next();
            if (p.time < fromTime)
                break;
            else
                l.add(p);
        }

        return l.toArray(new RoboTraits[0]);
    }

    public synchronized RoboTraits getNearTime(double atTime) {
        RoboTraits traits = list.getFirst();
        for (int i = 1, len = list.size(); i < len; ++i) {
            RoboTraits t = list.get(i);
            if (Math.abs(traits.time - atTime) < Math.abs(t.time - atTime))
                break;
            traits = t;
        }

        return traits;
    }

    public synchronized RoboTraits[] getAll() {
        return list.toArray(new RoboTraits[0]);

        // ArrayList l = new ArrayList(100);
        // Iterator i = list.iterator();
        //
        // while (i.hasNext()) {
        // RoboTraits p = (RoboTraits) i.next();
        // l.add(p);
        // }
        //
        // return (RoboTraits[]) l.toArray(new RoboTraits[0]);
    }

    public synchronized RoboTraits get(int index) {
        return list.get(index);
    }

    public boolean equals(Object obj) {
        if (obj instanceof RoboHistory) {
            RoboHistory p = (RoboHistory) obj;
            return p.name.equals(this.name);
        } else
            return false;
    }

}
