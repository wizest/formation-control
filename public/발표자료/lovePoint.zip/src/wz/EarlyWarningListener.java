/*
 * Created on 2006. 05. 22
 */
package wz;

import wz.motion.BulletMotion;

public interface EarlyWarningListener {

    void onBulletFired(String enemyName, BulletMotion bulletMotion);

    // void onCriticalEnemy(String enemyName, Motion enemy);

}
