/*
 * Created on 2008. 05. 29
 *
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz;

import java.util.ArrayList;
import java.util.Iterator;

import robocode.HitRobotEvent;

import wz.motion.MotionController;
import wz.motion.StuckMotion;
import wz.motion.TrackingController;

public class FormationMotionBehavior extends MotionBehavior {

    public FormationMotionBehavior(LovePoint self) {
        super(self);

    }

    protected MotionController selectMotionController() {
        Arena a = self.getArena();
        RoboHistory h = a.getMyself();
        Iterator<RoboTraits> itr = h.getRecentOrderIterator();
        RoboTraits t = itr.next();
        RoboTraits t2 = itr.hasNext() ? itr.next() : t;
        double x = t.x;
        double y = t.y;
        double dx = t.x - t2.x;
        double dy = t.y - t2.y;
        double th = t.heading;
        double u1 = t.velocity;
        double _A11 = u1 == 0 ? 0 : -Math.sin(th) / u1;
        double _A12 = u1 == 0 ? 0 : Math.cos(th) / u1;
        double _A21 = Math.cos(th);
        double _A22 = Math.sin(th);
        double k11 = .300;
        double k12 = .50;
        double k21 = .300;
        double k22 = .50;

        // formation vector
        double[] z1 = new double[2];
        double[] z2 = new double[2];

        int _i = 0;
        int myIdx = getIndex(self.getName());
        ArrayList<RoboHistory> histArr = new ArrayList<RoboHistory>();
        RoboHistory right = a.get("wz.LovePoint (" + (myIdx + 1) + ")");
        if (myIdx % 2 > 0 && right != null) {
            histArr.add(right);
            z1[_i] = -200;
            z2[_i] = 0;
            _i++;
        }
        RoboHistory down = a.get("wz.LovePoint (" + (myIdx + 2) + ")");
        if (down != null) {
            histArr.add(down);
            z1[_i] = 0;
            z2[_i] = 200;
            _i++;
        }

        RoboHistory[] hists = histArr.toArray(new RoboHistory[0]);
        int len = hists.length;
        double N = len;

        double in1 = 0;
        double in2 = 0;

        for (int i = 0; i < len; ++i) {
            {
                RoboHistory _h = hists[i];
                Iterator<RoboTraits> _itr = _h.getRecentOrderIterator();
                RoboTraits _t = _itr.next();
                RoboTraits _t2 = _itr.hasNext() ? _itr.next() : _t;

                double _x = _t.x;
                double _y = _t.y;
                double _dx = _t.x - _t2.x;
                double _dy = _t.y - _t2.y;

                in1 += k11 * (x - _x - z1[i]);// + k21 * (dx - _dx);
                in2 += k12 * (y - _y - z2[i]);// + k22 * (dy - _dy);
            }
        }

        final double _u2 = N == 0 ? 0 : (_A11 * in1 + _A12 * in2) / N;
        final double _u3 = N == 0 ? 0 : (_A21 * in1 + _A22 * in2) / N;
        final double _u1 = u1 + _u3 / 30;

        if (len == 0) {
            double nx = self.getBattleFieldWidth() / 2 + 100.;
            double ny = self.getBattleFieldHeight() / 2 - 100.;
            DoublePair p = Tool.polarToRect(100, Tool.toPrincipleRad(self.getTime() / 45.), nx, ny);
            return new TrackingController(new StuckMotion(p));
// return new TrackingController(new StuckMotion(new DoublePair(nx, ny)));
        } else {
            double nx = x - in1;
            double ny = y - in2;
            return new TrackingController(new StuckMotion(new DoublePair(nx, ny)));
        }
    }

    public void onHitRobot(HitRobotEvent e) {
        super.onHitRobot(e);
// if (getIndex(self.getName()) < getIndex(e.getName()))
        if (e.isMyFault()) {
            self.ahead(-100);
            self.turnLeftRadians(3.14 / 2);
        } else {
            self.ahead(100);
// self.turnLeftRadians(-3.14 / 2);
        }

    }

    private int getIndex(String name) {
        // start with 1
        int b = name.indexOf("(");
        if (b < 0)
            return 1;
        int e = name.indexOf(")");
        return Integer.valueOf(name.substring(b + 1, e));
    }
}
