/*
 * Created on 2006. 5. 2
 * 
 * Kim Sanghoon (wizest@gmail.com)
 * http://blog.naver.com/wizest
 */
package wz;

import java.awt.Color;
import java.util.Vector;

import robocode.BulletHitBulletEvent;
import robocode.BulletHitEvent;
import robocode.BulletMissedEvent;
import robocode.CustomEvent;
import robocode.DeathEvent;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import robocode.MessageEvent;
import robocode.RobotDeathEvent;
import robocode.ScannedRobotEvent;
import robocode.SkippedTurnEvent;
import robocode.TeamRobot;
import robocode.WinEvent;

/**
 * @author Kim Sanghoon (wizest@gmail.com, http://blog.naver.com/wizest)
 */
public class LovePoint extends TeamRobot {

    private Arena arena;

    private transient Vector<RawEventListener> fRawEventListeners;

    public LovePoint() {
        this.arena = new Arena();
    }

    public synchronized void addRawEventListener(RawEventListener l) {
        @SuppressWarnings("unchecked")
        Vector<RawEventListener> v = fRawEventListeners == null ? new Vector<RawEventListener>(2) : (Vector<RawEventListener>) fRawEventListeners.clone();
        if (!v.contains(l)) {
            v.addElement(l);
            fRawEventListeners = v;
        }
    }

    protected void fireOnBulletHit(BulletHitEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onBulletHit(e);
        }
    }

    protected void fireOnBulletHitBullet(BulletHitBulletEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onBulletHitBullet(e);
        }
    }

    protected void fireOnBulletMissed(BulletMissedEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onBulletMissed(e);
        }
    }

    protected void fireOnCustomEvent(CustomEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onCustomEvent(e);
        }
    }

    protected void fireOnDeath(DeathEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onDeath(e);
        }
    }

    protected void fireOnHitByBullet(HitByBulletEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onHitByBullet(e);
        }
    }

    protected void fireOnHitRobot(HitRobotEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onHitRobot(e);
        }
    }

    protected void fireOnHitWall(HitWallEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onHitWall(e);
        }
    }

    protected void fireOnMessageReceived(MessageEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onMessageReceived(e);
        }
    }

    protected void fireOnRobotDeath(RobotDeathEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onRobotDeath(e);
        }
    }

    protected void fireOnScannedRobot(ScannedRobotEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onScannedRobot(e);
        }
    }

    protected void fireOnSkippedTurn(SkippedTurnEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onSkippedTurn(e);
        }
    }

    protected void fireOnTick() {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onTick();
        }
    }

    protected void fireOnWin(WinEvent e) {
        if (fRawEventListeners != null) {
            Vector< ? > listeners = fRawEventListeners;
            int count = listeners.size();
            for (int i = 0; i < count; i++)
                ((RawEventListener) listeners.elementAt(i)).onWin(e);
        }
    }

    public void onBulletHit(BulletHitEvent event) {
        fireOnBulletHit(event);
    }

    public void onBulletHitBullet(BulletHitBulletEvent event) {
        fireOnBulletHitBullet(event);
    }

    public void onBulletMissed(BulletMissedEvent event) {
        fireOnBulletMissed(event);
    }

    public void onCustomEvent(CustomEvent event) {
        fireOnCustomEvent(event);
    }

    public void onDeath(DeathEvent event) {
        fireOnDeath(event);
    }

    public void onHitByBullet(HitByBulletEvent event) {
        fireOnHitByBullet(event);
    }

    public void onHitRobot(HitRobotEvent event) {
        fireOnHitRobot(event);
    }

    public void onHitWall(HitWallEvent event) {
        fireOnHitWall(event);
    }

    public void onMessageReceived(MessageEvent e) {
        fireOnMessageReceived(e);
    }

    public void onRobotDeath(RobotDeathEvent event) {
        fireOnRobotDeath(event);
    }

    public void onScannedRobot(ScannedRobotEvent event) {
        fireOnScannedRobot(event);
    }

    public void onSkippedTurn(SkippedTurnEvent event) {
        fireOnSkippedTurn(event);
    }

    public void onWin(WinEvent event) {
        fireOnWin(event);
        removeRawEventListenerAll();
        // play win-ceremony
        MotionBehavior moveRule = new WinCeremonyMotionBehavior(this);
        addRawEventListener(moveRule);
    }

    public synchronized void removeRawEventListener(RawEventListener l) {
        if (fRawEventListeners != null && fRawEventListeners.contains(l)) {
            @SuppressWarnings("unchecked")
            Vector<RawEventListener> v = (Vector<RawEventListener>) fRawEventListeners.clone();
            v.removeElement(l);
            fRawEventListeners = v;
        }
    }

    private synchronized void removeRawEventListenerAll() {
        fRawEventListeners.clear();
    }

    public Arena getArena() {
        return arena;
    }

    public DoublePair getXY() {
        return new DoublePair(getX(), getY());
    }

    public void run() {
        // init
        arena.setMyRobotName(getName());
        setColors(Color.orange, Color.orange, Color.orange);

        setInterruptible(true);
        setAdjustGunForRobotTurn(true);
        setAdjustRadarForGunTurn(true);
        setAdjustRadarForRobotTurn(true);

        // object
        EarlyWarning earlyWarning = new EarlyWarning(this);
        ScanBehavior scanRule = new ScanBehavior(this);
        FireBehavior fireRule = new FireBehavior(this);
        MotionBehavior moveRule = new BattleMotionBehavior(this);

        MotionBehavior formationRule = new FormationMotionBehavior(this);

        // link
        addRawEventListener(scanRule);
// addRawEventListener(fireRule);
// addRawEventListener(moveRule);
        addRawEventListener(formationRule);
        arena.addArenaListener(fireRule);
        arena.addArenaListener(earlyWarning);
        earlyWarning.addEarlyWarningListener(moveRule);

        // debug
        // DebugListener debug = new DebugListener(this);
        // addRawEventListener(debug);
        // arena.addArenaListener(debug);
        // addRawEventListener(new ArenaFileDispatcher(this, getName() + ".arena"));

        while (true) {
            // update my position
            arena.add(getName(), new RoboTraits(getX(), getY(), getHeadingRadians(), getVelocity(), getEnergy(), getTime()));
            fireOnTick();
            execute();
        }
    }

}
