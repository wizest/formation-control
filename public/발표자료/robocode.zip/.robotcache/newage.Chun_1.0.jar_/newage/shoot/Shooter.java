/*
 * Created on 2004. 6. 21.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.shoot;
import newage.Chun;
import newage.Tactics;
import newage.debug.Debug;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
import newage.utility.MyInfo;
import java.awt.geom.Point2D;
import robocode.AdvancedRobot;
import robocode.Bullet;
/**
 * @author user
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class Shooter {
	public int mFireCnt;
	public double mFireDamage;
	public int mFireCntAtNow;
	public double mFireDamageAtNow;
	AdvancedRobot mRobot;
	Tactics mTactics;
	ShootingOrder mOrder;
	public Shooter(Chun chiu, Tactics tactics) {
		mRobot = chiu;
		mTactics = tactics;
	}
	public void Shoot() {
		if (mOrder != null && mOrder.isAllowFire()
				&& MyInfo.getGunTurnRemaining() == 0
				&& MyInfo.getGunHeat() == 0 && mTactics.isLock()) {
			Bullet bullet = mRobot.setFireBullet(mOrder.getPower());
			//			Debug.println("I act Fire");
			if (bullet != null) {
				mTactics.reportFire(bullet);
				//				Debug.println("FIRE AT "+ GameInfo.getTime() + " TICK");
				//				Debug.println("FIRE FIRE TO IN S: " + mOrder.getLocation());
				//				Debug.println("FIRE FIRE TO IN S: " + mOrder.getLocation());
				//				Debug.println("FIRE FIRE TO IN S: " + mOrder.getLocation());
				mOrder = null;
				++mFireCnt;
				mFireDamage += MathUtil.DamageByPower(bullet.getPower());
				++mFireCntAtNow;
				mFireDamageAtNow += MathUtil.DamageByPower(bullet.getPower());
			} else {
				//				Debug.println("fire! BUT NO BULLET");
			}
		} else {
			//			if (mOrder==null)
			//				Debug.println("Not Ordered");
			//			else if (! mOrder.isAllowFire())
			//				Debug.println("Not Allow");
			//			else if( MyInfo.getGunTurnRemaining()!=0)
			//				Debug.println("Now GunTurning!! remained :
			// "+MyInfo.getGunTurnRemaining());
			//			else if (MyInfo. getGunHeat()!=0)
			//				Debug.println("Gun is HOT!! heat: " + MyInfo.getGunHeat());
			//			else if (!mTactics.isLock())
			//				Debug.println("No Target, NO Locking");
		}
		mOrder = mTactics.getShootingOrder();
		if (mOrder != null)
			aimToLoacation(mOrder.getLocation());
	}
	/**
	 * @param double1
	 */
	private void aimToLoacation(Point2D.Double loc) {
		//		Debug.println("TO :: " + loc);
		double fireDirection = MathUtil.DirectionFormTo(MyInfo
				.getFutureLocation(), loc);
		double turnAngles = MathUtil.relativeDegrees(fireDirection
				- MyInfo.getGunHeading());
		//		Debug.println("Fire Ang " + fireDirection + " turnAng: "
		//				+ turnAngles);
		mRobot.setTurnGunRight(turnAngles);
	}
	/**
	 *  
	 */
	public void initAtRoundStart() {
		mFireCntAtNow = 0;
		mFireDamageAtNow = 0;
	}
}
