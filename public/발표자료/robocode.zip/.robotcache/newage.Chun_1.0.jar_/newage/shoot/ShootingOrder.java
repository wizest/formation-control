/*
 * Created on 2004. 6. 21.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.shoot;
import java.awt.geom.Point2D;
/**
 * @author user
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class ShootingOrder {
	Point2D.Double mLocation;
	double mPower;
	boolean mAllowFire;
	public ShootingOrder(Point2D.Double loc) {
		mPower = 0;
		mAllowFire = false;
		mLocation = loc;
	}
	public ShootingOrder(Point2D.Double loc, double power, boolean allowFire) {
		mAllowFire = allowFire;
		mLocation = loc;
		mPower = power;
	}
	/**
	 * @return Returns the location.
	 */
	public Point2D.Double getLocation() {
		return mLocation;
	}
	/**
	 * @return Returns the power.
	 */
	public double getPower() {
		return mPower;
	}
	/**
	 * @return Returns the allowFire.
	 */
	public boolean isAllowFire() {
		return mAllowFire;
	}
}
