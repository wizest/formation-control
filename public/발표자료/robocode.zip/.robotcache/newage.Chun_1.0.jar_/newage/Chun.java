/*
 * Created on 2004. 5. 26.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage;
import newage.debug.Debug;
import newage.driver.Driver;
import newage.infomation.EnemyInfoManager;
import newage.infomation.Scanner;
import newage.shoot.Shooter;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
import newage.utility.MyInfo;

import java.awt.Color;

import robocode.AdvancedRobot;
import robocode.BulletHitBulletEvent;
import robocode.BulletHitEvent;
import robocode.BulletMissedEvent;
import robocode.DeathEvent;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import robocode.RobotDeathEvent;
import robocode.ScannedRobotEvent;
import robocode.SkippedTurnEvent;
import robocode.WinEvent;
/**
 * @author Ȳ�ؽ�
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class Chun extends AdvancedRobot {
	static private Driver mDriver;
	static private EnemyInfoManager mEnemyInfoManager;
	static private Scanner mScanner;
	static private Shooter mShooter;
	static private Tactics mTactics;
//	static private WaveManager mWaveManager;
	static {
		mEnemyInfoManager = new EnemyInfoManager();
//		mWaveManager = new WaveManager();
	}
	static int mHitBulletCnt;
	static int mHitBulletCntAtNow;
	static double mHitDamage;
	static double mHitDamageAtNow;
	/**
	 * @return Returns the enemyInfoManager.
	 */
	public EnemyInfoManager getEnemyInfoManager() {
		return mEnemyInfoManager;
	}
	/**
	 *  
	 */
	private void initialize() {
		setAdjustGunForRobotTurn(true);
		setAdjustRadarForGunTurn(true);
		setAdjustRadarForRobotTurn(true);
		mHitBulletCntAtNow = 0;
		mHitDamageAtNow = 0;
		if (getRoundNum() == 0) {
			GameInfo.setRobot(this);
			Debug.initialize(this);
			setColors(new Color(10, 90, 90), Color.green, Color.black);
			setAdjustRadarForGunTurn(true);
			setAdjustGunForRobotTurn(true);
			MyInfo.setRobot(this);
			mScanner = new Scanner(this);
			mTactics = new Tactics(mEnemyInfoManager);//, mWaveManager);
			mShooter = new Shooter(this, mTactics);
			mDriver = new Driver(this);
		}
		GameInfo.initAtRoundStart();
		MyInfo.initAtRoundStart();
		mDriver.initAtRoundStart();
		mShooter.initAtRoundStart();
		MyInfo.initAtRoundStart();
		mTactics.initAtRoundStart();
		mEnemyInfoManager.initAtRoundStart();
//		mWaveManager.initAtRoundStart();
	}
	public void onBulletHit(BulletHitEvent event) {
		//		Debug.println("Bullet Hit");
		GameInfo.cashData();
		MyInfo.cashData();
		double damage = MathUtil.DamageByPower(event.getBullet().getPower());
		mHitBulletCnt++;
		mHitDamage += damage;
		mHitBulletCntAtNow++;
		mHitDamageAtNow += damage;
		super.onBulletHit(event);
	}
	public void onBulletHitBullet(BulletHitBulletEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		super.onBulletHitBullet(event);
//		mDriver.onHitByBullet();
	}
	public void onBulletMissed(BulletMissedEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		super.onBulletMissed(event);
	}
	public void onDeath(DeathEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		printRate();
		super.onDeath(event);
	}
	public void onHitByBullet(HitByBulletEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		double damage = MathUtil.DamageByPower(event.getBullet().getPower());
		Debug.println("Damaged :  " + damage + "   TICK : "
				+ GameInfo.getTime());
		super.onHitByBullet(event);
//		mDriver.onHitByBullet();
	}
	public void onHitRobot(HitRobotEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		super.onHitRobot(event);
	}
	public void onHitWall(HitWallEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		Debug.println("On Hit Wall  Tick: "
				+ GameInfo.getTime()
				+ "   Bear: "
				+ MathUtil.AbsoluteDegrees(event.getBearing()
						+ MyInfo.getHeading()));
		Debug.println(event.toString());
		super.onHitWall(event);
	}
	public void onRobotDeath(RobotDeathEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		mEnemyInfoManager.reportRobotDeath(event.getName());
	}
	public void onScannedRobot(ScannedRobotEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		//		out.println("T: " + getTime() + " X: " + getX() + " Y: " + getY());
		mEnemyInfoManager.reportScan(event);
	}
	public void onSkippedTurn(SkippedTurnEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		super.onSkippedTurn(event);
	}
	public void onWin(WinEvent event) {
		GameInfo.cashData();
		MyInfo.cashData();
		printRate();
		super.onWin(event);
	}
	public void printRate() {
		out.println("---- RATE CURRENT ROUND ----");
		out.println("fireCount=" + mShooter.mFireCntAtNow + "   HitCount"
				+ mHitBulletCntAtNow);
		out
				.println("percent : "
						+ (100 * (double) mHitBulletCntAtNow / (double) mShooter.mFireCntAtNow)
						+ "%");
		out.println("fireD=" + mShooter.mFireDamageAtNow + "   HitD"
				+ mHitDamageAtNow);
		out
				.println("percent : "
						+ (100 * (double) mHitDamageAtNow / (double) mShooter.mFireDamageAtNow)
						+ "%");
		out.println("---- RATE TOTAL BATTLE ----");
		out.println("fireCount=" + mShooter.mFireCnt + "   HitCount"
				+ mHitBulletCnt);
		out.println("percent : "
				+ (100 * (double) mHitBulletCnt / (double) mShooter.mFireCnt)
				+ "%");
		out.println("fireD=" + mShooter.mFireDamage + "   HitD" + mHitDamage);
		out.println("percent : "
				+ (100 * (double) mHitDamage / (double) mShooter.mFireDamage)
				+ "%");
	}
	public void run() {
		initialize();
		out.println("NumRound: " + getNumRounds() + "   RoundNum: "
				+ getRoundNum());
		while (true) {
			MyInfo.cashData();
			GameInfo.cashData();
			//			Debug.print("Mydata Save OK! ");
			//			mWaveManager.update();
			//			Debug.print("Mydata Save OK! ");
			mTactics.makePlan();
			//			Debug.print("Make Plan OK! ");
			mDriver.drive();
			//			Debug.print("Drive OK! ");
			mScanner.scan();
			//			Debug.print("Scan OK! ");
			mShooter.Shoot();
			//			Debug.print("Shoot OK! ");
			execute();
		}
	}
}
