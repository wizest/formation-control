package newage.infomation;
/*
 * Created on 2004. 5. 20.
 * 
 * To change the template for this generated file go to Window - Preferences -
 * Java - Code Generation - Code and Comments
 */
/**
 * @author Ȳ�ؽ�
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public interface CheckPontConstant {
	final int[] ticks = {10, 20, 40, 60, 80};
	final int NotCP =0;
	final int InverseToAhead = 2;
	final int InverseToBack = 3;
	final int StartAhead = 4;
	final int StartBack = 5;
	final int AheadStop = 6;
	final int BackStop = 7;
	final int HeavyTurnRightAhead = 8;
	final int HeavyTurnRightBack = 9 ;
	final int HeavyTurnLeftAhead = 10;
	final int HeavyTurnLeftBack = 11;
	final int Stationaly = 30;
	final int Reverse = 40;
	final int TurnPoint = 60;
}
