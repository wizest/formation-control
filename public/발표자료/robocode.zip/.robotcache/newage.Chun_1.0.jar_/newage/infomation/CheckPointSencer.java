/*
 * Created on 2004. 5. 26.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.infomation;
import java.text.DecimalFormat;
import newage.debug.Debug;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
/**
 * @author Ȳ�ؽ�
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class CheckPointSencer implements CheckPontConstant {
	double[] angVel = new double[6];
	EnemyInfo client = null;
	int mDelayCnt = 0;
	long mLatestUpdateTime;
	double[] mPreDirection = new double[6];
	double[] mPreVelocity = new double[6];
	int[] mPreWinding = new int[6];
	int mStopCnt;
	public CheckPointSencer(EnemyInfo info) {
		client = info;
		initAtRoundStart();
	}
	public int getSenceResult() {
		if (client.getTime() > mLatestUpdateTime) {
			insertData(client.getVelocity(), client.getMovingDirection(),
					client.getWindingDirection(), client.getAnglarVelocity());
			mLatestUpdateTime = client.getTime();
		}
		int mainType = NotCP, Direct = 1;
		if (isStationaly()) {
			mainType = Stationaly;
		} else if (isThroughZero()) {
			mainType = InverseToAhead;
		} else if (isStartMove()) {
			mainType = StartAhead;
		} else if (isTurnPoint()) {
			mainType = TurnPoint;
		}
		//		if (isHeavyTurn()) {
		//			mainType = HeavyTurnLeftAhead;
		//		}
		//		if (mainType == NotCP)
		//			mainType = NotCP;
		//		if (isAhead()) {
		//			Direct = 0;
		//		} else if (isBack()) {
		//			Direct = 1;
		//		}
		if (mainType != NotCP) {
			mStopCnt = 0;
			return mainType + Direct;
		}
		return NotCP;
	}
	/**
	 *  
	 */
	public void initAtRoundStart() {
		mDelayCnt = 0;
		mLatestUpdateTime = 0;
		for (int i = 0; i < mPreVelocity.length; ++i) {
			mPreVelocity[i] = 0;
			mPreDirection[i] = 0;
		}
	}
	private void insertData(double velocity, double movingdirect, int winding,
			double angv) {
		for (int i = mPreVelocity.length - 1; i > 0; --i) {
			mPreVelocity[i] = mPreVelocity[i - 1];
			mPreDirection[i] = mPreDirection[i - 1];
			mPreWinding[i] = mPreWinding[i - 1];
			angVel[i] = angVel[i - 1];
		}
//		Debug.println("ANGVEL: " + angv);
		mPreVelocity[0] = velocity;
		mPreDirection[0] = movingdirect;
		mPreWinding[0] = winding;
		angVel[0] = angv;
	}
	/**
	 * @return
	 */
	private boolean isAhead() {
		if (mPreVelocity[0] > 0)
			return true;
		return false;
	}
	/**
	 * @return
	 */
	private boolean isBack() {
		if (mPreVelocity[0] < 0)
			return true;
		return false;
	}
	public boolean isCP() {
		return getSenceResult() != NotCP;
	}
	/**
	 * @return
	 */
	private boolean isHeavyTurn() {
		//		DecimalFormat form = new DecimalFormat("##.##");
		//		Debug.println("AngDIFF : "
		//				+ form.format(Math.abs(mPreDirection[0] - mPreDirection[1])));
		if (mDelayCnt == 0
				&& Math.abs(mPreDirection[0] - mPreDirection[1]) >= 3) {
			mDelayCnt = 6;
			return true;
		}
		if (mDelayCnt > 0)
			mDelayCnt--;
		return false;
	}
	/**
	 * @return
	 */
	private boolean isReverseTurn() {
		if (mPreWinding[1] != mPreWinding[0])
			return true;
		return false;
	}
	/**
	 * @return
	 */
	private boolean isStartMove() {
		if (mPreVelocity[0] != 0 && mPreVelocity[1] == 0) {
			double sum = 0;
			for (int i = 1; i < mPreVelocity.length; ++i) {
				sum += mPreVelocity[i];
			}
			if (sum == 0)
				return true;
		}
		return false;
	}
	/**
	 * @return
	 */
	private boolean isStationaly() {
		if (mPreVelocity[0] < 1) {
			mStopCnt++;
		} else {
			mStopCnt = 0;
		}
		//		Debug.println("Stop: " + mStopCnt);
		if (mStopCnt == 10) {
			mStopCnt = 0;
			return true;
		}
		return false;
	}
	/**
	 *  
	 */
	private boolean isThroughZero() {
		if (mPreVelocity[0] * mPreVelocity[1] < 0)
			return true;
		if (mPreVelocity[1] == 0 && mPreVelocity[0] * mPreVelocity[2] < 0)
			return true;
		return false;
	}
	/**
	 * @return
	 */
	private boolean isTurnPoint() {
		mDelayCnt--;
		if (mDelayCnt > 0) {
			return false;
		}
		double sum = 0;
		for (int i = 0; i < angVel.length; ++i) {
			if (Math.abs(mPreVelocity[i]) < 1) {
				return false;
			}
			if (angVel[i] < 3)
				return false;
			sum += angVel[i];
		}
		if (sum > 30) {
			mDelayCnt = 10;
			return true;
		}
		//		if (mDelayCnt == 0
		//				&& Math.abs(mPreDirection[0] - mPreDirection[1]) >= 3) {
		//			mDelayCnt = 6;
		//			return true;
		//		}
		//		double turnRate = MathUtil.TurnRateByVelocity(client.getVelocity());
		//		long turnTick = (long) (45 / turnRate);
		//		EnemyInfo.Record oldData = client.getRecordAtTick(GameInfo.getTime()
		//				- turnTick);
		//		if (oldData == null)
		//			return false;
		//		double turnAng =
		// Math.abs(MathUtil.relativeDegrees(client.getHeading()
		//				- oldData.getHeading()));
		//		if (turnAng > 35)
		//			return true;
		return false;
	} /*
	   * InverseToAhead InverseToBack StartMove Stop HeavyTureRight
	   * HeavyTureLeft
	   */
}
