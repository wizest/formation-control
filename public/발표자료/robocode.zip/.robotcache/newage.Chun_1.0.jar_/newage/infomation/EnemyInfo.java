/*
 * Created on 2003. 5. 10.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package newage.infomation;
import newage.prophet.ProphetOfCP;
import newage.prophet.ProphetResult;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
import newage.utility.MyInfo;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
/**
 * @author Administrator
 * 
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class EnemyInfo implements CheckPontConstant {
	public class Record {
		double mAbsBearing, mMovingDirection;
		int mCPType;
		double mEnergy, mHeading, mVelocity, mAccelerate, mAnglarVelocity,
				mDistance;
		Point2D.Double mLocation;
		long mTime;
		int mWindingDirection;
		public Record(double energy, double heading, double bearing,
				double velocity, double anglevelocity, double accelerate,
				double distance, long time, int cptype) {
			mAbsBearing = MathUtil.AbsoluteDegrees(bearing
					+ MyInfo.getHeading());
			Point2D.Double myLoc = MyInfo.getLocation();
			mLocation = MathUtil.Project(myLoc, mAbsBearing, distance);
			mDistance = distance;
			mCPType = cptype;
			mTime = time;
			mEnergy = energy;
			mHeading = heading;
			mVelocity = velocity;
			mAnglarVelocity = anglevelocity;
			mAccelerate = accelerate;
			//			Debug.print("T: " + GameInfo.getTime() + " loc " + mLocation
			//					+ " d " + distance);
			//			Debug.println("TIME: " + GameInfo.getTime());
			if (velocity < 0)
				mMovingDirection = MathUtil.AbsoluteDegrees(mHeading + 180);
			else if (velocity > 0)
				mMovingDirection = mHeading;
			else if (mLatestRecord != null) {
				double oldMD = mLatestRecord.getMovingDirection();
				//				Debug.print(" OLD " +oldMD);
				if (Math.abs(MathUtil.relativeDegrees(oldMD - mHeading)) < 90) {
					mMovingDirection = mHeading;
				} else
					mMovingDirection = MathUtil
							.AbsoluteDegrees((mHeading + 180));
			} else {
				mMovingDirection = mHeading; // ó�� ���� �κ�. �ӵ��� 0�λ��·� ��ĵ�ɋ�.
			}
			mWindingDirection = MathUtil.WindingDirection(mMovingDirection,
					mAbsBearing);
			//			Debug.println("Winding: "
			//					+ mWindingDirection + " Move D: " + mMovingDirection);
			//			if (mWindingDirection == 1) {
			//				Debug.println(toString());
			//			}
			//			Debug.print("Location : " + mLocation);
		}
		/**
		 * @param preRecord
		 * @param nextRecord
		 */
		public Record(Record preRecord, Record nextRecord, long tick, int round) {
			try {
				long deltaTick = nextRecord.getTime() - preRecord.getTime();
				double deltaDistance = MathUtil.Distance(preRecord
						.getLocation(), nextRecord.getLocation());
				double progressDist = deltaDistance * deltaTick / tick;
				mLocation = MathUtil.Project(preRecord.getLocation(), MathUtil
						.DirectionFormTo(preRecord.getLocation(), nextRecord
								.getLocation()), progressDist);
				Point2D.Double myLoc = MyInfo.getLocation(round, tick);
				if (myLoc == null)
					return;
				//				Debug.print(" " + myLoc + " " + round + " " + tick);
				//				Debug.print(" " + mLocation);
				mAbsBearing = MathUtil.DirectionFormTo(myLoc, mLocation);
				mDistance = MathUtil.Distance(myLoc, mLocation);
				//			mCPType = cptype;
				mTime = tick;
				mEnergy = (preRecord.getEnergy() + nextRecord.getEnergy()) / 2.0;
				mVelocity = deltaDistance / tick;
				if (preRecord.getVelocity() > 0) {
					mHeading = MathUtil.DirectionFormTo(
							preRecord.getLocation(), nextRecord.getLocation());
				} else {
					mHeading = MathUtil.AbsoluteDegrees(MathUtil
							.DirectionFormTo(preRecord.getLocation(),
									nextRecord.getLocation()) + 180);
				}
				mAnglarVelocity = (MathUtil.relativeDegrees(nextRecord
						.getHeading()
						- preRecord.getHeading()))
						/ tick;
				//			mAnglarVelocity = anglevelocity;
				mAccelerate = 0;
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
		}
		public double getAbsBearing() {
			return mAbsBearing;
			//			return MathUtil.DirectionFormTo(MyInfo.getLocation(),
			// mLocation);
		}
		public double getAccelerate() {
			return mAccelerate;
		}
		public double getAnglarVelocity() {
			return mAnglarVelocity;
		}
		public int getCheckPoint() {
			return mCPType;
		}
		/**
		 * @return Returns the distance.
		 */
		public double getDistance() {
			return mDistance;
		}
		public double getEnergy() {
			return mEnergy;
		}
		public double getHeading() {
			return mHeading;
		}
		public Point2D.Double getLocation() {
			return mLocation;
		}
		/**
		 * @return Returns the movingDirection.
		 */
		public double getMovingDirection() {
			return mMovingDirection;
		}
		public long getTime() {
			return mTime;
		}
		public double getVelocity() {
			return mVelocity;
		}
		public int getWindingDirection() {
			return mWindingDirection;
		}
		public boolean isCheckPoint() {
			return mCPType != NotCP;
		}
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		public String toString() {
			return " RECORD Tick: " + mTime + "  MovingD: " + mMovingDirection
					+ "  ABS Bear: " + mAbsBearing + "  Wind: "
					+ mWindingDirection;
		}
		/**
		 * @param type
		 *            The cPType to set.
		 */
		public void setCPType(int type) {
			mCPType = type;
		}
	}
	boolean mAlive = false;
	double mAverageAngularVelocity = 0;
	double mAverageVelocity = 0;
	CheckPointSencer mCheckPointSencer;
	ArrayList mHistoryAtNowRound, mCPList;
	Hashtable mHistoryTable, mCPListTable, mHistoryByTimeAtNow, mHistoryFromTo;
	// TODO Record mLatestCheckPoint�� ���������ΰ�? Ȯ���϶�.
	Record mLatestCheckPoint;
	Record mLatestRecord;
	String mName;
	ProphetOfCP mProphet;
	//	RatingManager mRatingManager;
	int mUpdateTimes;
	private double mAverageCPDensity = 14;
	FromTo mCurFT;
	private class FromTo {
		long mFrom, mTo;
		public FromTo(long from) {
			mFrom = from;
			mTo = from;
		}
		public void setTo(long to) {
			mTo = to;
		}
		/**
		 * @return Returns the from.
		 */
		public long getFrom() {
			return mFrom;
		}
		/**
		 * @return Returns the to.
		 */
		public long getTo() {
			return mTo;
		}
	}
	public EnemyInfo(String name, double energy, double heading,
			double bearing, double velocity, double distance, long time) {
		mHistoryTable = new Hashtable();
		mHistoryFromTo = new Hashtable();
		//		mRatingManager = new RatingManager();
		mCheckPointSencer = new CheckPointSencer(this);
		mCPListTable = new Hashtable();
		initAtRoundStart(); // ���� ������ �ʱ�ȭ �ȴ�.. ���Լ��� ȣ��ڿ� ���� ����.
		mAlive = true;// ���� ����ȭ�� ���� �ڿ� �Ұ�..
		mName = name;
		mCurFT = new FromTo(time);
		mHistoryFromTo.put("" + GameInfo.getNowRoundNumber(), mCurFT);
		mAverageVelocity = Math.abs(velocity);
		mUpdateTimes = 1;
		mLatestCheckPoint = mLatestRecord = new Record(energy, heading,
				bearing, velocity, 0, 0, distance, time, AheadStop);
		mHistoryAtNowRound.add(mLatestRecord);
		mHistoryByTimeAtNow.put(new Long(time), mLatestRecord);
		mCPList.add(mLatestCheckPoint);
		//TODO mProphet�� �����.
		mProphet = new ProphetOfCP(this);
	}
	/**
	 * @return
	 */
	public double getAbsBearing() {
		return mLatestRecord.getAbsBearing();
	}
	/**
	 * @return
	 */
	public double getAccelerate() {
		return mLatestRecord.getAccelerate();
	}
	/**
	 * @return
	 */
	public double getAnglarVelocity() {
		return mLatestRecord.getAnglarVelocity();
	}
	public double getAverageAngularVelocity() {
		return mAverageAngularVelocity;
	}
	public double getAverageAngularVelocityCnt(int cnt) {
		int size = mHistoryAtNowRound.size();
		int fromindex = size - cnt;
		if (fromindex < 0)
			fromindex = 0;
		List sub = mHistoryAtNowRound.subList(fromindex, size);
		double result = 0;
		for (int i = 0; i < sub.size(); ++i) {
			EnemyInfo.Record data = (Record) sub.get(i);
			result += data.getAnglarVelocity();
		}
		if (getVelocity() < 0)
			return result / sub.size();
		else
			return result / sub.size();
	}
	/**
	 * @return
	 */
	public double getAverageVelocity() {
		if (getVelocity() < 0)
			return -mAverageVelocity;
		else
			return +mAverageVelocity;
	}
	public double getAverVelocityCnt(int cnt) {
		int size = mHistoryAtNowRound.size();
		int fromindex = size - cnt;
		if (fromindex < 0)
			fromindex = 0;
		List sub = mHistoryAtNowRound.subList(fromindex, size);
		double result = 0;
		for (int i = 0; i < sub.size(); ++i) {
			EnemyInfo.Record data = (Record) sub.get(i);
			result += Math.abs(data.getVelocity());
		}
		return result / sub.size();
	}
	/**
	 * @return Returns the cPList.
	 */
	public ArrayList getCPList() {
		return mCPList;
	}
	/**
	 * @return
	 */
	public double getDistanceFromMe() {
		//		return MathUtil.Distance(MyInfo.getLocation(), getLocation());
		return mLatestRecord.getDistance();
	}
	/**
	 * @return
	 */
	public double getEnergy() {
		return mLatestRecord.getEnergy();
	}
	public Point2D.Double getFutureLocate() {
		return MathUtil.Project(getLocation(), getHeading(), getVelocity());
	}
	public double getHeading() {
		return mLatestRecord.getHeading();
	}
	/**
	 * @return
	 */
	public EnemyInfo.Record[] getHistoryArrayAtRound(int round) {
		ArrayList history = (ArrayList) mHistoryTable.get("L" + round);
		return (Record[]) history.toArray(new EnemyInfo.Record[0]);
	}
	/**
	 * @return Returns the latestCheckPoint.
	 */
	public Record getLatestCheckPoint() {
		return mLatestCheckPoint;
	}
	public Record getLatestRecord() {
		return mLatestRecord;
	}
	public long getLatestScannedTime() {
		return mLatestRecord.getTime();
	}
	public Point2D.Double getLocation() {
		return mLatestRecord.getLocation();
	}
	public String getName() {
		return mName;
	}
	/**
	 * @param hitTime
	 * @return
	 */
	public ProphetResult getProphetResults(long hitTime, double bulletVelocity) {
		return mProphet.getProphetResults(hitTime, bulletVelocity);
	}
	public long getTime() {
		return mLatestRecord.getTime();
	}
	public double getVelocity() {
		return mLatestRecord.getVelocity();
	}
	public int getWindingDirection() {
		return mLatestRecord.getWindingDirection();
	}
	//	public Hashtable getProphetResults(long hitTime) {
	//		return mProphetManager.getProphetResults(hitTime);
	//	}
	//	TODO ���� ����
	//	/**
	//	 * @return
	//	 */
	//	public RatingBoard[] getSortedRatingBoard() {
	//		return mProphetManager.getSortedRatingBoard();
	//	}
	//	/**
	//	 * @param bullet
	//	 */
	//	public void attack(Bullet bullet) {
	//		mProphetManager.attack(bullet);
	//	}
	//	public void hitWave(String method, double power) {
	//		mRatingManager.reportHit(method, power);
	//	}
	public void initAtRoundStart() {
		mCurFT = null;
		mAlive = false;
		mLatestRecord = null;
		mLatestCheckPoint = null;
		mCPList = new ArrayList();
		//		Debug.println(mCPList.size()+"");
		mCheckPointSencer.initAtRoundStart();
		mHistoryAtNowRound = new ArrayList();
		mHistoryByTimeAtNow = new Hashtable();
		mHistoryTable.put("L" + GameInfo.getNowRoundNumber(),
				mHistoryAtNowRound);
		mHistoryTable.put("T" + GameInfo.getNowRoundNumber(),
				mHistoryByTimeAtNow);
		mCPListTable.put("" + GameInfo.getNowRoundNumber(), mCPList);
	}
	public boolean isAlive() {
		return mAlive;
	}
	public void setAlive(boolean alive) {
		mAlive = alive;
	}
	public void update(double energy, double heading, double bearing,
			double velocity, double distance, long time) {
		double Accel = 0;
		double AnglarVelo = 0;
		if (mCurFT == null) {
			mCurFT = new FromTo(time);
			mHistoryFromTo.put("" + GameInfo.getNowRoundNumber(), mCurFT);
		} else {
			mCurFT.setTo(time);
		}
		//		Debug.println("B: " +bearing);
		if (mLatestRecord != null) {
			Accel = velocity - mLatestRecord.getVelocity();
			AnglarVelo = heading - mLatestRecord.getHeading();
			//			setAlive(true);
			mAlive = true;
		}
		int cptype = NotCP;
		//		Debug.println("time " + time + " size " +
		// mHistoryAtNowRound.size());
		mLatestRecord = new Record(energy, heading, bearing, velocity,
				AnglarVelo, Accel, distance, time, cptype);
		if (mHistoryAtNowRound.size() != 0) {
			cptype = mCheckPointSencer.getSenceResult();
			mLatestRecord.setCPType(cptype);
			//			Debug.println(" CPType " + cptype);
		} else {
			mLatestRecord.setCPType(StartAhead);
		}
		mHistoryByTimeAtNow.put(new Long(GameInfo.getTime()), mLatestRecord);
		//	mCheckTimes.add(new Long(time));
		mHistoryAtNowRound.add(mLatestRecord);
		mAverageVelocity = (mAverageVelocity * mUpdateTimes + Math
				.abs(velocity))
				/ (mUpdateTimes + 1);
		mAverageAngularVelocity = (mAverageAngularVelocity * (mUpdateTimes - 1) + AnglarVelo)
				/ mUpdateTimes;
		if (mLatestRecord.isCheckPoint()) {
			if (mLatestCheckPoint != null) {
				long diffTick = Math.abs(mLatestCheckPoint.getTime()
						- mLatestRecord.getTime());
				mAverageCPDensity = (mAverageCPDensity * 9 + diffTick) / (10);
			}
			mLatestCheckPoint = mLatestRecord;
			mCPList.add(mLatestRecord);
			//			Debug.println("CP info -time " + getTime() + " type "
			//					+ mLatestRecord.getCheckPoint() + " head " + getHeading()
			//					+ " velo " + getVelocity() + " loc "
			//					+ mLatestRecord.getLocation() + " Bear: "
			//					+ mLatestRecord.getAbsBearing() + " wind: "
			//					+ mLatestCheckPoint.getWindingDirection());
		}
		++mUpdateTimes;
	}
	/**
	 * @return Returns the cPListTable.
	 */
	public Hashtable getCPListTable() {
		return mCPListTable;
	}
	public Record getRecordAtTick(int round, long tick) {
		Hashtable table = (Hashtable) mHistoryTable.get("T" + round);
		//		return (Record) table.get(new Long(tick));
		return getRecordAtTick(table, tick, round);
	}
	public EnemyInfo.Record getRecordAtTick(long tick) {
		//		return (Record) mHistoryByTimeAtNow.get(new Long(tick));
		return getRecordAtTick(mHistoryByTimeAtNow, tick, GameInfo
				.getNowRoundNumber());
	}
	private Record getRecordAtTick(Hashtable table, long tick, int round) {
		Long key = new Long(tick);
		if (table.containsKey(key)) {
			return (Record) table.get(key);
		} else {
			FromTo ft = (FromTo) mHistoryFromTo.get("" + round);
			if (tick < ft.getFrom() || tick > ft.getTo()) {
				return null;
			}
			//			Debug.print(GameInfo.getTime() + " TO: " + ft.getTo() + " "
			//					+ tick);
			//			Debug.println("RAT: " + tick + " IN " + ft.getFrom() + " ~ "
			//					+ ft.getTo() + " AT " + round + " R");
			//			Debug.println("" + (Record) table.get(key));
			Record preRecord, nextRecord;
			Long pre = new Long(tick), next = new Long(tick);
			long pretick = tick, nexttick = tick;
			do {
				--pretick;
				pre = new Long(pretick);
			} while (!table.containsKey(pre));
			preRecord = (Record) table.get(pre);
			do {
				--nexttick;
				next = new Long(nexttick);
			} while (!table.containsKey(next));
			nextRecord = (Record) table.get(next);
			return new Record(preRecord, nextRecord, tick, round);
		}
	}
	/**
	 * @return
	 */
	public double getMovingDirection() {
		return mLatestRecord.getMovingDirection();
	}
	/**
	 * @return
	 */
	public double getAverCPDensity() {
		return mAverageCPDensity;
	}
	/**
	 * @param l
	 */
	public ArrayList getCPsAfter(long tick) {
		ArrayList list = new ArrayList();
		for (int i = 0, size = mCPList.size(); i < size; ++i) {
			Record data = (Record) mCPList.get(i);
			if (data.getTime() > tick) {
				list.add(data);
			}
		}
		list.remove(mLatestCheckPoint);
		return list;
	}
	/**
	 * @param i
	 * @return
	 */
	public List getHistorySample(int num) {
		int size = mHistoryAtNowRound.size();
		return mHistoryAtNowRound.subList(Math.max(0, size - num), size);
	}
}