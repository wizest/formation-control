/*
 * Created on 2004. 2. 26.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.infomation;
import newage.Chun;
import newage.debug.Debug;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
import newage.utility.MyInfo;
/**
 * @author Administrator
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class Scanner {
	Chun mRobot;
	EnemyInfoManager mEnemyInfoManager;
	boolean missRobot = false;
	boolean turnRight = true;
	public Scanner(Chun robot) {
		mRobot = robot;
		mEnemyInfoManager = robot.getEnemyInfoManager();
	}
	//	public EnemyInfo getOldScaned() {
	//		EnemyInfo[] enemies = mEnemyInfoManager.getEnemiesArray();
	//		EnemyInfo tmpEnemy, scanRobo = null;
	//		long scanedtime = -1;
	//		long now = GameInfo.getTime();
	//		for (int i = 0; i < enemies.length; i++) {
	//			tmpEnemy = enemies[i];
	//			if (tmpEnemy.isAlive()) {
	//				long gaptime = now - tmpEnemy.getLatestScannedTime();
	//				if (gaptime < 10) {
	//					if (gaptime > scanedtime) {
	//						scanRobo = tmpEnemy;
	//						scanedtime = gaptime;
	//					}
	//				} else {
	//					// Debug.println("miss robo : " + tmpEnemy.getName());
	//					missRobot = true;
	//					return tmpEnemy;
	//				}
	//			}
	//		}
	//		missRobot = false;
	//		return scanRobo;
	//	}
	public EnemyInfo getOldScaned() {
		EnemyInfo[] enemies = mEnemyInfoManager.getEnemiesArray();
		EnemyInfo tmpEnemy, scanRobo = null;
		long scanedtime = -1;
		long now = GameInfo.getTime();
		for (int i = 0; i < enemies.length; i++) {
			tmpEnemy = enemies[i];
//			Debug.println(" " + tmpEnemy.isAlive());
			if (tmpEnemy.isAlive()) {
				long gaptime = now - tmpEnemy.getLatestScannedTime();
				if (gaptime < 10) {
					if (gaptime > scanedtime) {
						scanRobo = tmpEnemy;
						scanedtime = gaptime;
					}
				} else {
					//					Debug.println("miss robo : " + tmpEnemy.getName());
					missRobot = true;
					return tmpEnemy;
				}
			}
		}
		missRobot = false;
		return scanRobo;
	}
	public void scan() {
		double turnAngles = 360;
//		Debug.println("VAL CNT " + mEnemyInfoManager.getValidateCnt());
		if (!(mEnemyInfoManager.getValidateCnt() < GameInfo.getAllOthers())) {
			EnemyInfo scanTarget = getOldScaned();
//			Debug.println("" + scanTarget);
			turnAngles = MathUtil.relativeDegrees(scanTarget.getAbsBearing()
					- MyInfo.getRadarHeading());
			//			Debug.println(scanTarget.getName() + " ABSBear " +
			// scanTarget.getAbsBearing()
			//					+" TURN "+ turnAngles);
			if (missRobot) {
				if (turnAngles>0)
					turnAngles = 360;
				else
					turnAngles = -360;
			} else {
				turnAngles = adjustTurnDgrees(turnAngles);
			}
		}
		mRobot.setTurnRadarRight(turnAngles);
	}
	private double adjustTurnDgrees(double dgrees) {
		if (dgrees >= 0) {
			dgrees += 25;
			turnRight = true;
		} else {
			dgrees -= 25;
			turnRight = false;
		}
		return dgrees;
	}
}
