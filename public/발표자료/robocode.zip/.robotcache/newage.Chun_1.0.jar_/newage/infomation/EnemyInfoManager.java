/*
 * Created on 2003. 5. 10.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package newage.infomation;
import newage.debug.Debug;
import newage.utility.GameInfo;
import newage.utility.MyInfo;
import java.util.HashMap;
import robocode.ScannedRobotEvent;
/**
 * @author Administrator
 * 
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class EnemyInfoManager {
	int mValidateCnt = 0;
	static HashMap mEnemymap;
	public EnemyInfoManager() {
		int tmp = (int) (GameInfo.getAllOthers() * 1.5);
		mEnemymap = new HashMap(tmp);
	}
	private void IncreseValidateCount() {
		++mValidateCnt;
	}
	/**
	 * @param Name
	 * @return
	 */
	public EnemyInfo getEnemyInfoByName(String Name) {
		return (EnemyInfo) mEnemymap.get(Name);
	}
	/**
	 * @return
	 */
	public EnemyInfo[] getEnemiesArray() {
		return (EnemyInfo[]) mEnemymap.values().toArray(new EnemyInfo[0]);
	}
	/**
	 * @return
	 */
	public int getTotalEnemiesCount() {
		return mEnemymap.size();
	}
	public boolean isExistByName(String Name) {
		return mEnemymap.containsKey(Name);
	}
	public void reportScan(ScannedRobotEvent event) {
		//		Debug.println("" + posx + " " + posy);
		if (!isExistByName(event.getName())) {
			EnemyInfo info = new EnemyInfo(event.getName(), event.getEnergy(),
					event.getHeading(), event.getBearing(),
					event.getVelocity(), event.getDistance(), event.getTime());
			mEnemymap.put(event.getName(), info);
			IncreseValidateCount();
		} else {
			EnemyInfo info = getEnemyInfoByName(event.getName());
			if (!info.isAlive()) {
				IncreseValidateCount();
				info.setAlive(true);
			}
			info.update(event.getEnergy(), event.getHeading(), event
					.getBearing(), event.getVelocity(), event.getDistance(),
					event.getTime());
		}
	}
	public int getValidateCnt() {
		return mValidateCnt;
	}
	public void reportRobotDeath(String name) {
		--mValidateCnt;
		EnemyInfo info = getEnemyInfoByName(name);
		info.setAlive(false);
	}
	//	public void reportRoundEnd() {
	//		setValidateCnt(0);
	//		setAliveAll(false);
	//	}
	//	private void setAliveAll(boolean bool) {
	//		EnemyInfo[] enemies = getEnemiesArray();
	//		for (int i = 0; i < enemies.length; ++i) {
	//			enemies[i].setAlive(bool);
	//		}
	//	}
	public boolean isRemainEnemy() {
		return mValidateCnt != 0;
	}
	public void initAtRoundStart() {
		mValidateCnt = 0;
		EnemyInfo[] enemies = getEnemiesArray();
		mValidateCnt = 0;
		for (int i = 0; i < enemies.length; ++i) {
			enemies[i].initAtRoundStart();
		}
	}
}
