/*
 * Created on 2004. 2. 27.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.utility;
import newage.debug.Debug;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.ArrayList;
import java.util.Hashtable;
import robocode.AdvancedRobot;
/**
 * @author Administrator
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class MyInfo {
	static Hashtable currentMyLocHistory = null;
	private static double mEnergy;
	private static double mGunCoolingRate;
	private static double mGunHeading;
	private static double mGunHeat;
	private static double mGunTurnRemaining;
	private static double mHeading;
	private static double mRadarHeading;
	static AdvancedRobot mRobot;
	private static double mVelocity;
	//	private static double mX;
	//	private static double mY;
	static Hashtable myLocHistories = new Hashtable();
	private static Point2D.Double mLocation;
	static long mTick = -1;
	public static void cashData() {
		if (mTick < mRobot.getTime()) {
			mLocation = new Point2D.Double(mRobot.getX(), mRobot.getY());
			mEnergy = mRobot.getEnergy();
			mGunHeading = mRobot.getGunHeading();
			mGunHeat = mRobot.getGunHeat();
			mGunTurnRemaining = mRobot.getGunTurnRemaining();
			mHeading = mRobot.getHeading();
			mRadarHeading = mRobot.getRadarHeading();
			mVelocity = mRobot.getVelocity();
			currentMyLocHistory.put("" + mRobot.getTime(), new Point2D.Double(
					mRobot.getX(), mRobot.getY()));
			mTick = mRobot.getTime();
//			Debug.println("Tick :  " + mTick + "   size: "
//					+ currentMyLocHistory.size());
		}
	}
	/**
	 * @return
	 */
	public static double getEnergy() {
		return mEnergy;
	}
	public static Point2D.Double getFutureLocation() {
		Point2D.Double result = MathUtil.Project(getLocation(), mHeading,
				mVelocity);
		return result;
	}
	/**
	 * @return
	 */
	public static double getGunHeading() {
		return mGunHeading;
	}
	/**
	 * @return
	 */
	public static double getGunHeat() {
		return mGunHeat;
	}
	/**
	 * @return
	 */
	public static double getGunTurnRemaining() {
		return mGunTurnRemaining;
	}
	//	public static double getX() {
	//		return mRobot.getX();
	//	}
	//	public static double getY() {
	//		return mRobot.getY();
	//	}
	public static double getHeading() {
		return mHeading;
	}
	/**
	 * @return
	 */
	public static Point2D.Double getLocation() {
		return mLocation;
	}
	/**
	 * @param j
	 * @param l
	 * @return
	 */
	public static Double getLocation(int round, long tick) {
		Hashtable table = (Hashtable) myLocHistories.get("" + round);
		Point2D.Double result = (Double) table.get("" + tick);
		return result;
	}
	public static Point2D.Double getLocation(long tick) {
		return (Point2D.Double) currentMyLocHistory.get("" + tick);
	}
	/**
	 * @return
	 */
	public static double getMovingDirection() {
		if (mVelocity < 0) {
			return MathUtil.AbsoluteDegrees(mHeading + 180);
		}
		return mHeading;
	}
	/**
	 * @return
	 */
	public static double getRadarHeading() {
		return mRadarHeading;
	}
	public static long getRemainCoolingTime() {
		return (long) (Math.floor(mGunHeat / mGunCoolingRate));
	}
	/**
	 * @return
	 */
	//	public static double getDistanceToHitWall(double movingDirection) {
	//		int zone = (int) (MathUtil.AbsoluteDegrees(movingDirection) / 90);
	//		Point2D.Double loc = MyInfo.getLocation();
	//		double distance = 0;
	//		switch (zone) {
	//			case 0 : //
	//				distance =
	//				break;
	//			case 1 :
	//				distance = Math.min(loc.getY(), GameInfo.getBattleW()
	//						- loc.getX());
	//				break;
	//			case 2 :
	//				distance = Math.min(loc.getY(), loc.getX());
	//				break;
	//			case 3 :
	//			case 4 :
	//				distance = Math.min(GameInfo.getBattleH() - loc.getY(), loc
	//						.getX());
	//				break;
	//		}
	//		return distance ;
	//	}
	/**
	 * @return
	 */
	public static double getReverseMovingDiroection() {
		double reverse = MathUtil.AbsoluteDegrees(getMovingDirection() + 180);
		return reverse;
	}
	/**
	 * @return
	 */
	public static double getVelocity() {
		return mVelocity;
	}
	/**
	 *  
	 */
	public static void initAtRoundStart() {
		currentMyLocHistory = new Hashtable();
		myLocHistories.put("" + GameInfo.getNowRoundNumber(),
				currentMyLocHistory);
		mTick = 0;
	}
	static public void setRobot(AdvancedRobot robot) {
		mRobot = robot;
		mGunCoolingRate = robot.getGunCoolingRate();
	}
	/**
	 * @return
	 */
	//	public static Point2D.Double getOldLocation() {
	//		// TODO Auto-generated method stub
	//		return mOldLoc;
	//	}
	/**
	 * @return
	 */
	public static double getSpaceUsability() {
		long tick = mRobot.getTime();
		Point2D.Double loc = getLocation();
		ArrayList list = new ArrayList();
		if (list.size() < 30){
			return 0.5;
		}
		for (int i = 0, limit = (int) Math.min(tick, 40); i < limit; ++i) {
			//		currentMyLocHistory
			loc = (Double) currentMyLocHistory.get("" + tick);
//			Debug.println(" " + loc);
			list.add(loc);
			tick--;
		}
		return MathUtil.SpaceUsability(list);
	}
}
