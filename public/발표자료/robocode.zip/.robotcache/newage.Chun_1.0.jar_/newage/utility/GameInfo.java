package newage.utility;
import robocode.AdvancedRobot;
public class GameInfo {
	static double sBattlew, sBattleh;
	static AdvancedRobot sMyrobo;
	static int sOtherbots;
	static String sRoboname;
	public static final int MAX_VELOCITY = 8;
	private static long mTick;
	private static int mOthers;
	private static int mNowRoundNum;
	private static int mNumRounds;
	static public int getAllOthers() {
		return sOtherbots;
	}
	static public double getBattleH() {
		return sBattleh;
	}
	static public double getBattleW() {
		return sBattlew;
	}
	static public int getOthers() {
		return mOthers;
	}
	public static long getTime() {
		return mTick;
	}
	static public long getTimeforFire() {
		return mTick + 1;
	}
	static public int getNowRoundNumber() {
		return mNowRoundNum;
	}
	static public void setRobot(AdvancedRobot R) {
		sMyrobo = R;
		sBattlew = R.getBattleFieldWidth();
		sBattleh = R.getBattleFieldHeight();
		sRoboname = R.getName();
		sOtherbots = R.getOthers();
	}
	/**
	 * @return
	 */
	static public int getNumRounds() {
		return mNumRounds;
	}
	/**
	 *  
	 */
	public static void initAtRoundStart() {
		mNumRounds = sMyrobo.getNumRounds();
		mNowRoundNum = sMyrobo.getRoundNum();
		mTick = 0;
	}
	/**
	 *  
	 */
	public static void cashData() {
		if (mTick < sMyrobo.getTime()) {
			mTick = sMyrobo.getTime();
			mOthers = sMyrobo.getOthers();
		}
	}
}
