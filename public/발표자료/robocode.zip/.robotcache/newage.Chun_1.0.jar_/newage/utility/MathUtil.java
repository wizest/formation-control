package newage.utility;
import newage.debug.Debug;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.List;
public class MathUtil {
	public final static int CW = 1;
	public final static int STOP = 0;
	public final static int CCW = -1;
	static public double AbsoluteRadians(double R) {
		while (R < 0)
			R += Math.PI * 2;
		while (R >= 2 * Math.PI)
			R -= Math.PI * 2;
		return R;
	}
	static public double AbsoluteDegrees(double D) {
		while (D >= 360)
			D -= 360;
		while (D < 0)
			D += 360;
		if (D == 360)
			D = 0;
		return D;
	}
	static public double relativeRadians(double R) {
		while (R <= -Math.PI)
			R += Math.PI * 2;
		while (R > Math.PI)
			R -= Math.PI * 2;
		return R;
	}
	public static boolean isInBattleFieldInLimit(Point2D.Double loc,
			double limitNearWall) {
		if (loc.getX() < limitNearWall || loc.getY() < limitNearWall
				|| loc.getX() > GameInfo.getBattleW() - limitNearWall
				|| loc.getY() > GameInfo.getBattleH() - limitNearWall) {
			return false;
		}
		return true;
	}
	static public double relativeDegrees(double D) {
		while (D < -180)
			D += 360;
		while (D >= 180)
			D -= 360;
		return D;
	}
	static public int WindingDirection(double movingDirect, double bearing) {
		return WindingDirection(movingDirect, bearing, 1);
	}
	static public int WindingDirection(double movingDirect, double bearing,
			int init) {
		int windDirection = init; // 1 - ClockWise, -1 - Count ClockWise
		//		Debug.println("Move D: " + movingDirect + " bear: " + bearing);
		double tmp = MathUtil.relativeDegrees(movingDirect - bearing);
		if (tmp < 0) {
			windDirection = -1;
		} else if (tmp > 0) {
			windDirection = 1;
		}
		return windDirection;
	}
	static public double DamageByPower(double power) {
		return (power) > 1 ? ((power * 4) + 2 * (power) - 1) : (power * 4);
	}
	//	static public double DirectionFormTo(double xfrom, double yfrom,
	//			double xto, double yto) {
	//		return MathUtil.AbsoluteDegrees(Math.toDegrees(Math.atan2(xto - xfrom,
	//				yto - yfrom)));
	//	}
	static public double DirectionFormTo(Point2D.Double from, Point2D.Double to) {
		return MathUtil.AbsoluteDegrees(Math.toDegrees(Math.atan2(to.getX()
				- from.getX(), to.getY() - from.getY())));
	}
	static public double BulletVelocityFromBulletPower(double power) {
		return 20.0 - power * 3.0;
	}
	static public double BulletPowerFormBulletVelocity(double velo) {
		return (20.0 - velo) / 3.0;
	}
	static public Point2D.Double Project(Point2D.Double from,
			double absDirection, double distance) {
		double x, y;
		x = from.getX() + Math.sin(Math.toRadians(absDirection)) * distance;
		y = from.getY() + Math.cos(Math.toRadians(absDirection)) * distance;
		return new Point2D.Double(x, y);
	}
	public static double SpaceUsability(List list) {
		try {
			if (list.isEmpty())
				return 0;
			Point2D.Double loc = (Double) list.get(0);
			if(loc ==null)
				loc =MyInfo.getLocation();
			double top = loc.getY(), bottom = loc.getY(), right = loc.getX(), left = loc
					.getX();
			for (int i = 1, size = list.size(); i < size; ++i) {
				loc = (Double) list.get(i);
				if (loc != null) {
					double tmpx = loc.getX();
					double tmpy = loc.getY();
					if (tmpx < left)
						left = tmpx;
					if (tmpx > right)
						right = tmpx;
					if (tmpy < bottom)
						bottom = tmpy;
					if (tmpy > top)
						top = tmpy;
				}
			}
			//		Debug.println("T: " + top + " B: " + bottom + " R: " + right
			//				+ " L: " + left + " Size: " + list.size());
			double h = top - bottom;
			double w = right - left;
			double dist = Math.sqrt(h * h + w * w);
			//		Debug.println("W: " + w + " h: " + h + " dist : " + dist
			//				+ " size: " + list.size());
			return dist / (list.size() * 8);
		} catch (RuntimeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0.5;
		}
	}
	//	static public Point2D.Double CalcPolarCoord(double fromx, double fromy,
	//			double absDirection, double distance) {
	//		double x, y;
	//		x = fromx + Math.sin(absDirection) * distance;
	//		y = fromy + Math.cos(absDirection) * distance;
	//		return new Point2D.Double(x, y);
	//	}
	/**
	 * @param locate
	 * @return
	 */
	public static boolean IsInBattleField(Double location) {
		double limit = 17;
		if (location.getX() < limit || location.getY() < limit
				|| location.getX() > GameInfo.getBattleW() - limit
				|| location.getY() > GameInfo.getBattleH() - limit)
			return false;
		return true;
	}
	public static double Distance(Point2D.Double from, Point2D.Double to) {
		double x = to.getX() - from.getX();
		double y = to.getY() - from.getY();
		return Math.sqrt(y * y + x * x);
	}
	/**
	 * @param d
	 * @return
	 */
	public static double TurnRateByVelocity(double velocity) {
		return 10 - Math.abs(velocity);
	}
	//	static public double Distance(double x1, double y1, double x2, double
	// y2) {
	//		double x = x2 - x1;
	//		double y = y2 - y1;
	//		return Math.sqrt(y * y + x * x);
	//	}
}