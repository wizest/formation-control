/*
 * Created on 2004. 6. 21.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage;
import newage.debug.Debug;
import newage.infomation.EnemyInfo;
import newage.infomation.EnemyInfoManager;
import newage.prophet.ProphetResult;
import newage.shoot.ShootingOrder;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
import newage.utility.MyInfo;
import java.awt.geom.Point2D;
import robocode.Bullet;
/**
 * @author user
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class Tactics {
	//	double[] powers = new double[3];
	int mBullets;
	EnemyInfoManager mEnemyInfoManager;
	//	FeedBackManager mFeedBackManager;
	//	long mHitTime;
	boolean mLockP;
	boolean mLockT;
	int mProcessBullets;
	ProphetResult mResults;
	EnemyInfo mTarget;
	//	TesterBulletHitArea mTesterBulletHitArea;
	//	WaveManager mWaveManager;
	// TODO ���� ��ȹ�� ��ȿ���� �����϶�.
	double power = 0;
	private long mDelayTick = 4;
	/**
	 * @param enemyInfoManager
	 */
	public Tactics(EnemyInfoManager enemyInfoManager) { //, WaveManager
		// waveManager) {
		mEnemyInfoManager = enemyInfoManager;
		//		mWaveManager = waveManager;
		initAtRoundStart();
	}
	private long getBestHittingTime() {
		double distance = mTarget.getDistanceFromMe();
		double tmpVelocity = 0;
		mBullets = (int) (4 * Math.random());
		//		if (distance < 100) {
		//			power = 3;
		//		} else if (distance < 400) {
		//			power = 2;
		//		} else
		//			power = 1;
		//		if (distance < 100) {
		//			power = 3;
		//		} else if (distance < 150) {
		//			power = 2 + 1 * (150 - distance) / 50;
		//		} else if (distance < 400) {
		//			power = 1 + 1 * (400 - distance) / 250;
		//		} else {
		//			power = Math.max(1 * (650 - distance) / 250, 0.1);
		//		}
		//		if (distance < 110) {
		//			power = 3;
		//		} else if (distance < 150) {
		//			power = 2;
		//		} else if (distance < 250) {
		//			power = 1;
		//		} else if (distance < 400) {
		//			power = 0.7;
		//		} else if (distance < 600) {
		//			power = 0.4;
		//		} else {
		//			power = 0.1;
		//		}
		if (distance < 100) {
			power = 3;
		} else if (distance < 150) {
			power = 2;
		} else if (distance < 300) {
			power = 1.5;
		} else
			power = 1;
		//		double tEnergy = mTarget.getEnergy();
		//		if (tEnergy < 10) {
		//			power *= 0.2;
		//		} else if (tEnergy < 20) {
		//			power *= 0.4;
		//		} else if (tEnergy < 30) {
		//			power *= 0.7;
		//		}
		//		if (distance < 110) {
		//			power = 3;
		//		} else if (distance < 600) {
		//			power = 2 * 490 / (distance + 380);
		//		} else {
		//			power = Math.min(0.1, 1 * 600 / (distance));
		//		}
		//		if (distance < 150) {
		//			power = 3;
		//		} else {
		//			power = 2;
		//		}
		//TODO �ִ� �̵��Ÿ��� �����Ͽ� �Ѿ��� ���϶�..
		power = Math.min(getDeadPower(mTarget.getEnergy()), power);
		//		if (mTarget.getEnergy() <= 0.4 || MyInfo.getEnergy() < 1.5) {
		//			tmpPower = 0.1;
		//		}
		//		if (MyInfo.getEnergy() < 20) {
		//			power *= 0.7;
		//		}
		if (mTarget.getEnergy() <= 5 && MyInfo.getEnergy() < 5) {
			power = Math.min(power, MyInfo.getEnergy() - 2);
		}
		if (mTarget.getEnergy() <= 2 && MyInfo.getEnergy() <= 3) {
			power = 0.1;
		}
		power = Math.max(0.1, power);
		tmpVelocity = MathUtil.BulletVelocityFromBulletPower(power);
		double enemymove = 8 * distance / tmpVelocity;
		double dist2 = enemymove + distance;
		long flyTime = Math.round(dist2 / tmpVelocity);
		double direct = mTarget.getAbsBearing();
		double delta = Math.abs(MathUtil.relativeDegrees(direct
				- MyInfo.getGunHeading()));
		long gunTurnTick = (long) (delta / 20 + 1);
		return GameInfo.getTime() + flyTime
				+ Math.max(gunTurnTick, MyInfo.getRemainCoolingTime()) + 5;
		//		Debug.println("TIME : " + GameInfo.getTime()
		//				+ " Tactics make Plan HIT Time << " + mHitTime
		//				+ " >> target Esti Dist: " + dist2);
		//		Debug.println("Gun Turn Time: " + gunTurnTick + " CoolTime: "
		//				+ MyInfo.getRemainCoolingTime() + " Max : "
		//				+ Math.max(gunTurnTick, MyInfo.getRemainCoolingTime())
		//				+ " fly: " + flyTime);
	}
	private double getDeadPower(double energy) {
		double deadpower = 3;
		if (energy <= 4) {
			deadpower = energy / 4;
		} else if (energy <= 16) {
			deadpower = (energy + 2) / 6;
		}
		if (deadpower < 1 && deadpower > 0.3) {
			deadpower /= 2;
		}
		return deadpower;
	}
	/**
	 * @return Returns the hitTime.
	 */
	//	public long getHitTime() {
	//		return mHitTime;
	//	}
	/**
	 * @return
	 */
	public ShootingOrder getShootingOrder() {
		//		Debug.println("Call " + GameInfo.getTime());
		if (mTarget == null) {
			return null;
		}
		//		Debug.print("AAAAAAAAAAAAAAAAAAAAA");
		if (mResults == null) {
			return null;
		}
		//		Debug.print("BBBBBBBBBBBBBBBBBBBB");
		if (mLockP == false || mEnemyInfoManager.getValidateCnt() == 0) {
			mLockP = false;
			return new ShootingOrder(mTarget.getLocation());
		}
		//		if (results[processBullets] == null)
		//			Debug.println("Null results");
		Point2D.Double tmp = mResults.getLocation(mProcessBullets);
		//		Debug.println("LOC TO HIT : " + tmp + " MP: " + mProcessBullets);
		if (tmp == null) {
			if (mResults.size() <= mProcessBullets)
				mLockP = false;
			return new ShootingOrder(mTarget.getLocation());
		} else {
			//			Debug.println("Order: " + tmp + " proc: " + mProcessBullets);
		}
		//		Debug.print("DDDDDDDDDDDDDDDDDDDDD");
		/***********************************************************************
		 * 
		 * Smart Power Selection
		 *  
		 **********************************************************************/
		//		Debug.println(" esti loc "+tmp);
		boolean allowFire = true;
		double dist = MathUtil.Distance(tmp, MyInfo.getFutureLocation());
		long mHitTime = mResults.getHitTime();
		long needVelocity = (long) Math.ceil(dist
				/ (mHitTime - GameInfo.getTime()));
		//		if (mTarget.getEnergy() <= 5 && MyInfo.getEnergy() < 5) {
		//			power = Math.min(power, MyInfo.getEnergy() - 2);
		//		}
		//		if (mTarget.getEnergy() <= 3 && MyInfo.getEnergy() <= 3) {
		//			power = Math.min(power, MyInfo.getEnergy() - 0.5);
		//		}
		//		if (mTarget.getEnergy() <= 5 && MyInfo.getEnergy() <= 5) {
		//			power = 0.1;
		//		}
		if (needVelocity > 19.7) {
			mLockP = false;
			return new ShootingOrder(mTarget.getLocation());
		} else if (needVelocity < 11) {
			//			Debug.println("Need Velocity " + needVelocity);
			allowFire = false;
		}
		//		Debug.print("EEEEEEEEEEEEEEEEEEE");
		double power = MathUtil.BulletPowerFormBulletVelocity(needVelocity);
		if (power > MyInfo.getEnergy() - 1) {
			power = 0.1;
		}
		if (mTarget.getEnergy() <= 2 && MyInfo.getEnergy() <= 3) {
			allowFire = false;
		}
		power = Math.min(power, getDeadPower(mTarget.getEnergy()));
		ShootingOrder order = new ShootingOrder(tmp, power, allowFire);
		return order;
	}
	/**
	 * @return Returns the target.
	 */
	public EnemyInfo getTarget() {
		return mTarget;
	}
	public void initAtRoundStart() {
		//		mFeedBackManager = new FeedBackManager();
		//		mTesterBulletHitArea = new TesterBulletHitArea();
		mLockP = false;
		mLockT = false;
		mProcessBullets = 0;
		mBullets = 0;
		//		mHitTime = 0;
		mDelayTick = 1;
		mTarget = null;
	}
	/**
	 * @return Returns the lock.
	 */
	public boolean isLock() {
		return mLockP;
	}
	/**
	 *  
	 */
	public void makePlan() {
		//		mTesterBulletHitArea.check();
		//		mFeedBackManager.check();
		if (mDelayTick > GameInfo.getTime()) {
			return;
		}
		if (mLockP == false) {
			if (!mLockT) {
				mTarget = selectTarget();
			}
			if (mTarget != null && MyInfo.getGunHeat() == 0) {
				//				Debug.println("NOW TIME: " + GameInfo.getTime() + " MAKE
				// PLAN!!");
				//				if (mTarget.getEnergy() > 50
				//						&& mTarget.getEnergy() > MyInfo.getEnergy() * 1.5) {
				//					mLockP = false;
				//					mLockT = false;
				//					return;
				//				}
				EnemyInfo.Record cp = mTarget.getLatestCheckPoint();
				long gapTime = Math.abs(GameInfo.getTime() - cp.getTime());
				//				if (gapTime < 3) {
				//					mLockP = false;
				//				}
				//				if (gapTime > mTarget.getAverCPDensity() * 0.7) {
				//					mLockP = true;
				//					return;
				//				}
				mProcessBullets = 0;
				long HitTime = getBestHittingTime();
				mResults = mTarget.getProphetResults(HitTime, MathUtil
						.BulletVelocityFromBulletPower(power));
				if (mResults == null || mResults.isEmpty()) {
					mLockP = false;
					//					Debug.println("Prophet result NULL!!!");
					return;
				}
				//				Debug.print("Bullet " + mBullets);
				//				mFeedBackManager.add(mResults);
				mBullets = Math.min(mBullets, mResults.size());
				//				Debug.println(" adjest: " + mBullets);
				//				Debug.println(GameInfo.getTime() + " result len "
				//						+ mResults.getLocations().length);
				//				bullets = Math.min(bullets, mResults.getLocations().length);
				//				if (mResults.getLocations().length == 0) {
				//					mLock = false;
				//					Debug.println("Prophet result Zero!!!");
				//					processBullets=0;
				mLockP = true;
			}
		}
	}
	/**
	 * @param bullet
	 */
	public void reportFire(Bullet bullet) {
		//		mTesterBulletHitArea.add(mResults[processBullets], bullet);
		//		Debug.println("FIRE Process: " + mProcessBullets + " bullets "
		//				+ mBullets);
		mProcessBullets++;
		Debug.println("FIRE   p: " + bullet.getPower() + "  V: "
				+ bullet.getVelocity());
		if (mProcessBullets >= mBullets) {
			mLockP = false;
			mLockT = false;
			if (mTarget.getEnergy() > 30) {
				mDelayTick = (long) (GameInfo.getTime() + 10 * Math.random());
			}
		}
		//		Hashtable table = mTarget.getProphetResults(mHitTime);
		//		mWaveManager.generateWave(mTarget, table, bullet);
		//		mTarget.attack(bullet);
		//		if (mTarget!=null) {
		//			Debug.println("Time : " +mHitTime+" Enemy loc " +
		// results[0].getLocation());
		//		}
	}
	private EnemyInfo selectTarget() {
		EnemyInfo[] enemies = mEnemyInfoManager.getEnemiesArray();
		EnemyInfo tmpEnemy = null;
		EnemyInfo result = null;
		double dist = 99999;
		for (int i = 0; i < enemies.length; i++) {
			tmpEnemy = enemies[i];
			if (tmpEnemy.isAlive()) {
				if (tmpEnemy.getDistanceFromMe() < dist) {
					result = tmpEnemy;
					dist = tmpEnemy.getDistanceFromMe();
				}
			}
		}
		return result;
	}
}
