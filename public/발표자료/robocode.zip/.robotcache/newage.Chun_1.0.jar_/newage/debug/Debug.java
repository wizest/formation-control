/*
 * Created on 2004. 2. 27.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.debug;
import java.io.PrintStream;
import robocode.AdvancedRobot;
/**
 * @author Administrator
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class Debug {
	static boolean mDebugMode = false;
	static PrintStream out;
	static public void initialize(AdvancedRobot robo) {
		out = robo.out;
		mDebugMode = true;
	}
	/**
	 * @return Returns the debugMode.
	 */
	public static boolean isDebugMode() {
		return mDebugMode;
	}
	/**
	 * @param string
	 */
	public static void print(String string) {
		out.print(string);
	}
	static public void println(String str) {
		if (mDebugMode)
			out.println(str);
	}
	/**
	 * @param debugMode
	 *            The debugMode to set.
	 */
	public static void setDebugMode(boolean debugMode) {
		mDebugMode = debugMode;
	}
}
