/*
 * Created on 2004. 6. 23.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.prophet;
import newage.debug.Debug;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;
/**
 * @author user
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class StatisticsOfCP {
	private class STRecord implements Comparable {
		int cnt;
		double mFactor;
		int mIndex;
		public STRecord(int index, double factor) {
			mIndex = index;
			mFactor = factor;
			cnt = 1;
		}
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		public int compareTo(Object obj) {
			if (obj instanceof STRecord) {
				STRecord other = (STRecord) obj;
				if (mFactor < other.getFactor()) {
					return 1;
				} else if (mFactor > other.getFactor()) {
					return -1; //TODO �񱳰� �ùٸ���.?
				}
			}
			return 0;
		}
		/**
		 * @return
		 */
		public int getCount() {
			return cnt;
		}
		/**
		 * @return Returns the factor.
		 */
		public double getFactor() {
			return mFactor;
		}
		/**
		 * @return Returns the index.
		 */
		public int getIndex() {
			return mIndex;
		}
		public double increseFactor(double increment) {
			cnt++;
			return mFactor = mFactor + increment;
		}
	}
	int mMaxIndex = 999;
	int mMinIndex = 999;
	boolean mSorted = false;
	Hashtable mTable;
	STRecord[] records;
	int totalNum;
	public StatisticsOfCP() {
		mTable = new Hashtable();
	}
	/**
	 * start from 0 to Size-1
	 * 
	 * @param i
	 */
	public int getIndexOfNthGraterFactor(int n) {
		if (!mSorted) {
			records = (STRecord[]) mTable.values().toArray(new STRecord[0]);
			Arrays.sort(records);
			mSorted = true;
		}
		if (records != null && n < records.length)
			return records[n].getIndex();
		return n;
	}
	/**
	 * @param realHitIndex
	 * @return
	 */
	public Integer getNthOfIndex(int realHitIndex) {
		if (!mSorted) {
			records = (STRecord[]) mTable.values().toArray(new STRecord[0]);
			Arrays.sort(records);
			mSorted = true;
		}
		for (int i = 0; i < records.length; ++i) {
			if (records[i].getIndex() == realHitIndex) {
				return new Integer(i);
			}
		}
		return null;
	}
	/**
	 * @param index
	 */
	public void increse(int index, double factor) {
		totalNum++;
		if (Math.abs(index) > mMaxIndex)
			return;
		Integer i = new Integer(index);
		if (mTable.containsKey(i)) {
			//			Debug.println("UPDATE " + i);
			STRecord data = (STRecord) mTable.get(i);
			data.increseFactor(factor);
			mTable.put(i, data);
		} else {
			//			Debug.println("ADD " + i);
			mTable.put(i, new STRecord(index, factor));
		}
		mSorted = false;
	}
	/**
	 * @return
	 */
	public boolean isEmpty() {
		return mTable.isEmpty();
	}
	/**
	 * @param max
	 */
	public void setMaxMinIndex(int max) {
		mMaxIndex = max;
		mMinIndex = -max + 3;
	}
	public void setMaxMinIndex(int max, int min) {
		mMaxIndex = max;
		mMinIndex = min;
	}
	public void show() {
		Debug.println("STAT OF CP");
		records = (STRecord[]) mTable.values().toArray(new STRecord[0]);
		Arrays.sort(records);
		if (records != null) {
			int sum = 0;
			for (int i = 0; i < records.length; ++i) {
				Debug.println(i + " - I: " + records[i].getIndex() + "  F: "
						+ records[i].getFactor() + "  CNT: "
						+ records[i].getCount());
				sum += records[i].getCount();
			}
			//			Debug.println("SUM : " + sum);
		}
	}
	/**
	 * @return
	 */
	public int size() {
		return mTable.size();
	}
}
