/*
 * Created on 2004. 6. 22.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.prophet;
import newage.debug.Debug;
import newage.infomation.EnemyInfo;
import newage.infomation.EnemyInfo.Record;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
import newage.utility.MyInfo;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
/**
 * @author user
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class ProphetOfCP extends Prophet {
	private static final long MAX_ROBO_VELOCITY = 8;
	Hashtable mCPListTable;
//	RankHitCounter mRankHitCounter;
	public Hashtable mTheMapper = new Hashtable();
	final int ROBOSIZE = 33;
	public ProphetOfCP(EnemyInfo target) {
		super(target);
//		mRankHitCounter = new RankHitCounter();
		mCPListTable = mTarget.getCPListTable();
		ArrayList list = (ArrayList) mCPListTable.get("" + 0);
		//		Debug.println(" + " + list.size() );
		//		mCPList = mTarget.getCPList();
		mTheMapper = new Hashtable();
	}
	/**
	 * @param old
	 * @return
	 */
	private double extractFactor(int round, Record Aim, Record mid, Record end,
			Double myOldLoc, Record origin) {
		double curDistance = mTarget.getDistanceFromMe();
		double oldDistance = MathUtil.DirectionFormTo(myOldLoc, Aim
				.getLocation());
		double deltaDistance = Math.abs(oldDistance - curDistance);
		double deltaTick = Math.abs(GameInfo.getTime() - Aim.getTime());
		//		int deltaRound = GameInfo.getNowRoundNumber() - round;
		int deltaRound = GameInfo.getNowRoundNumber() - round + 1;
		double oldDeltaDirection = Math.abs(MathUtil.DirectionFormTo(Aim
				.getLocation(), mid.getLocation())
				- Aim.getMovingDirection());
		double curDeltaDirection = Math.abs(MathUtil.DirectionFormTo(origin
				.getLocation(), mTarget.getLocation())
				- origin.getMovingDirection());
		double deltaDirect = Math.abs(oldDeltaDirection - curDeltaDirection);
		//TODO ������ ���� ���� �Լ��� �����϶�.
		//		return 1 / (deltaRound * deltaDistance * deltaTick);
		//		return 1 / (deltaDistance * Math.pow(deltaTick,
		// 1+deltaRound/GameInfo.getNumRounds()));
		//		Debug.print(GameInfo.getTime() + " "
		//				+ (old.getTime() + (mTarget.getTime() - origin.getTime())));
		//		EnemyInfo.Record deltaOld = null;
		//		Debug.println("B");
		//		deltaOld = mTarget.getRecordAtTick(round, Aim.getTime()
		//				+ (mTarget.getTime() - origin.getTime()));
		double similarRate = 0.1;
		double distCur = MathUtil.Distance(origin.getLocation(), mTarget
				.getLocation());
		double distOld = MathUtil
				.Distance(Aim.getLocation(), mid.getLocation());
		if (distOld != 0)
			similarRate = 1 - Math.abs((distOld - distCur) / distOld);
		else
			similarRate = 0.1;
		similarRate = Math.max(0.1, similarRate);
		//			Debug.println("DISCUR: " + distCur + " DISTOLD: " + distOld
		//					+ " SRCRATE: " + similarRate);
		double similarFactor = Math.pow(similarRate, 3) * 10;
		double AbsAng = MathUtil.DirectionFormTo(Aim.getLocation(), mid
				.getLocation());
		int windingAimMid = MathUtil.WindingDirection(AbsAng, Aim
				.getAbsBearing());
		double curAbsAng = MathUtil.DirectionFormTo(origin.getLocation(),
				mTarget.getLocation());
		int windingOriginTar = MathUtil.WindingDirection(curAbsAng, origin
				.getAbsBearing());
		double windFactor = 0.2;
		int std = Aim.getWindingDirection() * origin.getWindingDirection();
		if (windingAimMid * windingOriginTar == std) {
			windFactor += 0.3;
			if (mTarget.getWindingDirection() * mid.getWindingDirection() == std) {
				windFactor += 0.5;
			}
		}
		windFactor = Math.pow(windFactor, 2);
		//		if (windingAimMid * windingOriginTar > 0) {
		//			windFactor = 100;
		//		}
		//		Debug.println("Winds: Old " + oldWinding + " cur " + curWinding);
		//		Debug.println("SIML: " + similarFactor);
		//		return 1 * windFactor / (deltaDistance * deltaTick * 2000 *
		// deltaRound);
		return windFactor * similarFactor / (Math.pow(deltaDistance, 1.5))
				/ deltaTick;
		//		return windFactor * similarFactor / (Math.pow(deltaDistance, 1.5))
		//				/ Math.pow(deltaTick, 2); // / Math.pow(1.1, deltaRound);//*
		// deltaRound);
	}
	public void feedBack(ProphetResult result) {
		// Debug.println("Before FeedBack");
		// mRankHitCounter.show();
		if (result instanceof ProphetResultOfCP) {
			// Debug.print("FeedBacking.....");
			ProphetResultOfCP cpresult = (ProphetResultOfCP) result;
			StatisticsOfCP statistics = cpresult.getStatistics();
			int realHitIndex = getIndex(cpresult.getOriginRecord(), null,
					mTarget.getLatestRecord(), MyInfo.getLocation(cpresult
							.getOriginRecord().getTime()));
			Integer i = statistics.getNthOfIndex(realHitIndex);
			if (i != null) {
				int rank = i.intValue();
//				mRankHitCounter.hit(realHitIndex, rank);
				// Debug.println(" Ok");
			}
			// else Debug.println(" No Match Index");
		}
		// Debug.println("After FeedBack");
		// mRankHitCounter.show();
	}
	/**
	 * @return
	 */
	private StatisticsOfCP generateStatisticsOfCP(long hitTime) {
		//			EnemyInfo.Record origin) {
		StatisticsOfCP stat = new StatisticsOfCP();
		//		int max = getMaxIndex(hitTime, origin.getTime());
		//		Debug.println("MAX INDEX: " + max);
		//		stat.setMaxMinIndex(max);
		ArrayList list = mTarget.getCPsAfter(GameInfo.getTime()
				- (hitTime - GameInfo.getTime()));
		List samplingList = mTarget.getHistorySample(40);
		double dist = getDistINCPS(samplingList);
		double r = dist / (40 * 8);
		//		Debug.println("R " + r + " dist : " + dist);
		//		if (r < 0.6) {
		//			stat.setMaxMinIndex(DistanceToIndex(dist));
		//		}
		for (int k = 0, size = list.size(); k < size; ++k) {
			EnemyInfo.Record origin = (Record) list.get(k);
			long diffTick = hitTime - origin.getTime();
			int sum = 0;
			EnemyInfo.Record begin, end;
			//		Debug.println("TIME " + GameInfo.getToexime());
			for (int j = 0; j <= GameInfo.getNowRoundNumber(); ++j) {
				ArrayList cpList = (ArrayList) mCPListTable.get("" + j);
				for (int i = 0; i < cpList.size(); ++i) {
					begin = (Record) cpList.get(i);
					//				Debug.println(j + " R cpsize " + cpList.size() + " HT: "
					//						+ hitTime);
					//				Debug.println("A");
					end = mTarget
							.getRecordAtTick(j, begin.getTime() + diffTick);
					//			Debug.println("LATER TICK " + (diffTick+old.getTime()));
					if (end != null) {
						Point2D.Double myOldLoc = MyInfo.getLocation(j, begin
								.getTime());
						EnemyInfo.Record middle = mTarget.getRecordAtTick(j,
								begin.getTime() + GameInfo.getTime()
										- origin.getTime());
						//						Debug
						//								.println("ODL " + old.getLocation() + " "
						//										+ old.getTime() + " DiffLater "
						//										+ sample.getTime() + " "
						//										+ sample.getLocation());
						//					Debug.println("MY OLD " + myOldLoc);
						if (myOldLoc != null && begin != null) {
							int index = getIndex(begin, middle, end, myOldLoc);
							double factor = extractFactor(j, begin, middle,
									end, myOldLoc, origin);
							stat.increse(index, factor);
							sum++;
						}
					} else {
						//					Debug.println("DiffLater Null " + j + "R t:"
						//							+ (old.getTime() + diffTick));
					}
				}
			}
		}
		return stat;
	}
	/**
	 * @param d
	 * @return
	 */
	private int DistanceToIndex(double distance) {
		return (int) Math.floor((distance + 18) / ROBOSIZE);
	}
	/**
	 * @param list
	 */
	private double getDistINCPS(List list) {
		if (list.isEmpty())
			return 0;
		EnemyInfo.Record rec = (Record) list.get(0);
		Point2D.Double loc = rec.getLocation();
		double top = loc.getY(), bottom = loc.getY(), right = loc.getX(), left = loc
				.getX();
		for (int i = 1, size = list.size(); i < size; ++i) {
			rec = (Record) list.get(i);
			loc = rec.getLocation();
			double tmpx = loc.getX();
			double tmpy = loc.getY();
			if (tmpx < left)
				left = tmpx;
			if (tmpx > right)
				right = tmpx;
			if (tmpy < bottom)
				bottom = tmpy;
			if (tmpy > top)
				top = tmpy;
		}
		//		Debug.println("T: " + top + " B: " + bottom + " R: " + right
		//				+ " L: " + left);
		double h = top - bottom;
		double w = right - left;
		double dist = Math.sqrt(h * h + w * w);
		//		Debug.println("W: " + w + " h: " + h + " dist : " + dist
		//				+ " size: " + list.size());
		return dist;
	}
	private double getEstimateDistance(int index) {
		return index * ROBOSIZE;//- (ROBOSIZE) + ROBOSIZE * 2 * Math.random();
	}
	private int getIndex(EnemyInfo.Record aimRecord,
			EnemyInfo.Record thoughtRecord, EnemyInfo.Record avoidRecord,
			Point2D.Double fireLoc) {
		int result = 0;
		double distance = MathUtil.Distance(aimRecord.getLocation(),
				avoidRecord.getLocation());
		//		Debug.println("Old : " + aimRecord.getLocation() + " OldT: "
		//				+ aimRecord.getTime() + " Sample: " + avoidRecord.getLocation()
		//				+ " SimT: " + avoidRecord.getTime() + " dist: " + distance);
		double AbsAng = MathUtil.DirectionFormTo(aimRecord.getLocation(),
				avoidRecord.getLocation());
		int winding = MathUtil.WindingDirection(AbsAng, aimRecord
				.getAbsBearing());
		int windingTh = 1;
		if (thoughtRecord != null) {
			double AbsAngTh = MathUtil.DirectionFormTo(aimRecord.getLocation(),
					thoughtRecord.getLocation());
			windingTh = MathUtil.WindingDirection(AbsAng, aimRecord
					.getAbsBearing());
		} else {
			windingTh = aimRecord.getWindingDirection();
		}
		//		Debug.print("Wind " + winding + " ");
		result = (int) Math.floor((distance + ROBOSIZE / 2) / ROBOSIZE)
				* winding * windingTh;
		return result;
	}
	/**
	 * @return
	 */
	private int getMaxIndex(long hitTime, long originTime) {
		long deltaTick = hitTime - originTime;
		double distance = deltaTick * GameInfo.MAX_VELOCITY;
		int result = (int) ((distance + 18) / ROBOSIZE + 1);
		return result;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see hwandan.prophet.Prophet#getProphetMethodeCode()
	 */
	public String getProphetMethodeCode() {
		return "CP";
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see hwandan.prophet.Prophet#getProphetResults(long)
	 */
	public ProphetResult getProphetResults(long hitTime, double bulletVelocity) {
		if (mTarget.getDistanceFromMe() < 160) {
			return super.getProphetResults(hitTime, bulletVelocity);
		}
		//		Debug.println("Call getProphetResult " + hitTime + " In Game Time "
		//				+ GameInfo.getTime());
		EnemyInfo.Record origin;
		origin = mTarget.getLatestCheckPoint();
		if (origin == null)
			return null;
		StatisticsOfCP stat = generateStatisticsOfCP(hitTime);
		//		stat.show();
		if (stat.isEmpty())
			return null;
		if (mTarget.getEnergy() < 0.001) {
			Point2D.Double[] tmp = {mTarget.getLocation()};
			return new ProphetResultOfCP(this, mTarget, hitTime, tmp, stat,
					origin);
		}
		//TODO CP�� ���� ����� ����ϴ� �ڵ�
		//		stat.show();
		//		Debug.println("HIT TIME :: " + hitTime);
		//		Debug.println("Time Gap : " + (hitTime - GameInfo.getTime()) + " D:
		// "
		//				+ (8 * (hitTime - GameInfo.getTime())));
		//		Debug.print(" Sizeof Stat: " + stat.size());
		ArrayList list = new ArrayList();
		//		Debug.println("STSIZE: " + stat.size());
		for (int i = 0, size = stat.size(); i < size; ++i) {
			//			int index = stat.getIndexOfNthGraterFactor(mRankHitCounter
			//					.getRankOfNthGraterCounter(i));
			int index = stat.getIndexOfNthGraterFactor(i);
			//			Debug.println(i + " th Rank: "
			//					+ mRankHitCounter.getRankOfNthGraterCounter(i)
			//					+ " Index: " + index);
			//			double direction = origin.getMovingDirection();
			double direction = MathUtil.DirectionFormTo(origin.getLocation(),
					mTarget.getLocation());
			//						Debug.println("or : " + origin.getLocation() + " mT: "
			//								+ mTarget.getLocation());
			//			Integer mapi = (Integer) mTheMapper.get(new Integer(index));
			//			int tmp = index;
			//			if (mapi != null) {
			//				tmp = mapi.intValue();
			//			}
			double estimateMovement = getEstimateDistance(index);
			// TODO ��������� �̵��� ������ �����Ͽ� �����Ұ��ΰ�?
			Point2D.Double loc = MathUtil.Project(origin.getLocation(),
					direction, estimateMovement);
			//			if (isTargetCanGo(loc, hitTime, bulletVelocity)) {
			if (isTargetCanGo(loc, hitTime, bulletVelocity)) {
				//				Debug.println("i: " + i + " Index: " + index + " Dist: "
				//						+ estimateMovement + " loc " + loc + " MD: "
				//						+ direction + " T: " + (hitTime - origin.getTime())
				//						+ " Origin: " + origin.getLocation() + " OT: "
				//						+ origin.getTime());
				list.add(loc);
			}
			//				Debug.println("i: " + i + " Index: " + index + " Dist: "
			//						+ estimateMovement + " loc " + loc + " MD: "
			//						+ direction + " T: " + (hitTime - origin.getTime())
			//						+ " Origin: " + origin.getLocation() + " OT: "
			//						+ origin.getTime());
			//			}
			//			locs[i] = loc;
		}
		//		for (int i = 0; i < list.size(); ++i) {
		//			Point2D.Double t = (Double) list.get(i);
		//			Debug.println(i + " " + t);
		//		}
		//		mRankHitCounter.show();
		//TODO ��� ��ģ��.
		// TODO ���Ļ��� Ȯ��
		// TODO ���ϰ� ����
		return new ProphetResultOfCP(this, mTarget, hitTime, (Double[]) list
				.toArray(new Point2D.Double[0]), stat, origin);
	}
	/**
	 * @param loc
	 */
	private boolean isTargetCanGo(Point2D.Double loc, long hitTime,
			double bulletVelocity) {
		//		Debug.println("BV : " + bulletVelocity);
		if (!MathUtil.IsInBattleField(loc)) {
			//			Debug.println("Cant go : Out OF Field");
			return false;
		}
		//		long deltaTick = Math.abs(hitTime - GameInfo.getTime());
		//		double canDistance = deltaTick * MAX_ROBO_VELOCITY;
		//		double deltaAng = Math.abs(MathUtil.relativeDegrees(MathUtil
		//				.DirectionFormTo(mTarget.getLocation(), loc)
		//				- mTarget.getMovingDirection()));
		//		double theta = Math.toDegrees(Math.asin(8 / bulletVelocity));
		double ang = Math.abs(MathUtil.relativeDegrees(mTarget.getAbsBearing()
				- MathUtil.DirectionFormTo(MyInfo.getLocation(), loc)));
		if (ang > 45) {
			//			Debug.println("Cant go : Out OF ANG");
			return false;
		}
		//		if (deltaAng < 90) {
		//			canDistance -= 100;
		//// Debug.println("Cant go : B Delta Limit Out");
		//		}
		//		double gap = MathUtil.Distance(mTarget.getLocation(), loc);
		//		// Debug.print(" GAP: " + gap + " canD: " + canDistance );
		//		if (gap > canDistance) {
		//// Debug.println("Cant go : B");
		//			// Debug.println("FALSE");
		//			return false;
		//		}
		//		Debug.println("TRUE");
		return true;
	} /*
	   * (non-Javadoc)
	   * 
	   * @see hwandan.prophet.Prophet#reportHitTarget(boolean, long)
	   */
	public void reportHitTarget(boolean ishit, long firedTime) {
	}
}
