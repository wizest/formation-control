/*
 * Created on 2004. 5. 26.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.prophet;
import java.awt.geom.Point2D;
import newage.infomation.EnemyInfo;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
/**
 * @author Ȳ�ؽ�
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public abstract class Prophet {
	EnemyInfo mTarget;
	public Prophet(EnemyInfo target) {
		mTarget = target;
	}
	public abstract String getProphetMethodeCode();
	public ProphetResult getProphetResults(long hitTime, double bulletVelocity) {
		hitTime = GameInfo.getTime() + 10;
		long travelTime = 10;
		Point2D.Double[] loc = new Point2D.Double[1];
		if (mTarget.getDistanceFromMe() < 60) {
			loc[0] = MathUtil.Project(mTarget.getLocation(), mTarget
					.getHeading(), mTarget.getVelocity());
		} else if (mTarget.getDistanceFromMe() < 110) {
			double tmpV = mTarget.getVelocity() * 0.65;
			loc[0] = MathUtil.Project(mTarget.getLocation(), mTarget
					.getHeading(), tmpV * travelTime);
		} else
			return null;
		return new ProphetResult(this, mTarget, hitTime, loc);
	}
	public abstract void reportHitTarget(boolean ishit, long firedTime);
	public abstract void feedBack(ProphetResult result);
}
