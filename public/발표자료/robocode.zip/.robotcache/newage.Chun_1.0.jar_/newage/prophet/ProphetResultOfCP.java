/*
 * Created on 2004. 6. 25.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.prophet;
import newage.debug.Debug;
import newage.infomation.EnemyInfo;
import newage.infomation.EnemyInfo.Record;
import java.awt.geom.Point2D.Double;
/**
 * @author user
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class ProphetResultOfCP extends ProphetResult {
	EnemyInfo.Record mOriginRecord;
	StatisticsOfCP mStatistics;
	public ProphetResultOfCP(Prophet prophet, EnemyInfo target, long hittime,
			Double[] locs, StatisticsOfCP stat, Record origin) {
		super(prophet, target, hittime, locs);
		mOriginRecord = origin;
		mStatistics = stat;
	}
	/**
	 * @return Returns the originRecord.
	 */
	public EnemyInfo.Record getOriginRecord() {
		return mOriginRecord;
	}
	/**
	 * @return Returns the statistics.
	 */
	public StatisticsOfCP getStatistics() {
		return mStatistics;
	}
}
