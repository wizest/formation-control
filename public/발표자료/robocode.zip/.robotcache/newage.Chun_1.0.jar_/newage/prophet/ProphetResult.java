/*
 * Created on 2004. 5. 26.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.prophet;
import newage.debug.Debug;
import newage.infomation.EnemyInfo;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
/**
 * @author Ȳ�ؽ�
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class ProphetResult {
	private long mHitTime;
	//	private String mMethodName;
	Point2D.Double[] mLocations;
	EnemyInfo mTarget;
	Prophet mProphet;
	public ProphetResult(Prophet prophet, EnemyInfo target, long hittime,
			Double[] locs) {
		mHitTime = hittime;
		mProphet = prophet;
		mLocations = locs;
		mTarget = target;
	}
	public void feedBack() {
		mProphet.feedBack(this);
	}
	public Point2D.Double getLocation(int i) {
		if (i < mLocations.length)
			return mLocations[i];
		Debug.println("Loc Len: " + mLocations.length + "   Call i: " + i);
		return null;
	}
	public long getHitTime() {
		return mHitTime;
	}
	public int size() {
		return mLocations.length;
	}
	/**
	 * @return
	 */
	public boolean isEmpty() {
		return mLocations.length == 0;
	}
	/**
	 * @return Returns the target.
	 */
	public EnemyInfo getTarget() {
		return mTarget;
	}
}
