/*
 * Created on 2004. 6. 23.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.driver;
import newage.debug.Debug;
import newage.infomation.EnemyInfo;
import newage.infomation.EnemyInfoManager;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
import newage.utility.MyInfo;
import java.awt.geom.Point2D;
import java.text.DecimalFormat;
import java.util.ArrayList;
/**
 * @author user
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class DriveStatistics {
	private class StatisticsData {
		private int cnt;
		private double factor;
		private double mMinDistanceToCrash;
		private boolean mRestricted;
		private double mDistanceToCrashWall;
		public StatisticsData() {
			cnt = 0;
			mMinDistanceToCrash = Double.MAX_VALUE;
			factor = 0;
		}
		public void addEnemy(EnemyInfo info, double increment) {
			double distance = info.getDistanceFromMe();
			if (distance < mMinDistanceToCrash) {
				setMinDistanceToCrash(distance);
			}
			cnt++;
			increseFactor(increment);
		}
		public void addSplashEnemy(EnemyInfo info, double increment) {
			double distance = info.getDistanceFromMe();
			//			double increment = Math.pow(info.getEnergy() /
			// MyInfo.getEnergy()
			//					* 10, 1.3)
			//					/ distance * 100 * factor;
			increseFactor(increment);
		}
		private void increseFactor(double increment) {
			if (!mRestricted) {
				factor += increment;
				mSum += increment;
			}
		}
		//		public boolean isDeadArea() {
		//			double limit = 300;// �������̸� �� �پ�� �ҵ�..
		//			if (mMinDistanceToCrash < limit)
		//				return true;
		//			return false;
		//		}
		public boolean isHigherAver() {
			//			Debug.println("" + factor + " " + mAverFactor);
			return factor > getAverageFactor();
		}
		/**
		 * @return Returns the restricted.
		 */
		public boolean isRestricted() {
			return mRestricted;
		}
		public void setRestricted(boolean restricted) {
			if (!mRestricted) {
				++mRestirtCnt;
				mRestricted = restricted;
				mSum -= factor;
				factor = 0;
			}
		}
		/**
		 * @return Returns the minDistanceToCrash.
		 */
		public double getMinDistanceToCrash() {
			return mMinDistanceToCrash;
		}
		/**
		 * @param minDistanceToCrash
		 *            The minDistanceToCrash to set.
		 */
		public void setMinDistanceToCrash(double minDistanceToCrash) {
			mMinDistanceToCrash = minDistanceToCrash;
		}
		/**
		 * @return
		 */
		public boolean isRoadToDeath() {
			if (GameInfo.getOthers() == 1) {
				if (cnt != 0)
					return true;
			} else {
				if (mMinDistanceToCrash < 200)
					return true;
			}
			return false;
		}
		/**
		 * @param left
		 */
		public void setMinDistanceToCrashWall(double dist) {
			mDistanceToCrashWall = dist;
		}
	}
	private final int Bottom = 0x08;
	StatisticsData[] mDatas;
	private final int Left = 0x02;
	//	double mAverFactor;
	final double mCornerLimit = 250;
	int mSliceCnt;
	double mThetaPerSlice;
	//	final double mWallLimit = 50;
	//	boolean mWallSmooth;
	private final int Right = 0x01;
	private double mSum;
	private final int Top = 0x04;
	private static double[] mWallAvoid;
	private static double[] mWallAvoidAngLimit;
	private static final double[] mWallAvoidM = new double[]{120, 90, 60, 30};
	private static final double[] mWallAvoidAngLimitM = new double[]{45, 60,
			75, 90};
	private static final double[] mWallAvoidS = new double[]{200, 140, 100, 60};
	private static final double[] mWallAvoidAngLimitS = new double[]{30, 45,
			70, 90};
	int mRestirtCnt = 0;
	public DriveStatistics(EnemyInfoManager enemyInfoManager, int sliceCnt) {
		if (GameInfo.getOthers() == 1) {
			mWallAvoid = mWallAvoidS;
			mWallAvoidAngLimit = mWallAvoidAngLimitS;
		} else {
			mWallAvoid = mWallAvoidM;
			mWallAvoidAngLimit = mWallAvoidAngLimitM;
		}
		mSliceCnt = sliceCnt;
		mThetaPerSlice = 360.0 / sliceCnt;
		mDatas = new StatisticsData[mSliceCnt];
		mSum = 0;
		EnemyInfo[] infos = enemyInfoManager.getEnemiesArray();
		initDatas();
		setWallAvoidance();
		for (int i = 0; i < infos.length; ++i) {
			if (infos[i].isAlive()) {
				addEnemyFactors(infos[i]);
			}
		}
		//		DecimalFormat f = new DecimalFormat("##.#########");
		//		Debug.println("Factor Aver : " + f.format(mAverFactor));
	}
	/**
	 * @param infos
	 * @param i
	 */
	private void addEnemyFactors(EnemyInfo info) {
		int index = getIndexFromABSAngle(info.getAbsBearing());
		//TODO Extract Increment
		double limitAng = 45;
		double distance = info.getDistanceFromMe();
		double delta = 0;
		double multi = 1;
		//		Debug.println("enemy: " + index);
		//		if (GameInfo.getOthers() == 1) {
		//			multi = 100;
		//		}
		int limit = 0;
		if (distance < 300) {
			limitAng = 130;
			limit = getIndexFromABSAngle(limitAng);
			delta = 1.0 / (limit + 1) / 3;
			//			Debug.println("delta1 : " + delta+ " Lim: " + limit);
		} else if (distance < 700) {
			limitAng = 70;
			limit = getIndexFromABSAngle(limitAng);
			delta = 1.0 / (1 + limit) / 2;
			//			Debug.println("delta2 : " + delta+ " Lim: " + limit);
		} else {
			limitAng = 30;
			limit = getIndexFromABSAngle(limitAng);
			delta = 1.0 / (1 + limit);
			//			Debug.println("delta3 : " + delta + " Lim: " + limit);
		}
		//		Debug.println("DIST : " + distance + "delta : " + delta);
		int pSide = index, nSide = index;
		double increment = extractincrement(info);
		mDatas[index].addEnemy(info, increment);
		for (int i = 0, k = 0; i < limit; ++i) {
			k++;
			pSide = getPreIndex(pSide);
			nSide = getNextIndex(nSide);
			//			Debug.println("P: " + pSide + " N: " + nSide);
			double tmp = increment * Math.max(0.1, 1 - k * delta);
			mDatas[pSide].addSplashEnemy(info, tmp);
			mDatas[nSide].addSplashEnemy(info, tmp);
			//			Debug.println("Factor : " + Math.max(0.1, 1 - k * delta));
		}
		int from = getIndexFromABSAngle(info.getAbsBearing() + 180 - 45);
		int to = getIndexFromABSAngle(info.getAbsBearing() + 180 + 45);
		// ����� �� ����ġ.
		for (int i = from; i != to; i = getNextIndex(i)) {
			//			datas[i].setRestricted(true);
			mDatas[i].addSplashEnemy(info, 0.7);
		}
		mDatas[to].addSplashEnemy(info, 0.7);
		//		datas[to].setRestricted(true);
		int rIndex = getReversIndex(index);
		mDatas[rIndex].addSplashEnemy(info, 0.3);
	}
	/**
	 * @param info
	 */
	private double extractincrement(EnemyInfo info) {
		double distance = info.getDistanceFromMe();
		return Math.pow(info.getEnergy() / MyInfo.getEnergy() * 10, 1.3)
				/ distance * 100;
	}
	public int getIndexFromABSAngle(double angle) {
		int result = (int) (MathUtil
				.AbsoluteDegrees(angle + mThetaPerSlice / 2) / mThetaPerSlice);
		result %= mSliceCnt;
		return result;
	}
	private int getNextIndex(int index) {
		int result = index + 1;
		if (result >= mSliceCnt) {
			result = result % mSliceCnt;
		}
		return result;
	}
	private int getPreIndex(int index) {
		int result = index - 1;
		if (result < 0)
			result = (result + mSliceCnt) % mSliceCnt;
		return result;
	}
	private int getReversIndex(int index) {
		int result = index + mSliceCnt / 2;
		if (result >= mSliceCnt) {
			result = result % mSliceCnt;
		}
		return result;
	}
	public double getRandomDirectionInRandom() {
		int cnt = 0;
		int dir = 0;
		do {
			dir = (int) (Math.random() * mSliceCnt);
			if (dir == mSliceCnt) {
				dir = mSliceCnt - 1;
			}
			cnt++;
			if (cnt > 300) {
				show();
				for (int i = 0; i < 30; ++i) {
					Debug.println("Can't Choose. In " + cnt
							+ " try.. fail. DEBUG!!!!!!! IT is CRITICAL");
				}
				break;
			}
			if (getRestirtCnt() == mSliceCnt) {
				Debug.println("************ ALL RESTRICT ************");
				show();
			}
		} while (isCriticalDirection(dir));
		//		for (int i = 0; i < datas.length; ++i) {
		//			DecimalFormat f = new DecimalFormat("#.#####");
		//			if (!datas[i].isRestricted())
		//				Debug.print(i + ": " + f.format(datas[i].factor) + " ");
		//		}
		//		Debug.println(dir + "selected " + mThetaPerSlice);
		return getAbsDirectionFromIndex(dir);
	}
	/**
	 * @param dir
	 * @return
	 */
	private boolean isCriticalDirection(int dir) {
		return mDatas[dir].isRestricted() || isMayBeCrash(dir)
				|| mDatas[dir].isHigherAver();
	}
	/**
	 * @param dir
	 * @return
	 */
	private double getAbsDirectionFromIndex(int dir) {
		return dir * mThetaPerSlice;
	}
	private void initDatas() {
		for (int i = 0; i < mDatas.length; ++i) {
			mDatas[i] = new StatisticsData();
		}
	}
	//	public boolean isDangerous(double direction) {
	//		int dir = (int) (MathUtil.AbsoluteDegrees(direction + mThetaPerSlice
	//				/ 2) / mThetaPerSlice);
	//		if (mDatas[dir].isDeadArea() || mDatas[dir].isRestricted()) {
	//			if (mDatas[dir].isDeadArea() || mDatas[dir].isHigherAver()
	//					|| mDatas[dir].isRestricted()) {
	//				if (mDatas[dir].isDeadArea() || mDatas[dir].isRestricted()) {
	//					Debug.println("TIME: " + GameInfo.getTime() + " restic "
	//							+ mDatas[dir].isRestricted() + " dead "
	//							+ mDatas[dir].isDeadArea());
	//				}
	//				if (mDatas[dir].isHigherAver()) {
	//					Debug.println(" averHigh " + mDatas[dir].isHigherAver()
	//							+ " aver : " + getAverageFactor() + " dirs "
	//							+ mDatas[dir].factor);
	//				}
	//			}
	//		}
	//		return (mDatas[dir].isDeadArea() || mDatas[dir].isRestricted());
	//	}
	//	private boolean isSafeArea(int dir) {
	//		// Debug.println(datas[dir].isDeadArea() + " " +
	//		// datas[dir].isHigherAver());
	//		return !mDatas[dir].isDeadArea() && !mDatas[dir].isHigherAver()
	//				&& !mDatas[dir].isRestricted();
	//	}
	//	public
	/**
	 * @return Returns the wallSmooth.
	 */
	//	public boolean isWallSmooth() {
	//		return mWallSmooth;
	//	}
	private int getNearCorner() {
		int zone = 0;
		Point2D.Double loc = MyInfo.getLocation();
		if (loc.getX() < GameInfo.getBattleW() / 2) {
			zone |= Left;
		} else {
			zone |= Right;
		}
		if (loc.getY() < GameInfo.getBattleH() / 2) {
			zone |= Bottom;
		} else {
			zone |= Top;
		}
		return zone;
	}
	private int getDangCorner() {
		int zone = 0;
		//		Debug.print("SET ZONE IN CORNER!! ");
		double x = 0, y = 0;
		String str = "";
		zone = getNearCorner();
		Point2D.Double loc = MyInfo.getLocation();
		switch (zone) {
			case (Left | Top) :
				str = "LT - 3";
				x = loc.getX();
				y = GameInfo.getBattleH() - loc.getY();
				break;
			case (Left | Bottom) :
				str = "LB - 2";
				x = loc.getX();
				y = loc.getY();
				break;
			case (Right | Top) :
				str = "RT - 0";
				x = GameInfo.getBattleW() - loc.getX();
				y = GameInfo.getBattleH() - loc.getY();
				break;
			case (Right | Bottom) :
				str = "RB - 1";
				x = GameInfo.getBattleW() - loc.getX();
				y = loc.getY();
				break;
		}
		double distance = x + y;
		//		Debug.println(" dist To corner " + distance + " X,Y " );
		if (distance < mCornerLimit) {
			return zone;
		}
		return 0;
	}
	private boolean setRestrictForAvoidCorner() {
		int zone = 0;
		boolean result = false;
		//		Debug.print("SET ZONE IN CORNER!! ");
		double x = 0, y = 0;
		String str = "";
		zone = getDangCorner();
		//			Debug.println("AVOID " + str);
		//			setRestrictForAvoidCorner(zone);
		int index = 0;
		int from = 0;
		int to = 0;
		//		Debug.print("Zone: " + zone+" ");
		result = true;
		switch (zone) {
			case (Left | Top) :
				from = getIndexFromABSAngle(225);
				to = getIndexFromABSAngle(45);
				str = "L-T";
				//			from = getNextIndex(getIndexFromABSAngle(225));
				//			to = getPreIndex(getIndexFromABSAngle(45));
				setRestrictFromTo(from, to);
				break;
			case (Left | Bottom) :
				from = getIndexFromABSAngle(135);
				to = getIndexFromABSAngle(315);
				//				from = getNextIndex(getIndexFromABSAngle(135));
				//				to = getPreIndex(getIndexFromABSAngle(315));
				str = "L-B";
				setRestrictFromTo(from, to);
				break;
			case (Right | Top) :
				str = "R-T";
				from = getIndexFromABSAngle(315);
				to = getIndexFromABSAngle(135);
				//				from = getNextIndex(getIndexFromABSAngle(315));
				//				to = getPreIndex(getIndexFromABSAngle(135));
				setRestrictFromTo(from, to);
				break;
			case (Right | Bottom) :
				str = "R-B";
				from = getIndexFromABSAngle(45);
				to = getIndexFromABSAngle(225);
				//				from = getNextIndex(getIndexFromABSAngle(45));
				//				to = getPreIndex(getIndexFromABSAngle(225));
				setRestrictFromTo(from, to);
				break;
			default :
				result = false;
		}
		if (result) {
			//			Debug.println("Corner " + str);
		}
		return result;
	}
	private void setWallAvoidance() {
		//		Debug.println("TIME: " + GameInfo.getTime());
		setDistanceToWall();
		setRestrictForAvoidCorner();
		setRestrictForAvoidWall();
	}
	/**
	 *  
	 */
	private void setDistanceToWall() {
		Point2D.Double loc = MyInfo.getLocation();
		double left = loc.getX();
		double right = GameInfo.getBattleW() - loc.getX();
		double top = GameInfo.getBattleH() - loc.getY();
		double bottom = loc.getY();
		mDatas[getIndexFromABSAngle(0)].setMinDistanceToCrashWall(top);
		mDatas[getIndexFromABSAngle(90)].setMinDistanceToCrashWall(right);
		mDatas[getIndexFromABSAngle(180)].setMinDistanceToCrashWall(bottom);
		mDatas[getIndexFromABSAngle(270)].setMinDistanceToCrashWall(left);
	}
	/**
	 * @param from
	 * @param to
	 */
	private void setRestrictFromTo(int from, int to) {
		setRestrictFromTo(from, to, true);
	}
	private void setRestrictFromTo(int from, int to, boolean test) {
		//		if (test) {
		//			if (!isOkRestrictFromTo(from, to)) {
		//			}
		//			return;
		//		}
		//		Debug.println("Restirct F: " + from + " T: " + to);
		for (int i = from; i != to; i = getNextIndex(i)) {
			//			Debug.println(i + " Restrict");
			mDatas[i].setRestricted(true);
		}
		mDatas[to].setRestricted(true);
		//		Debug.println(" Setted");
	}
	/**
	 * @param from
	 * @param to
	 * @return
	 */
	private boolean isOkRestrictFromTo(int from, int to) {
		ArrayList list = new ArrayList();
		for (int i = 0; i < mDatas.length; ++i) {
			if (!isCriticalDirection(i)) {
				list.add("" + i);
			}
		}
		for (int i = from; i != to; i = getNextIndex(i)) {
			list.remove("" + i);
		}
		list.remove("" + to);
		return !list.isEmpty();
	}
	public void show() {
		Debug.println("SHOW");
		Debug.println("Factors :   Aver : " + getAverageFactor());
		DecimalFormat f = new DecimalFormat("#.####");
		for (int i = 0; i < mDatas.length; ++i) {
			Debug.print(i + ":  " + f.format(mDatas[i].factor) + " "
					+ "Restrict " + isRestirct(i) + " CRI: "
					+ isCriticalDirection(i) + "   ");
			if (i % 4 == 0)
				Debug.println(" ");
		}
		Debug.println(" end");
	}
	/**
	 * @param left2
	 */
	//	private void setRestrictForAvoidWall(int zone) {
	//		// mWallSmooth = true;
	//		double angle = 0;
	//		int from = 0, to = 0;
	//		String str = "";
	//		switch (zone) {
	//			case Left :
	//				str = "LEFT";
	//				from = getNextIndex(getIndexFromABSAngle(180));
	//				to = getPreIndex(getIndexFromABSAngle(0));
	//				break;
	//			case Right :
	//				str = "Right";
	//				from = getNextIndex(getIndexFromABSAngle(0));
	//				to = getPreIndex(getIndexFromABSAngle(180));
	//				break;
	//			case Top :
	//				str = "TOP";
	//				from = getNextIndex(getIndexFromABSAngle(270));
	//				to = getPreIndex(getIndexFromABSAngle(90));
	//				break;
	//			case Bottom :
	//				str = "BOTTOM";
	//				from = getNextIndex(getIndexFromABSAngle(90));
	//				to = getPreIndex(getIndexFromABSAngle(270));
	//				break;
	//		}
	//		// Debug.print("Zone: " + str+" ");
	//		setRestrictFromTo(from, to);
	//	}
	private void setRestrictForAvoidWall() {
		Point2D.Double loc = MyInfo.getLocation();
		//		int wallDirect = 0;
		//		double angle = 0;
		int from = 0, to = 0;
		String str = "";
		boolean doRestirct = false;
		int cnt = 0;
		if (loc.getX() < mWallAvoid[0]) {
			//			setRestrictForAvoidWall(Left);
			doRestirct = true;
			str = "LEFT";
			for (int i = 0; i < mWallAvoid.length; ++i) {
				if (loc.getX() < mWallAvoid[i]) {
					cnt++;
					//			setRestrictForAvoidWall(Left);
					from = getNextIndex(getIndexFromABSAngle(270 - mWallAvoidAngLimit[i]));
					to = getPreIndex(getIndexFromABSAngle(270 + mWallAvoidAngLimit[i]));
				}
			}
			setRestrictFromTo(from, to);
			//			Debug.println(str + " Restrict");
		} else if (loc.getX() > GameInfo.getBattleW() - mWallAvoid[0]) {
			//			setRestrictForAvoidWall(Right);
			str = "RIGHT";
			doRestirct = true;
			for (int i = 0; i < mWallAvoid.length; ++i) {
				if (GameInfo.getBattleW() - loc.getX() < mWallAvoid[i]) {
					//			setRestrictForAvoidWall(Left);
					cnt++;
					from = getNextIndex(getIndexFromABSAngle(90 - mWallAvoidAngLimit[i]));
					to = getPreIndex(getIndexFromABSAngle(90 + mWallAvoidAngLimit[i]));
				}
			}
			setRestrictFromTo(from, to);
			//			Debug.println(str + " Restrict");
		}
		//		Debug.println(str + " Restrict " + cnt);
		cnt = 0;
		if (loc.getY() < mWallAvoid[0]) {
			//			setRestrictForAvoidWall(Left);
			doRestirct = true;
			str = "BOTTOM";
			for (int i = 0; i < mWallAvoid.length; ++i) {
				if (loc.getY() < mWallAvoid[i]) {
					cnt++;
					//			setRestrictForAvoidWall(Left);
					from = getNextIndex(getIndexFromABSAngle(180 - mWallAvoidAngLimit[i]));
					to = getPreIndex(getIndexFromABSAngle(180 + mWallAvoidAngLimit[i]));
				}
			}
			setRestrictFromTo(from, to);
			//			Debug.println(str + " Restrict");
		} else if (loc.getY() > GameInfo.getBattleH() - mWallAvoid[0]) {
			//			setRestrictForAvoidWall(Right);
			str = "TOP";
			doRestirct = true;
			for (int i = 0; i < mWallAvoid.length; ++i) {
				if (GameInfo.getBattleH() - loc.getY() < mWallAvoid[i]) {
					cnt++;
					//			setRestrictForAvoidWall(Left);
					from = getNextIndex(getIndexFromABSAngle(-mWallAvoidAngLimit[i]));
					to = getPreIndex(getIndexFromABSAngle(mWallAvoidAngLimit[i]));
				}
			}
			setRestrictFromTo(from, to);
		}
		//		Debug.println(str + " Restrict " + cnt);
	}
	/**
	 * @param d
	 * @param i
	 */
	public void increaseFactorsInRange(double direction, int theta) {
		int from = getIndexFromABSAngle(direction - theta);
		int to = getIndexFromABSAngle(direction + theta);
		//		Debug.println("from: " + from + " to: " + to);
		double addtion = getAverageFactor();
		for (int i = from; i != to; i = getNextIndex(i)) {
			mDatas[i].increseFactor(addtion);
		}
		mDatas[to].increseFactor(addtion);
	}
	/**
	 *  
	 */
	public void reverseControl(double direction) {
		double theta = 90;
		int from = getIndexFromABSAngle(direction - theta);
		int to = getIndexFromABSAngle(direction + theta);
		//		Debug.println("from: " + from + " to: " + to);
		//		double addtion = mAverFactor * 2;
		//		setRestrictFromTo(from, to);
		increaseFactorsInRange(from, to);
		//		for (int i = from; i != to; i = getNextIndex(i)) {
		//			datas[i].setRestricted(true);
		//		}
		//		datas[to].setRestricted(true);
	}
	/**
	 * @return Returns the averFactor.
	 */
	public double getAverageFactor() {
		return mSum / (mSliceCnt - mRestirtCnt);
	}
	/**
	 * @return Returns the restirtCnt.
	 */
	public int getRestirtCnt() {
		return mRestirtCnt;
	}
	/**
	 * @param direction
	 * @return
	 */
	public boolean isMayBeCrash(double direction) {
		int dirNum = getIndexFromABSAngle(direction);
		return isMayBeCrash(dirNum, 130);
	}
	public boolean isMayBeCrash(int dirNum) {
		return isMayBeCrash(dirNum, 130);
	}
	
	public boolean isMayBeCrash(int dirNum, double limit) {
		if (mDatas[dirNum].getMinDistanceToCrash() < limit) {
			//			Debug.println("crash " + dirNum + " DISTTO: "
			//					+ mDatas[dirNum].getMinDistanceToCrash());
			return true;
		}
		return false;
	}

	public boolean isRestirct(double direction) {
		return mDatas[getIndexFromABSAngle(direction)].isRestricted();
	}
	/**
	 * @return
	 */
	public boolean isMayBeInCorner(double direction) {
		int zone = getDangCorner();
		if (zone == 0) {
			return false;
		}
		double baseAng = 0;
		switch (zone) {
			case (Left | Top) :
				baseAng = 315;
				break;
			case (Left | Bottom) :
				baseAng = 225;
				break;
			case (Right | Top) :
				baseAng = 45;
				break;
			case (Right | Bottom) :
				baseAng = 135;
				break;
		}
		if (Math.abs(MathUtil.relativeDegrees(direction - baseAng)) < 90) {
			//			Debug.println("May Corner: " + zone);
			return true;
		}
		return false;
	}
	/**
	 * @return
	 */
	public boolean isRoadToDeath(double direct) {
		int limitAng = 0;
		if (GameInfo.getOthers() == 1) {
			limitAng = 30;
		} else {
			limitAng = 25;
		}
		int begin = getIndexFromABSAngle(direct - limitAng);
		int end = getIndexFromABSAngle(direct + limitAng);
		for (int i = begin; i != end; i = getNextIndex(i)) {
			if (mDatas[i].isRoadToDeath()) {
				return true;
			}
		}
		return mDatas[end].isRoadToDeath();
	}
}
