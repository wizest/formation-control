/*
 * Created on 2004. 6. 23.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package newage.driver;
import java.awt.geom.Point2D;
import newage.Chun;
import newage.debug.Debug;
import newage.infomation.EnemyInfoManager;
import newage.utility.GameInfo;
import newage.utility.MathUtil;
import newage.utility.MyInfo;
import robocode.AdvancedRobot;
/**
 * @author user
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class Driver {
	double[] cnt;
	long mChangTick, mStopTick;
	double mDirection;
	double mDistance;
	EnemyInfoManager mEnemyInfoManager;
	double mFullMovement;
	long mHandlingTick;
	private boolean mOnReverse;
	//	boolean mReverseControl = false;
//	ReverseObserver mReverseObserver;
	AdvancedRobot mRobot;
	boolean setMove = false;
	private long mChangFullTick;
	private long mChangBaseTick;
	private double mBaseMovement;
	boolean handling;
	boolean forwording;
	public Driver(Chun robo) {
//		mReverseObserver = new ReverseObserver();
		//		mMode = ZIG;
		mRobot = robo;
		mEnemyInfoManager = robo.getEnemyInfoManager();
		initAtRoundStart();
		mStopTick = 5;
		mFullMovement = GameInfo.getBattleH() / 5;
		mBaseMovement = 20;
	}
	public void drive() {
		double rate = MyInfo.getSpaceUsability();
		handling = false;
		if (MyInfo.getEnergy() < 0.001) {
			return;
		}
		if (mChangFullTick < GameInfo.getTime()) {
			resetFullMovement();
		}
		if (mChangBaseTick < GameInfo.getTime()) {
			resetBaseMovement();
		}
		DriveStatistics st = new DriveStatistics(mEnemyInfoManager, 24);
		if (mRobot.getDistanceRemaining() == 0) {
			setMove = false;
			forwording = false;
			if (Math.random() < 0.3) {
				mStopTick = (long) (GameInfo.getTime() + 10 * Math.random());
			}
		}
		if (rate < 0.25) {
			forwording = true;
		}
		if (st.isRestirct(mDirection)) {
			setMove = false;
			if (mRobot.getDistanceRemaining() / mDistance > 0.1) {
				st.reverseControl(MyInfo.getReverseMovingDiroection());
				handling = true;
			}
		}
		if (st.isRoadToDeath(MyInfo.getMovingDirection())) {
			handling = true;
			setMove = false;
		}
		if (isNeedWallSmooth()) {
			mRobot.setMaxVelocity(getVelocityForWallSmooth());
		} else {
			mRobot.setMaxVelocity(8);
		}
		if (mStopTick > GameInfo.getTime()) {
			mRobot.setMaxVelocity(0);
		}
//		st.show();
		if (!setMove) {
			mDirection = st.getRandomDirectionInRandom();
			if (!handling) {
				mDistance = Math.random() * mFullMovement + mBaseMovement;
			} else {
				mDirection = st.getRandomDirectionInRandom();
				mDistance = mRobot.getDistanceRemaining();
			}
			if (forwording) {
				mDistance *= 1 + Math.random();
			}
//			mReverseObserver.addHistory(mDirection, mDistance);
			setMove = true;
			driveTo(mDirection, mDistance);
		}
//		Debug.println(setMove + " h " + handling + " f " + forwording
//				+ "  Dist " + mDistance + "   md: " + mDirection);
	}
	/**
	 *  
	 */
	private void resetBaseMovement() {
		mBaseMovement = 80 * Math.random() + 20;
		mChangBaseTick = (long) (GameInfo.getTime() + 10 + 20 * Math.random());
	}
	/**
	 *  
	 */
	private void resetFullMovement() {
		mFullMovement = GameInfo.getBattleW() / 3 * (0.3 + Math.random());
		mChangFullTick = (long) (GameInfo.getTime() + 20 + 50 * Math.random());
	}
	private void driveTo(double direction, double dist) {
		//		Debug.println("TIME: " + GameInfo.getTime() + "Move - Direction: "
		//				+ direction + " distance: " + dist);
		double turnHeading;
		turnHeading = MathUtil.relativeDegrees(direction - MyInfo.getHeading());
		int forword = 1;
		if (turnHeading > 90) {
			turnHeading -= 180;
			forword = -1;
		} else if (turnHeading < -90) {
			turnHeading += 180;
			forword = -1;
		}
		dist *= forword;
		//		Debug.println("DRIVE TO");
		mRobot.setTurnRight(turnHeading);
		mRobot.setAhead(dist);
	}
	/**
	 * @param d
	 * @return
	 */
	private double getDistanceToHitWall(double direct) {
		direct = MathUtil.AbsoluteDegrees(direct);
		Point2D.Double loc = MyInfo.getLocation();
		double theta = 0, distance = 0;
		double limit = 35;
		if (direct > 315 || direct <= 45) { //TOP
			theta = Math.abs(MathUtil.relativeDegrees(direct));
			distance = GameInfo.getBattleH() - loc.getY() - limit;
		} else if (direct > 45 && direct <= 135) {//LEFT
			theta = Math.abs(MathUtil.relativeDegrees(direct - 90));
			distance = GameInfo.getBattleW() - loc.getX() - limit;
		} else if (direct > 135 && direct <= 225) {//BOTTOM
			theta = Math.abs(MathUtil.relativeDegrees(direct - 180));
			distance = loc.getY() - limit;
		} else if (direct > 225 && direct <= 315) {//RIGHT
			theta = Math.abs(MathUtil.relativeDegrees(direct - 270));
			distance = loc.getX() - limit;
		}
		return distance / Math.cos(Math.toRadians(theta));
	}
	/**
	 * @return
	 */
	private double getVelocityForWallSmooth() {
		double dist = getDistanceToHitWall(MyInfo.getMovingDirection());
		//		double tmp = MyInfo.getHeading() % 90;
		//		double distToCrash = dist / Math.cos(Math.toRadians(tmp));
		double deltaAng = Math.abs(MathUtil.relativeDegrees(MyInfo
				.getMovingDirection()
				- mDirection));
		if (deltaAng >= 90) {
			//			Debug.print("distTOWALL " + dist + " DeltaANG " + deltaAng);
			return 6;
		}
		double turnRate = MathUtil.TurnRateByVelocity(MyInfo.getVelocity());
		long timeToTurning = (long) (deltaAng / turnRate);
		//		Debug.print("distTOWALL " + dist + " DeltaANG " + deltaAng + " Limit
		// "
		//				+ (dist / timeToTurning));
		//		Debug.println(" myH: " + MyInfo.getHeading() + " mToH: " +
		// mDirection);
		if (timeToTurning == 0)
			return 7;
		//		Math.max(0, dist / timeToTurning)
		return Math.max(0, dist / timeToTurning - 0.5);
	}
	/**
	 *  
	 */
	public void initAtRoundStart() {
		resetFullMovement();
		resetBaseMovement();
		mStopTick = 0;
		handling = false;
		forwording = false;
	}
	/**
	 * @return
	 */
	private boolean isNeedWallSmooth() {
		double dist = getDistanceToHitWall(MyInfo.getMovingDirection());
		//		Debug.println("Dist To Wall " + dist);
		if (dist < 150)
			return true;
		return false;
	}
	//	public void onHitByBullet() {
	//		resetBaseMovement();
	//		resetFullMovement();
	//		if (MyInfo.getVelocity() > 0)
	//			mRobot.back(20);
	//		else
	//			mRobot.ahead(20);
	//		setMove = false;
	//		handling = true;
	//	}
	//	private void resetChangeTick() {
	//		// if (mReverseControl) {
	//		// mChangTick = (long) (GameInfo.getTime() + 20 + Math.random() * 40);
	//		// } else
	//		if (mReverseObserver.isMoreReverse()) {
	//			mReverseControl = true;
	//			mChangTick = (long) (GameInfo.getTime() + Math.random() * 10);
	//		} else {
	//			mChangTick = (long) (GameInfo.getTime() + 10 + Math.random() * 20);
	//		}
	//		// Debug.println("ResetTime: " + mChangTick);
	//	}
}
