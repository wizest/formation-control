package fangs.tactician;

import java.awt.geom.Point2D;

import fangs.FangR;
import fangs.Shooter;
import fangs.driver.Driver;
import fangs.enemy.EnemyInfo;
import fangs.gravpoint.GravPointManager;
import fangs.predict.GunPowerSelector;
import fangs.predict.PredictorManager;
import fangs.utility.GameInfo;
import fangs.utility.MyInfo;
import fangs.utility.Debug;
public class Tactician {
	private int _timerRemain = -1;
	static EnemyInfo _target;
	private int _oldj = -1;
	private int _oldi = -1;
	int countRemakeLead = -1;

	PredictorManager _predictormgr;	
	GravPointManager _gpmgr;
	private Driver _dirver;

	public Tactician(FangR fang) {
		_predictormgr = FangR.predictormgr;		
		_gpmgr = FangR.gravpointmgr;
		_dirver = fang.get_driver();
	}

	public void selectTarget() {
		EnemyInfo[] enemies = FangR.enemymgr.getEnemiesArray();
		EnemyInfo tmpEnemy = null;
		_target = null;
		double dist = 99999;
		for (int i = 0; i < enemies.length; i++) {
			tmpEnemy = enemies[i];
			if (tmpEnemy.isAlive()) {
				if (tmpEnemy.getDistance() < dist) {
					_target = tmpEnemy;
					dist = tmpEnemy.getDistance();
				}
			}
		}
	}

	public void makeplan() {

		if (isMelee()) {
			setLeadPoint();
			_gpmgr.setMelee(true);
			FangR.predictormgr.setMelee(true);
			_dirver.setMelee(true);
			GunPowerSelector.setMelee(true);
		} else {
			_gpmgr.setMelee(false);
			FangR.predictormgr.setMelee(false);
			_dirver.setMelee(false);
			GunPowerSelector.setMelee(false);
		}
		selectTarget();

		if (_target != null) {
			Shooter.setShooting(true);
		}
		//		Debug.println(_target.get_id());
	}

	private boolean isMelee() {
		if (GameInfo.getOthers() == 1) {
			return false;
		}
		return true;
	}

	private void setLeadPoint() {

		if (Debug.isShowLeadPointInfoForConerMovement) {
			Debug.println("timerRemain:" + _timerRemain);
		}

		countDownTimer();
		if (isTimerEnded()) {

			Point2D.Double position = getRandomCoordinatesForCornerMovement();
			if (Debug.isShowLeadPointInfoForConerMovement) {
				Debug.println("LeadPoint x:" + position.x + " y:" + position.y);
			}
			GravPointManager.setLeadPoint(position.x, position.y);
			resetTimer();
			if (Debug.isShowLeadPointInfoForConerMovement) {
				Debug.println("timerRemainAfterReset:" + _timerRemain);
			}
		}
	}
	//	private void setLeadPoint() {
	//		_influencemapmgr.updateMap();
	//		//		_influencemapmgr.displayMap();
	//		double cmpheight = 999999;
	//		int selecti = 0, selectj = 0;
	//		double[][] imap = _influencemapmgr.getInfluenceMap();
	//		for (int i = 0; i < imap.length; i++) {
	//			for (int j = 0; j < imap[0].length; j++) {
	//				if (cmpheight > imap[i][j]) {
	//					cmpheight = imap[i][j];
	//					selecti = i;
	//					selectj = j;
	//				} else if (cmpheight == imap[i][j] && Math.random() > 0.5) {
	//					cmpheight = imap[i][j];
	//					selecti = i;
	//					selectj = j;
	//				}
	//			}
	//		}
	//		if ((selecti != _oldi || selectj != _oldj) && countRemakeLead < 0) {
	//			countRemakeLead = (int) (20 * Math.random());
	////			Debug.println("set count Remake Lead");
	//		}
	//		//		 TODO :: LEAD GP ���� 
	//		if (countRemakeLead == 0) {
	//			if (countRemakeLead == 0) {
	//				double x = (selecti + Math.random()) * 100;
	//				double y = (selectj + Math.random()) * 100;
	//				double strength = -10;
	//				double factor= 0.8;
	//				GravPointManager.setLeadPoint(x, y, strength, factor);
	//			}
	//			_oldi = selecti;
	//			_oldj = selectj;
	//
	//		}
	//		countRemakeLead--;
	//	}

	private void resetTimer() {
		_timerRemain = (int) (Math.random() * 20);
	}

	private Point2D.Double getRandomCoordinatesForCornerMovement() {
		return getRandomCoordinatesInSquareForCornerMovementByCorner();

	}

	private Point2D
		.Double getRandomCoordinatesInSquareForCornerMovementByCorner() {
		Point2D.Double cornerxy = getNearestCornerCoordinates();

		double x = 0;
		double y = 0;

		double safetyDistanceToAvoidWallRam = 30;
		double RandomLimit = 200 - safetyDistanceToAvoidWallRam;

		if (cornerxy.x > 0) {
			x =
				GameInfo.getBattleW()
					- (Math.random() * RandomLimit)
					- safetyDistanceToAvoidWallRam;
		} else {
			x = Math.random() * RandomLimit + safetyDistanceToAvoidWallRam;
		}
		if (cornerxy.y > 0) {
			y =
				GameInfo.getBattleH()
					- (Math.random() * RandomLimit)
					- safetyDistanceToAvoidWallRam;
		} else {
			y = (Math.random() * RandomLimit) + safetyDistanceToAvoidWallRam;
		}

		return new Point2D.Double(x, y);
	}

	private Point2D.Double getNearestCornerCoordinates() {
		double x = 0;
		double y = 0;
		if (MyInfo.getX() > (GameInfo.getBattleW() / 2)) {
			x = GameInfo.getBattleW();
		}
		if (MyInfo.getY() > (GameInfo.getBattleH() / 2)) {
			y = GameInfo.getBattleH();
		}
		return new Point2D.Double(x, y);
	}

	private boolean isTimerEnded() {
		if (_timerRemain < 0) {
			return true;
		}

		return false;
	}

	private void countDownTimer() {
		_timerRemain--;
	}

	static public EnemyInfo get_target() {
		return _target;
	}

	public void hitRobot() {
		_timerRemain = 0;

	}

}
