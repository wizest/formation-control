/*
 * Created on 2003. 5. 10.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.scaner;

import fangs.FangR;
import fangs.enemy.EnemyInfoManager;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Scanner {
	FangR _fang;
	EnemyInfoManager _enemymgr;
	OldSearchCalculater _oldsearcher;

	public Scanner(FangR f) {
		_fang = f;
		_enemymgr = FangR.enemymgr;
		_oldsearcher = new OldSearchCalculater(_enemymgr);
	}

	public void scan() {
		double radians = _oldsearcher.getScanRadians();
		_fang.setTurnRadarRightRadians(radians);
	}
}
