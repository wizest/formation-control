/*
 * Created on May 14, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.scaner;

import fangs.enemy.EnemyInfo;
import fangs.enemy.EnemyInfoManager;
import fangs.utility.GameInfo;
import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author cse19
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class OldSearchCalculater {
	EnemyInfoManager _enemymgr;
	double turnRadians;
	boolean findall;

	public OldSearchCalculater(EnemyInfoManager EMGR) {
		_enemymgr = EMGR;
	}

	public EnemyInfo getOldScaned() {
		EnemyInfo[] enemies = _enemymgr.getEnemiesArray();
		EnemyInfo tmpEnemy, scanRobo = null;
		long scanedtime = -1;
		long now = GameInfo.getTime();

		findall = true;
		for (int i = 0; i < enemies.length; i++) {
			tmpEnemy = enemies[i];
			if (tmpEnemy.isAlive()) {
				long gaptime = now - tmpEnemy.getLastUpdateTime();
				if (gaptime < 12) {
					if (gaptime > scanedtime) {
						scanRobo = tmpEnemy;
						scanedtime = gaptime;
					}
				} else
					findall = false;
			}
		}
		return scanRobo;
	}

	public double getScanRadians() {
		if (GameInfo.getAllOthers() != _enemymgr.getTotalEnemiesCount())
			return Math.PI;

		if (GameInfo.getRoundNum() > 0 && GameInfo.getTime() < 9)
			return Math.PI;

		EnemyInfo oldrobo = getOldScaned();

		if (oldrobo != null)
			turnRadians =
				MathUtil.relativeRadians(
					oldrobo.getAbsBearingRadians()
						- MyInfo.getRadarHeadingRadians());
		else
			findall = false;

		if (findall)
			return adjustTurnRadians(turnRadians);
		else
			return Math.PI * 2;
	}

	private double adjustTurnRadians(double R) {
		if (R >= 0)
			R += Math.PI / 6;
		else
			R -= Math.PI / 6;
		return R;
	}
}
