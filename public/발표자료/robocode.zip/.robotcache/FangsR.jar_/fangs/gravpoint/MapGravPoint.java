/*
 * Created on 2003. 6. 25.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.gravpoint;

import fangs.utility.GameInfo;
import fangs.utility.MyInfo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class MapGravPoint extends GravPoint {
	static final int NORTH = 0;
	static final int NORTH_EAST = 1;
	static final int EAST = 2;
	static final int SOUTH_EAST = 3;
	static final int SOUTH = 4;
	static final int SOUTH_WEST = 5;
	static final int WEST = 6;
	static final int NORTH_WEST = 7;

	public MapGravPoint(int i, double strength, double factor) {
		_strength = strength;
		_factor = factor;

		switch (i) {
			case NORTH :
				_x = MyInfo.getX();
				_y = GameInfo.getBattleH();
				break;
			case SOUTH :
				_x = MyInfo.getX();
				_y = 0;
				break;
			case EAST :
				_x = GameInfo.getBattleW();
				_y = MyInfo.getY();
				break;
			case WEST :
				_x = 0;
				_y = MyInfo.getY();
				break;
			case NORTH_WEST :
				_x = 0;
				_y = GameInfo.getBattleH();
				break;
			case NORTH_EAST :
				_x = GameInfo.getBattleW();
				_y = GameInfo.getBattleH();
				break;
			case SOUTH_WEST :
				_x = 0;
				_y = 0;
				break;
			case SOUTH_EAST :
				_x = GameInfo.getBattleW();
				_y = 0;
				break;
		}
	}
}
