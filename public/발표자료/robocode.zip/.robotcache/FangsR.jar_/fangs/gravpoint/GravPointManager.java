/*
 * Created on 2003. 5. 11.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.gravpoint;

import java.util.ArrayList;

import fangs.FangR;
import fangs.enemy.EnemyInfo;
import fangs.enemy.ShootingData;
import fangs.utility.GameInfo;
import fangs.utility.MyInfo;

public class GravPointManager {
	static ArrayList _gplist;
	//	static boolean enableLead;
	static double leadx, leady, leadStrength, leadFactor;
	static double _defaultLeadStrength = -0.3;
	static double _defaultLeadFactor = 0;
	boolean melee = false;

	public static void setLeadPoint(
		double x,
		double y,
		double strength,
		double factor) {
		leadx = x;
		leady = y;
		leadStrength = strength;
		leadFactor = factor;
		//		enableLead = true;
	}
	public static void setLeadPoint(double x, double y) {
		setLeadPoint(x, y, _defaultLeadStrength, _defaultLeadFactor);
	}

	public GravPointManager() {
		_gplist = new ArrayList();
	}

	public GravPoint[] getGPArray() {
		_gplist.clear();

		if (isMelee()) {
			gatherCenterGP();
			gatherLeadGP();
			gatherEnemyGP();
		} else {
			gatherEnemyGP();
			gatherBulletGP();
			_gplist.addAll(getAllGPsOfMap());
		}
		return (GravPoint[]) _gplist.toArray(new GravPoint[0]);
	}

	private GravPoint convertEnemyInfoToGravPoint(EnemyInfo info) {
		double x = info.get_x();
		double y = info.get_y();
		double strength = 1000; //* (info.get_energy() / MyInfo.getEnergy());
		double factor = 2.0;
		return new GravPoint(strength, x, y, factor);
	}

	private void convertShootingDataToGravPoint(ShootingData data) {

		double[] angles = data.get_guessAngles();

				double strength = 500 +  data.getDamage() * 50;
//		double strength = data.getDamage() * 62.5;

		double flyingdistance =
			data.get_velocity() * (GameInfo.getTime() - data.get_stamptime());
		double posx;
		double posy;
		double factor = 2;
		for (int i = 0; i < angles.length; i++) {
			posx = data.get_x() + Math.sin(angles[i]) * flyingdistance;
			posy = data.get_y() + Math.cos(angles[i]) * flyingdistance;
			//			if (300
			//				> MathUtil.Distance(posx, posy, MyInfo.getX(), MyInfo.getY())) {
			_gplist.add(new GravPoint(strength, posx, posy, factor));
			//			}
		}
	}

	private void gatherBulletGP() {
		ShootingData[] shootingdatas =
			FangR.enemymgr.getEnemiesShootingDataArray();
		for (int i = 0; i < shootingdatas.length; i++) {
			//	_gplist.addAll(convertShootingDataToGravPoint(shootingdatas[i]));
			convertShootingDataToGravPoint(shootingdatas[i]);
		}
	}

	private void gatherCenterGP() {
		if (GameInfo.getOthers() == 1)
			return;

		double strength = 2000;
		double x = GameInfo.getBattleW() / 2;
		double y = GameInfo.getBattleH() / 2;
		double factor = 1.5;
		_gplist.add(new GravPoint(strength, x, y, factor));
	}

	private void gatherEnemyGP() {
		EnemyInfo[] enemise = FangR.enemymgr.getEnemiesArray();
		for (int i = 0; i < enemise.length; i++) {
			if (enemise[i].isAlive()) {
				_gplist.add(convertEnemyInfoToGravPoint(enemise[i]));
			}
		}
	}

	private void gatherLeadGP() {
		_gplist.add(new GravPoint(leadStrength, leadx, leady, leadFactor));
	}
	
	private ArrayList getAllGPsOfMap() {
		ArrayList tempList = new ArrayList();
		for (int i = 0; i < 8; i++) {
			tempList.add(new MapGravPoint(i, getMapStrengh(), getMapFactor()));
		}
		return tempList;
	}

	private double getMapFactor() {
		if (MyInfo.isTooCloseToWall()) {
			return 2;
		} else {
			return 3;
		}
	}

	private double getMapStrengh() {
		if (MyInfo.isTooCloseToWall()) {
			return 8000;
		} else {
			return 5000;
		}
	}
	public boolean isMelee() {
		return melee;
	}

	public void setMelee(boolean b) {
		melee = b;
	}

}
