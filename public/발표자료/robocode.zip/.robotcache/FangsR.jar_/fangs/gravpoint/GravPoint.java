/*
 * Created on 2003. 5. 11.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.gravpoint;

import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class GravPoint {
	double _strength, _x, _y, _factor;

	public GravPoint() {
	}

	public GravPoint(double Strength, double X, double Y, double Factor) {
		_factor = Factor;
		_strength = Strength;
		_x = X;
		_y = Y;
	}
	public double getForce() {
		return get_strength()
			/ Math.pow(
				MathUtil.Distance(
					MyInfo.getX(),
					MyInfo.getY(),
					get_x(),
					get_y()),
				get_factor());
	}
	public double get_absBearingRadians() {
		return MathUtil.AbsoluteRadians(
			Math.atan2(get_x() - MyInfo.getX(), get_y() - MyInfo.getY()));
	}

	public double get_strength() {
		return _strength;
	}

	public double get_x() {
		return _x;
	}

	public double get_y() {
		return _y;
	}

	public double get_factor() {
		return _factor;
	}
}
