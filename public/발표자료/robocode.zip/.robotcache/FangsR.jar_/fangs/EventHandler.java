/*
 * Created on 2003. 5. 18.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs;
import robocode.Bullet;
import robocode.BulletHitBulletEvent;
import robocode.BulletHitEvent;
import robocode.BulletMissedEvent;
import robocode.HitByBulletEvent;
import robocode.ScannedRobotEvent;
import fangs.enemy.EnemyInfoManager;
import fangs.ripple.RippleManager;
import fangs.utility.Debug;
import fangs.utility.GameInfo;
import fangs.utility.MyInfo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class EventHandler {
	EnemyInfoManager _enemymgr;
	FangR _fang;
	private RippleManager _ripplemgr;

	public EventHandler(EnemyInfoManager EM) {
		_enemymgr = EM;
	}

	public void handlingBulletHitBullet(BulletHitBulletEvent e) {
		// TODO :: EnemyInfo�� ���� ���� ������ ���ƶ�.
		//		Bullet bullet = e.getHitBullet();
		//		if (_enemymgr.isExistByName(bullet.getName())) {
		//			EnemyInfo ei = _enemymgr.getEnemyInfoByName(bullet.getName());
		//			ei.searchBulletOrigin(bullet, e.getTime());
		//		}
	}

	public void handlingBulletMissed(BulletMissedEvent e) {
	}

	public void handlingHitByBullet(HitByBulletEvent e) {
		_enemymgr.updateByHit(e.getName(), e.getBullet(), e.getTime());
	}

	public void handlingOnScannedRobot(ScannedRobotEvent e) {
		if (Debug.isShowScanEvent) {
			Debug.println(
				"name " + e.getName() + " tick: " + GameInfo.getTime());
		}
		double angle = MyInfo.getHeadingRadians() + e.getBearingRadians();
		double posx = MyInfo.getX() + e.getDistance() * Math.sin(angle);
		double posy = MyInfo.getY() + e.getDistance() * Math.cos(angle);
		_enemymgr.updateByScan(
			e.getName(),
			e.getTime(),
			posx,
			posy,
			e.getEnergy(),
			e.getHeadingRadians(),
			e.getVelocity());
	}

	public void handlingBulletHit(BulletHitEvent e) {
		Bullet bullet = e.getBullet();
		_enemymgr.updateByBulletHit(e.getName(), e.getEnergy());
	}
}
