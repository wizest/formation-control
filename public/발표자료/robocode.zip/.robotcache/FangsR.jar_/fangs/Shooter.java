/*
 * Created on May 13, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs;

import robocode.Bullet;
import fangs.predict.PredictorManager;
import fangs.predict.ShootingOrder;
import fangs.ripple.RippleManager;
import fangs.utility.Debug;
import fangs.utility.GameInfo;
import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * Shooting Bullet & Ripple(similar to Virtual Bullet)
 */
public class Shooter {
	private double _hitDamage;
	ShootingOrder _result;
	FangR _fang;
	RippleManager _ripplemgr;
	PredictorManager _predictmgr;

	//	Predictable _predict;

	private long _fireCount;

	static boolean _shooting;

	public Shooter(FangR F) {
		_shooting = false;
		_fang = F;
		_predictmgr = FangR.predictormgr;
		_ripplemgr = FangR.ripplemgr;

	}

	public void shoot() {
		_result = _predictmgr.getShootingOrder();
		if (_result == null) {
			//			Debug.println("Not Order");
			return;
		}

		aimingTarget(_result.get_radians());

		if (_shooting
			&& MyInfo.getGunTurnRemaining() < 1
			&& MyInfo.getGunHeat() == 0) {
			//			Debug.println("shoot");

			Bullet bullet = _fang.setFireBullet(_result.get_power());

			_hitDamage += (_result.get_power()) > 1
				? (_result.get_power() * 4) + 2 * (_result.get_power() - 1)
				: (_result.get_power() * 4);
			_fireCount++;
			//			_firedtime = GameInfo.getTime();
			if (bullet != null) {

				if (Debug.isShowPredicInfo) {
					_predictmgr.displayPredictInfo();
				}

				if (Debug.isShowShoot) {
					Debug.println("Shooting time : " + GameInfo.getTime());
					Debug.println(
						"Shooting angle :"
							+ Math.toDegrees(MyInfo.getGunHeadingRadians()));
				}
				_ripplemgr.reportFireBullet(bullet);
			}
		}
	}

	private void aimingTarget(double fireRadians) {
		double turnradians =
			MathUtil.relativeRadians(
				fireRadians - MyInfo.getGunHeadingRadians());
		_fang.setTurnGunRightRadians(turnradians);
	}

	public static void setShooting(boolean b) {
		_shooting = b;
	}

	//	public static long getFiredtime() {
	//		return _firedtime;
	//	}
	public long get_fireCount() {
		return _fireCount;
	}
	public double get_hitDamage() {
		return _hitDamage;
	}

}
