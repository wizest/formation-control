/*
 * Created on 2003. 5. 11.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.driver;

import fangs.gravpoint.*;
import fangs.utility.*;

/**
 * @author Chunsik In Spoon.Korea.ac.kr
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class AGMCalculater {
	double sumforce;
	long count;
	GravPointManager _gpmgr;

	public static boolean display = false;

	public AGMCalculater(GravPointManager GPM) {
		_gpmgr = GPM;
	}

	public AGMResult calculate() {
		double xforce = 0, yforce = 0, angle;
		GravPoint[] gps = _gpmgr.getGPArray();
		if (Debug.isShowGPS) {
			Debug.println("\n\n== AGMCalculate Result ==");
		}

		for (int i = 0; i < gps.length; i++) {
			angle = gps[i].get_absBearingRadians();
			double tmpforce = gps[i].getForce();
			xforce += tmpforce * Math.sin(angle);
			yforce += tmpforce * Math.cos(angle);

			if (Debug.isShowGPS) {
				/* for Debug*/
				Debug.println(
				/* gps[i].toString()*/
				i
					+ "  force "
					+ tmpforce
					+ "  angle "
					+ Math.toDegrees(angle)
					+ " x  "
					+ gps[i].get_x()
					+ " y  "
					+ gps[i].get_y());
			}
		}

		angle =
			MathUtil.AbsoluteRadians(
				Math.PI * 3 / 2 - Math.atan2(yforce, xforce));
		double force = MathUtil.Distance(0, 0, xforce, yforce);
		if (Debug.isShowGPS) {
			Debug.println(
				"\nforce : " + force + "  angle : " + Math.toDegrees(angle));
		}
		return new AGMResult(force, angle);
	}
}
