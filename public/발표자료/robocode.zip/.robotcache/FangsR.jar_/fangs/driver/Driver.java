/*
 * Created on 2003. 5. 10.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.driver;

import fangs.FangR;
import fangs.enemy.EnemyInfo;
import fangs.tactician.Tactician;
import fangs.utility.Debug;
import fangs.utility.GameInfo;
import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Driver {
	FangR _fang;
	AGMCalculater _agmcalc;
	boolean Melee;
	int i = 0;

	public Driver(FangR f) {
		_fang = f;
		_agmcalc = new AGMCalculater(FangR.gravpointmgr);

	}

	public void drive() {
		AGMResult agmresult = _agmcalc.calculate();
		if (Debug.isShowDriverCall) {
			Debug.println("time : " + GameInfo.getTime() + " i : " + i++);
		}

		double force = agmresult.get_force();
		double toradians = 0;
		double targetbear;
		double tmpradians;
		//		Debug.println("agm force " + force);
		//		if (force < 0.1) {
		//			EnemyInfo target = Tactician.get_target();
		//			if (target != null) {
		//				
		//				 targetbear = target.get_absBearingRadians();
		//
		//				 tmpradians =
		//					MathUtil.relativeRadians(
		//						MyInfo.getHeadingRadians() - targetbear);
		//				if (tmpradians >= 0) {
		//					toradians =
		//						MathUtil.AbsoluteRadians(targetbear + Math.PI / 2);
		//				} else if (tmpradians < 0) {
		//					toradians =
		//						MathUtil.AbsoluteRadians(targetbear - Math.PI / 2);
		//				}
		//				agmresult = new AGMResult(100, toradians);
		//			}
		//		} else {
		if (!isMelee()) {

			EnemyInfo target = Tactician.get_target();
			if (target != null) {

				targetbear = target.getAbsBearingRadians();

				tmpradians =
					MathUtil.relativeRadians(
						agmresult.get_angle() - targetbear);
				if (tmpradians >= 0) {
					toradians =
						MathUtil.AbsoluteRadians(targetbear + Math.PI / 2);
				} else if (tmpradians < 0) {
					toradians =
						MathUtil.AbsoluteRadians(targetbear - Math.PI / 2);
				}
				//			Debug.println(
				//				"T-bear : "
				//					+ Math.toDegrees(targetbear)
				//					+ " tmpradians : "
				//					+ Math.toDegrees(tmpradians)
				//					+ "  HMS heading : "
				//					+ Math.toDegrees(toradians)
				//					+ "  agm angle "
				//					+ Math.toDegrees(agmresult.get_angle()));
				double tmp =
					MathUtil.AbsoluteRadians(
						toradians
							+ MathUtil.relativeRadians(
								agmresult.get_angle() - toradians)
								/ 2);
				agmresult = new AGMResult(100, tmp);
				//		}

			}
		}
		double limitV = 4 + 4 * Math.random();
		double limitT = ((8 + 2 * Math.random()) - 0.75 * limitV);
		_fang.setMaxVelocity(limitV);
		_fang.setMaxTurnRate(limitT);
		goTO(agmresult);
	}

	public void goTO(AGMResult DO) {

		double angle =
			MathUtil.relativeRadians(
				DO.get_angle() - MyInfo.getHeadingRadians());
		double range = 1000;
		int direction = 1;

		//		Debug.println("Goto angle " + Math.toDegrees(DO.get_angle()));

		if (angle > Math.PI / 2) {
			angle -= Math.PI;
			direction = -1;
		} else if (angle < -Math.PI / 2) {
			angle += Math.PI;
			direction = -1;
		}

		range *= direction;
		_fang.setTurnRightRadians(angle);
		_fang.setAhead(range);
	}

	public boolean isMelee() {
		return Melee;
	}

	public void setMelee(boolean b) {
		Melee = b;
	}

}
