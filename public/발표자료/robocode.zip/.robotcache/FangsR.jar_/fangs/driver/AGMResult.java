/*
 * Created on May 10, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.driver;

/**
 * @author cse19
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class AGMResult {
	double _force, _angle;

	public AGMResult(double RANGE, double ANGLE) {
		_force = RANGE;
		_angle = ANGLE;
	}

	/**
	 * @return
	 */
	public double get_angle() {
		return _angle;
	}

	/**
	 * @return
	 */
	public double get_force() {
		return _force;
	}

}
