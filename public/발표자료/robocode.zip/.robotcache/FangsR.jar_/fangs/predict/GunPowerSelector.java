package fangs.predict;
import fangs.enemy.EnemyInfo;
import fangs.utility.MyInfo;

/*
 * Created on 2003-06-05
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author cse20
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class GunPowerSelector {
	static double _gunpower;
	static boolean Melee = false;
	public boolean setGunPower(EnemyInfo Target) {

		if (Target == null)
			return false;
		if (isMelee()) {
			if (Target.isAlive()) {
				double gunpower;
				double dist = Target.getDistance();

				double MyEnergy = MyInfo.getEnergy();
				double EnemyEnergy = Target.get_energy();

				double deadpower = 3;

				if (EnemyEnergy < 2 && MyEnergy < 2) {
					_gunpower = 0.1;
					return true;
				}

				if (EnemyEnergy <= 4) {
					deadpower = (EnemyEnergy) / 4;
				} else if (EnemyEnergy <= 16) {
					deadpower = (EnemyEnergy + 2) / 6;
				}
				if (dist < 400) {
					gunpower = 1.5 + Math.random();
				} else if (dist < 600) {
					gunpower = 1.0 + Math.random();
				} else {
					gunpower = 0.5 + Math.random();
				}

				_gunpower = Math.min(deadpower, gunpower);

				return true;
			}
			return false;
		}
		if (Target.isAlive()) {
			//			double gunpower;
			//			double dist = Target.getDistance();

			double MyEnergy = MyInfo.getEnergy();
			double EnemyEnergy = Target.get_energy();

			double deadpower = 3;

			if (EnemyEnergy < 2 && MyEnergy < 2) {
				_gunpower = 0.1;
				return true;
			}

			if (EnemyEnergy <= 4) {
				deadpower = (EnemyEnergy) / 4;
			} else if (EnemyEnergy <= 16) {
				deadpower = (EnemyEnergy + 2) / 6;
			}

			//			if (MyEnergy < 2 * deadpower) {
			//				return false;
			//			}
			if (MyEnergy * 2 < EnemyEnergy) {
				_gunpower = Math.min(MyEnergy - 0.1, 0.5);
				return true;
			}
			_gunpower = Math.min(deadpower, 3.0);
			//		_gunpower = 1;

			//		_gunpower = 1;
			return true;
		}
		return false;
	}

	public static double get_gunpower() {
		return Math.min(_gunpower, 3.0);
	}

	public static boolean isMelee() {
		return Melee;
	}

	public static void setMelee(boolean b) {
		Melee = b;
	}

}
