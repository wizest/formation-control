/*
 * Created on 2003-05-22
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.predict;

import fangs.enemy.EnemyInfo;
import fangs.enemy.StateData;
import fangs.tactician.Tactician;

/**
 * @author cse20
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class StationaryPredictor implements Predictable {
	final static int STANARY_CHECK = 20;

	public ShootingOrder getResult(EnemyInfo Target) {
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder() {
		EnemyInfo Target = Tactician.get_target();
		if (Target == null)
			return null;
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder(EnemyInfo Target) {
		double gunpower = GunPowerSelector.get_gunpower();
		return new ShootingOrder(Target.getAbsBearingRadians() + Math.toRadians(4*Math.random()-2), gunpower, true);
	}

	public boolean isCanPredict(EnemyInfo target) {
		StateData[] EnemyDatas = target.getEnemyDataRecordArray();
		if (EnemyDatas.length < STANARY_CHECK) {
			return false;
		}
		int i;
		for (i = 0; i < STANARY_CHECK; i++) {
			//	Debug.println("v : " + EnemyDatas[i].get_velocity());
			if (EnemyDatas[i].get_velocity() != 0)
				break;
		}
		if (i == STANARY_CHECK)
			return true;

		return false;
	}
	public String toString() {
		return "Sta";
	}

}
