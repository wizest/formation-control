/*
 * Created on May 28, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.predict;

import fangs.enemy.EnemyInfo;
import fangs.tactician.Tactician;
import fangs.utility.MathUtil;

public class GuessFactorPredictor implements Predictable {

	public ShootingOrder getResult(EnemyInfo Target) {
		return getShootingOrder(Target);
	}
	
	public ShootingOrder getShootingOrder() {
		EnemyInfo Target = Tactician.get_target();
		if (Target == null)
			return null;
		return getShootingOrder(Target);
	}
	
	public ShootingOrder getShootingOrder(EnemyInfo Target) {

		int distindex = getDistanceIndex(Target.getDistance());

		double gunpower = GunPowerSelector.get_gunpower();

		int bestGuessFactor =
			getBestGuessFactor(Target.getGuessFactorScoreMap(), distindex);

		double targetDirection =
			getTargetDirection(
				Target.get_velocity(),
				Target.get_headingRadians(),
				Target.getAbsBearingRadians());

		double fireangle =
			getAngleToFireByGuessFactor(
				bestGuessFactor,
				Target.getAbsBearingRadians(),
				targetDirection);

		return new ShootingOrder(fireangle, gunpower, true);
	}

	public static double getAngleToFireByGuessFactor(
		int bestGuessFactor,
		double absBearingRadian,
		double targetDirection) {
		return MathUtil.AbsoluteRadians(
			absBearingRadian
				+ targetDirection * Math.toRadians(bestGuessFactor - 50));
	}

	public static double getTargetDirection(
		double velocity,
		double headingRadian,
		double absBearingRadian) {
		double targetDirection = 1;
		if (velocity != 0) {
			targetDirection =
				velocity * Math.sin(headingRadian - absBearingRadian);
			targetDirection /= Math.abs(targetDirection);
		}
		return targetDirection;
	}

	public static int getBestGuessFactor(
		double[][] guessFactorMap,
		int distindex) {
		double tmp = guessFactorMap[distindex][50];
		int bestGuessFactor = 50;
		for (int i = 0; i < guessFactorMap[distindex].length / 2; i++) {
			if (tmp < guessFactorMap[distindex][50 - i]) {
				tmp = guessFactorMap[distindex][50 - i];
				bestGuessFactor = 50 - i;
				//				allow = true;
			}
			if (tmp < guessFactorMap[distindex][50 + i]) {
				tmp = guessFactorMap[distindex][50 + i];
				bestGuessFactor = 50 + i;
				//				allow = true;
			}

		}
		return bestGuessFactor;
	}

	public static int getDistanceIndex(double distance) {
		int distindex = (int) Math.round(Math.sqrt(distance / 40));
		if (distindex < 0)
			distindex = 0;

		if (distindex > 10)
			distindex = 10;

		return distindex;
	}

	public boolean isCanPredict(EnemyInfo target) {
		return true;
	}
	public String toString() {
		return "GF";
	}

}
