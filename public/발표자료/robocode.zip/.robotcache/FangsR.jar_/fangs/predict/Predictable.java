/*
 * Created on 2003. 5. 20.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.predict;

import fangs.enemy.EnemyInfo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public interface Predictable {
	public boolean isCanPredict(EnemyInfo target);
	public ShootingOrder getShootingOrder(EnemyInfo Target);
	public ShootingOrder getShootingOrder();
	public ShootingOrder getResult(EnemyInfo Target);
}
