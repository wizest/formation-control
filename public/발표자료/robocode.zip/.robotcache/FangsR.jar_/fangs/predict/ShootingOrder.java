/*
 * Created on May 17, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.predict;

/**
 * @author cse19
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ShootingOrder {
	double _radians;
	double _power;
	boolean _allow;

	public ShootingOrder(double R, double P, boolean A ) {
		_radians = R;
		_power = P;
		_allow = A;
		//		Debug.println("fire angle : " + Math.toDegrees(R));
	}

	public double get_power() {
		return _power;
	}

	public double get_radians() {
		return _radians;
	}

	public boolean is_allow() {
		return _allow;
	}

}
