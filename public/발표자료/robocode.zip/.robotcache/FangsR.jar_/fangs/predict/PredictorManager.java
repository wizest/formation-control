/*
 * Created on 2003-05-22
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.predict;

import fangs.FangR;
import fangs.enemy.EnemyInfo;
import fangs.tactician.Tactician;
import fangs.utility.Debug;

/**
 * @author cse20
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class PredictorManager {
	GunPowerSelector _GunPowerSelector;
	boolean _isMelee;

	static private Predictable[] _predictors =
		new Predictable[] {
			new GuessFactorPredictor(),
			new RepeatPredictor(),
			new CircularPredictor(),
			new LinearPredictor(),
			new StationaryPredictor()};

	public PredictorManager() {
		_GunPowerSelector = new GunPowerSelector();
	}

	public static int getPredictorsNumber() {
		return _predictors.length;
	}

	public ShootingOrder[] getAllPredictResult() {
		return getAllPredictResult(Tactician.get_target());
	}

	public ShootingOrder[] getAllPredictResult(EnemyInfo Target) {
		ShootingOrder[] results = new ShootingOrder[_predictors.length];
		//				ShootingOrder[] results = new ShootingOrder[1];
		//		results[0]= _predictors[4].getShootingOrder(Target);
		for (int i = 0; i < _predictors.length; i++) {
			results[i] = _predictors[i].getResult(Target);
			//			Debug.println("getAll Result");
			//			if (_predictors[i].isCanPredict(Target)) {
			//				results[i] = _predictors[i].getShootingOrder(Target);
			//			} else {
			//				results[i] = null;
			//			}
		}
		return results;
	}

	public ShootingOrder getShootingOrder() {
		EnemyInfo Target = Tactician.get_target();
		if (Target == null)
			return null;
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder(EnemyInfo Target) {

		if (!_GunPowerSelector.setGunPower(Target))
			return null;

		if (isMelee()) {
			if (Target.getDistance() < 200) {
				return _predictors[4].getShootingOrder(Target);
			}
		}

		//		if (isMelee()) {

		//			return _predictors[4].getShootingOrder();
		//		} else {

		int[] accuracy = Target.getAccuracyArray();

		int bestindex = 0;
		int bestvalue = 0;
		for (int i = 0; i < _predictors.length; i++) {
			if (bestvalue < accuracy[i]) {
				bestindex = i;
				bestvalue = accuracy[i];
			}
		}
		ShootingOrder order = _predictors[bestindex].getShootingOrder(Target);

		if (order == null || Target == null) {
			FangR.enemymgr.setAccuracyToZero(Target.get_id(), bestindex);
		}

		return order;
		//		}

	}

	public void displayPredictInfo() {
		EnemyInfo Target = Tactician.get_target();
		int bestindex = 0;
		int bestvalue = 0;
		int[] accuracy = Target.getAccuracyArray();
		for (int i = 0; i < accuracy.length; i++) {
			Debug.println(
				_predictors[i].toString() + " accuracy : " + accuracy[i]);
			if (bestvalue < accuracy[i]) {
				bestindex = i;
				bestvalue = accuracy[i];
			}
		}
		Debug.println(
			"Selected Predictor : " + _predictors[bestindex].toString());

		//		int index = GuessFactorPredictor.getDistanceIndex(Target.getDistance());
		//		double[][] map = Target.getGuessFactorScoreMap();
		//		for (int i = 0; i < map[0].length; i++) {
		//			Debug.print(map[index][i] + "  ");
		//		}
		Debug.println(" ");

	}
	public boolean isMelee() {
		return _isMelee;
	}

	public void setMelee(boolean b) {
		_isMelee = b;
	}

}
