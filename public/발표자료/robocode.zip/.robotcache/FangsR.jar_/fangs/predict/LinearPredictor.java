/*
 * Created on May 13, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.predict;

import fangs.enemy.EnemyInfo;
import fangs.enemy.StateData;
import fangs.tactician.Tactician;
import fangs.utility.Debug;
import fangs.utility.MathUtil;

/**
 * @author cse19
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class LinearPredictor implements Predictable {
	private int LINEAR_CHECK = 10;

	public ShootingOrder getResult(EnemyInfo Target) {
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder() {
		EnemyInfo Target = Tactician.get_target();
		if (Target == null)
			return null;
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder(EnemyInfo Target) {
		double gunpower = GunPowerSelector.get_gunpower();
		//		Debug.println("call lin");

		double fireangle =
			getAngleToFireByLinear(
				Target.get_velocity(),
				Target.getAbsBearingRadians(),
				Target.get_headingRadians(),
				gunpower);

		//		Debug.println(Math.toDegrees(fireangle));

		return new ShootingOrder(fireangle, gunpower, true);
	}

	public static double getAngleToFireByLinear(
		double velocity,
		double absBearingRadian,
		double headingRadian,
		double gunpower) {
		double projV;
		double diff = headingRadian - absBearingRadian;

		projV = Math.sin(diff) * velocity;

		if (Debug.isShowLinear) {
			Debug.println(
				"T head  : "
					+ Math.toDegrees(headingRadian)
					+ "   T Bearing : "
					+ Math.toDegrees(absBearingRadian));
			Debug.println("Velocity : " + velocity + "  gunpower  " + gunpower);
		}

		return MathUtil.AbsoluteRadians(
			Math.asin(projV / (20 - 3 * gunpower)) + absBearingRadian);
	}

	public boolean isCanPredict(EnemyInfo target) {
		StateData[] EnemyDatas = target.getEnemyDataRecordArray();
		if (EnemyDatas.length < LINEAR_CHECK) {
			return false;
		}
		double stdtmpvelo = EnemyDatas[0].get_velocity();
		double stdtmpangvelo = EnemyDatas[0].get_angularvelocity();
		double gaptmp;
					Debug.println(
						"stdV : " + stdtmpvelo + "   stdAV : " + stdtmpangvelo);
		if (stdtmpangvelo == 0 && stdtmpvelo != 0) {
			int i = 1;
			for (i = 1; i < LINEAR_CHECK; i++) {
				if (EnemyDatas[i].get_velocity() != stdtmpvelo
					|| EnemyDatas[i].get_angularvelocity() != 0)
					break;
			}

			if (i == LINEAR_CHECK) {
				return true;
			}
		}
		return false;
	}

	public String toString() {
		return "Lin";
	}

}
