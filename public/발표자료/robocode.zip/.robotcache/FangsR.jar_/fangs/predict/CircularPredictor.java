/*
 * Created on 2003. 5. 20.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.predict;

import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;

import fangs.enemy.EnemyInfo;
import fangs.enemy.StateData;
import fangs.tactician.Tactician;
import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class CircularPredictor implements Predictable {
	final static int CIRCULAR_CHECK = 10;

	public ShootingOrder getResult(EnemyInfo Target) {
		if (!isTargetTurning(Target.get_angularvelocity()))
			return null;
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder() {
		EnemyInfo Target = Tactician.get_target();
		if (Target == null)
			return null;
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder(EnemyInfo Target) {
		double gunpower = GunPowerSelector.get_gunpower();

		Point2D.Double CenterPosition =
			getCenterOfCircul(
				Target.get_headingRadians(),
				Target.get_velocity(),
				Target.get_angularvelocity(),
				Target.get_x(),
				Target.get_y());

		double fireangle =
			getAngleToFireByCircular(
				CenterPosition,
				gunpower,
				Target.get_angularvelocity(),
				Target.get_headingRadians(),
				Target.get_x(),
				Target.get_y(),
				MyInfo.getX(),
				MyInfo.getY());
		return new ShootingOrder(fireangle, gunpower, true);
	}

	public static double getAngleToFireByCircular(
		Double CenterPosition,
		double gunpower,
		double angularVelocity,
		double headingRadians,
		double x,
		double y,
		double shooterx,
		double shootery) {

		double diffdist;
		double changingheading;
		long difftime;

		double bulletvelocity = 20 - 3 * gunpower;

		double distance = MathUtil.Distance(shooterx, shootery, x, y);

		double radius =
			MathUtil.Distance(
				CenterPosition.getX(),
				CenterPosition.getY(),
				x,
				y);

		for (int i = 0; i < 20; i++) {

			difftime = (long) (distance / bulletvelocity + 0.5);
			changingheading = difftime * angularVelocity;

			x =
				CenterPosition.getX()
					- Math.cos(headingRadians + changingheading) * radius;
			y =
				CenterPosition.getY()
					+ Math.sin(headingRadians + changingheading) * radius;
			distance = MathUtil.Distance(shooterx, shootery, x, y);
		}

		return MathUtil.AbsoluteRadians(Math.atan2(x - shooterx, y - shootery));
	}

	/**
	 * @param d
	 * @param e
	 * @param f
	 * @return
	 */
	public static Point2D.Double getCenterOfCircul(
		double headingRadians,
		double velocity,
		double angularVelocity,
		double x,
		double y) {

		double radius = velocity / angularVelocity;
		long difftime;

		double centerx = x + Math.cos(headingRadians) * radius;
		double centery = y - Math.sin(headingRadians) * radius;
		return new Point2D.Double(centerx, centery);

	}

	//	private double getAngleToFireByCircular(
	//		double x,
	//		double y,
	//		double headingRadians,
	//		double EnemyVelocity) {
	//		double initheadingradians = _target.get_headingRadians();
	//		double radius = _target.get_velocity() / _oldturnrate;
	//		long difftime;
	//
	//		double x = Target.get_x();
	//		double y = Target.get_y();
	//		double centerx = x + Math.cos(initheadingradians) * radius;
	//		double centery = y - Math.sin(initheadingradians) * radius;
	//
	//		double diffdist;
	//		double changingheading;
	//
	//		double myx = MyInfo.getX();
	//		double myy = MyInfo.getY();
	//		double dist = MathUtil.Distance(myx, myy, x, y);
	//		double bulletVelocity = 20 - 3 * _gunpower;
	//
	//		for (int i = 0; i < 20; i++) {
	//
	//			difftime = (long) (dist / bulletVelocity + 0.5);
	//			changingheading = difftime * _oldturnrate;
	//
	//			x =
	//				centerx
	//					- Math.cos(initheadingradians + changingheading) * radius;
	//			y =
	//				centery
	//					+ Math.sin(initheadingradians + changingheading) * radius;
	//			double tmpdist = MathUtil.Distance(myx, myy, x, y);
	//			diffdist = Math.abs(tmpdist - dist);
	//			dist = tmpdist;
	//		}
	//		return Math.PI / 2 - Math.atan2(y - myy, x - myx);

	/* (non-Javadoc)
	 * @see fangs.predict.Pattern#isMatch(double, double)
	 */

	public boolean isCanPredict(EnemyInfo target) {
		StateData[] EnemyDatas = target.getEnemyDataRecordArray();
		double stdtmpangvelo = EnemyDatas[0].get_angularvelocity();
		if (EnemyDatas.length < CIRCULAR_CHECK || stdtmpangvelo == 0) {
			return false;
		}
		double stdtmpvelo = EnemyDatas[0].get_velocity();
		double gaptmp;
		int i = 1;
		for (i = 1; i < CIRCULAR_CHECK; i++) {
			gaptmp =
				Math.abs(EnemyDatas[i].get_angularvelocity() - stdtmpangvelo);
			if (EnemyDatas[i].get_velocity() != stdtmpvelo || gaptmp > 0.04) {
				break;
			}
		}
		if (i == CIRCULAR_CHECK) {
			return true;
		}

		return false;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "Cir";
	}

	public static boolean isTargetTurning(double angluarVelocity) {
		return (angluarVelocity != 0);
	}
}
