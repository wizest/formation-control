/*
 * Created on 2003-05-26
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.predict;

import fangs.enemy.EnemyInfo;
import fangs.enemy.StateData;
import fangs.tactician.Tactician;
import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author cse20
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class RepeatPredictor implements Predictable {
	final static int PATTERN_CHECK = 8;
	boolean _allow;

	public ShootingOrder getResult(EnemyInfo Target) {
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder() {
		EnemyInfo Target = Tactician.get_target();
		if (Target == null)
			return null;
		return getShootingOrder(Target);
	}

	public ShootingOrder getShootingOrder(EnemyInfo Target) {
		if (!isCanPredict(Target))
		{		
			return null;
		}
		_allow = true;
		double gunpower = GunPowerSelector.get_gunpower();

		double fireangle =
			getAngleToFireByRepeat(
				Target.getEnemyDataRecordArray(),
				Target.get_matchoffset(),
				Target.getDistance(),
				gunpower);

		return new ShootingOrder(fireangle, gunpower, _allow);
	}
	/**
	 * @return
	 */
	private double getAngleToFireByRepeat(
		StateData[] datas,
		int startMatchOffset,
		double distance,
		double gunpower) {
		long difftime;

		double velocity = 20 - 3 * gunpower;
		double startx = datas[startMatchOffset].get_x();
		double starty = datas[startMatchOffset].get_y();
		double destx = 0;
		double desty = 0;
		double directangle;
		double tmpdist;
		for (int i = 0; i < 20; i++) {
			difftime = (long) (distance / velocity + 0.5);
			try {
				destx = datas[(int) (startMatchOffset - difftime)].get_x();
				desty = datas[(int) (startMatchOffset - difftime)].get_y();

			} catch (ArrayIndexOutOfBoundsException e) {
				_allow = false;
				return 0;
			}

			directangle =
				Math.PI / 2
					- Math.atan2(desty - starty, destx - startx)
					- datas[startMatchOffset].get_headingRadians();
			tmpdist = MathUtil.Distance(destx, desty, startx, starty);
			directangle += datas[0].get_headingRadians();
			destx = datas[0].get_x() + Math.sin(directangle) * tmpdist;
			desty = datas[0].get_y() + Math.cos(directangle) * tmpdist;

			distance =
				MathUtil.Distance(MyInfo.getX(), MyInfo.getY(), destx, desty);

		}

		return Math.PI / 2
			- Math.atan2(desty - MyInfo.getY(), destx - MyInfo.getX());

	}
	/* (non-Javadoc)
	 * @see fangs.predict.Pattern#isMatch(double, double)
	 */
	public boolean isCanPredict(EnemyInfo target) {

		StateData[] EnemyDatas = target.getEnemyDataRecordArray();
		if (EnemyDatas.length < PATTERN_CHECK) {
			return false;
		}
		int count = 0;
		int i;
		double tmpgapV;
		double gaptmp;
		for (i = PATTERN_CHECK * 3;
			i < EnemyDatas.length - PATTERN_CHECK;
			i++) {
			gaptmp =
				Math.abs(
					EnemyDatas[i].get_angularvelocity()
						- EnemyDatas[0].get_angularvelocity());
			tmpgapV =
				Math.abs(
					EnemyDatas[i].get_velocity()
						- EnemyDatas[0].get_velocity());
			if (gaptmp <= 0.04 && tmpgapV <= 0.02) {
				//				Debug.println("match? num : " + i);
				for (count = 1; count < PATTERN_CHECK; count++) {
					gaptmp =
						Math.abs(
							EnemyDatas[i
								+ count].get_angularvelocity()
								- EnemyDatas[count].get_angularvelocity());
					tmpgapV =
						Math.abs(
							EnemyDatas[i
								+ count].get_velocity()
								- EnemyDatas[count].get_velocity());

					if (gaptmp > 0.04 || tmpgapV > 0.02) {
						break;
					}
					if (count == PATTERN_CHECK - 1) {
						target.set_matchoffset(i - 1);
						return true;
					}
				}
			}
		}
		return false;
	}
	public String toString() {
		return "Pat";
	}

}
