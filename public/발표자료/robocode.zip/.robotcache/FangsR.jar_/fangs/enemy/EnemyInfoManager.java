/*
 * Created on 2003. 5. 10.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.enemy;

import java.awt.geom.Point2D;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;

import robocode.Bullet;
import fangs.predict.CircularPredictor;
import fangs.predict.GuessFactorPredictor;
import fangs.predict.ShootingOrder;
import fangs.ripple.MyFireData;
import fangs.utility.Debug;
import fangs.utility.GameInfo;
import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class EnemyInfoManager {
	static HashMap _enemymap;
	public EnemyInfoManager() {
		int tmp = (int) (GameInfo.getAllOthers() * 1.5);
		_enemymap = new HashMap(tmp);
	}

	public EnemyInfo getEnemyInfoByName(String Name) {
		return (EnemyInfo) _enemymap.get(Name);
	}

	public EnemyInfo[] getEnemiesArray() {
		return (EnemyInfo[]) _enemymap.values().toArray(new EnemyInfo[0]);
	}

	public ShootingData[] getEnemiesShootingDataArray() {
		EnemyInfo[] enemies = getEnemiesArray();
		ArrayList list = new ArrayList();
		for (int i = 0; i < enemies.length; i++) {
			list.addAll(enemies[i].getEnemyShootingDataArray());
		}
		return (ShootingData[]) list.toArray(new ShootingData[0]);
	}

	public int getTotalEnemiesCount() {
		return _enemymap.size();
	}

	public void ReportDeath(String Name) {
		if (!_enemymap.containsKey(Name))
			return;
		EnemyInfo en = (EnemyInfo) _enemymap.get(Name);
		en.set_alive(false);
	}

	public boolean isExistByName(String Name) {
		return _enemymap.containsKey(Name);
	}

	public void setAliveAll() {
		EnemyInfo[] Earray = getEnemiesArray();
		for (int i = 0; i < Earray.length; i++) {
			Earray[i].set_alive(true);
		}
	}

	public void clearRoundData() {
		EnemyInfo[] eis = getEnemiesArray();
		for (int i = 0; i < eis.length; i++) {
			eis[i].clearRoundData();
		}
	}

	public void updateByScan(
		String name,
		long Time,
		double x,
		double y,
		double Energy,
		double Heading,
		double Velocity) {

		if (_enemymap.containsKey(name)) {
			EnemyInfo EI = getEnemyInfoByName(name);
			if (!EI.isAlive()) {
				EI.set_alive(true);
			}
			if (EI.getLastUpdateTime() == Time) {
				EI.removeHistory(0);
			}
			EnemyInfoUpdate(EI, Time, x, y, Energy, Heading, Velocity);
		} else {
			EnemyInfo EI =
				new EnemyInfo(name, x, y, Energy, Velocity, Heading, Time);
			_enemymap.put(name, EI);
		}
	}

	private void EnemyInfoUpdate(
		EnemyInfo EI,
		long Time,
		double x,
		double y,
		double Energy,
		double Heading,
		double Velocity) {
		if (EI.getLastUpdateTime() == Time)
			EI.removeHistory(0);

		double angulardiff = Heading - EI.get_headingRadians();
		int timegap = (int) (Time - EI.getLastUpdateTime());

		double diffEnergy = EI.get_energy() - Energy;
		if (diffEnergy > 0 && diffEnergy <= 3) {
			if (timegap > 1) {
				double posx = (x + EI.get_x()) / 2;
				double posy = (y + EI.get_y()) / 2;
				double bearing =
					MathUtil.AbsoluteRadians(
						Math.atan2(posx - MyInfo.getX(), posy - MyInfo.getY()));
				double distance =
					MathUtil.Distance(posx, posy, MyInfo.getX(), MyInfo.getY());
				senseShooting(
					EI,
					posx,
					posy,
					diffEnergy,
					bearing,
					distance,
					(EI.getLastUpdateTime() + Time) / 2);
			} else {
				//				Debug.println("Fire  TIME" + Time);
				senseShooting(
					EI,
					EI.get_x(),
					EI.get_y(),
					diffEnergy,
					EI.getAbsBearingRadians(),
					EI.getDistance(),
					EI.getLastUpdateTime());
			}

		}

		if (timegap > 1) {
			//			Debug.println("Have Time Gap");
			double dist = MathUtil.Distance(EI.get_x(), EI.get_y(), x, y);

			if (angulardiff == 0) {
				double tmpx = EI.get_x();
				double tmpy = EI.get_y();
				double velocity = dist / timegap;

				for (long i = EI.getLastUpdateTime() + 1; i < Time; i++) {
					tmpx += velocity * Math.sin(Heading);
					tmpy += velocity * Math.cos(Heading);

					//			adjustOutOfBattleField
					if (tmpx < 0)
						tmpx = 20;
					if (tmpx > GameInfo.getBattleW())
						tmpx = GameInfo.getBattleW() - 20;
					if (tmpy < 0)
						tmpy = 20;
					if (tmpy > GameInfo.getBattleH())
						tmpy = GameInfo.getBattleH() - 20;
					//          end - adjustOutOfBattleField
					EI.addHistory(
						new StateData(
							i,
							tmpx,
							tmpy,
							Energy,
							Heading,
							velocity,
							0));
				}
				EI.addHistory(
					new StateData(Time, x, y, Energy, Heading, Velocity, 0));
			} else {
				double eachangle = angulardiff / timegap;
				double radius = dist / 2 / Math.sin(angulardiff / 2);
				double velocity = radius * eachangle;
				double centerx = x + Math.cos(Heading) * radius;
				double centery = y - Math.sin(Heading) * radius;
				double tmpx;
				double tmpy;

				long lasttime = EI.getLastUpdateTime();
				double lastheading = EI.get_headingRadians();

				for (int i = 1; i < timegap; i++) {
					tmpx =
						centerx
							- Math.cos(lastheading + eachangle * i) * radius;
					tmpy =
						centery
							+ Math.sin(lastheading + eachangle * i) * radius;
					//					adjustOutOfBattleField
					if (tmpx < 0)
						tmpx = 20;
					if (tmpx > GameInfo.getBattleW())
						tmpx = GameInfo.getBattleW() - 20;
					if (tmpy < 0)
						tmpy = 20;
					if (tmpy > GameInfo.getBattleH())
						tmpy = GameInfo.getBattleH() - 20;
					//					end - adjustOutOfBattleField
					EI.addHistory(
						new StateData(
							lasttime + i,
							tmpx,
							tmpy,
							Energy,
							lastheading + eachangle * i,
							velocity,
							eachangle));
				}
				EI.addHistory(
					new StateData(
						Time,
						x,
						y,
						Energy,
						Heading,
						Velocity,
						eachangle));
			}
		} else {
			EI.addHistory(
				new StateData(
					Time,
					x,
					y,
					Energy,
					Heading,
					Velocity,
					angulardiff));
		}
	}

	private void senseShooting(
		EnemyInfo info,
		double x,
		double y,
		double power,
		double bearing,
		double distance,
		long time) {

		//		double StationaryAngle = getStationaryAngle(bearing);
		//		double LinearAngle = getGuessedLinearAngle(power, bearing);
		double CircularAngle = getGuessedCircularAngle(power, x, y, bearing);
		double GuessFactorAngle =
			getGuessedShootingAngleByGF(info, bearing, power);

		//		double[] PredictAngle =
		//			new double[] {
		//				StationaryAngle,
		//				LinearAngle,
		//				CircularAngle,
		//				GuessFactorAngle };
		//		double[] PredictAngle = new double[] { GuessFactorAngle };
		//		double[] PredictAngle = new double[] { GuessFactorAngle, LinearAngle };
		double[] PredictAngle =
			new double[] { GuessFactorAngle, CircularAngle };

		// TODO ���� 

		info.addShootingData(
			x,
			y,
			power,
			bearing,
			distance,
			time,
			PredictAngle);
		if (Debug.isShowSenseShooting) {
			Debug.println(
				"\nsense shoot time " + time + "  Distnace : " + distance);
			Debug.println("enemy shoot : " + Math.toDegrees(GuessFactorAngle));
			Debug.println("guessed Position x : " + x + " y : " + y);

			Debug.println(
				"fangs bearing : "
					+ MathUtil.AbsoluteDegrees(Math.toDegrees(bearing + Math.PI))
					+ " diff: "
					+ Math.toDegrees(GuessFactorAngle - (bearing + Math.PI)));

		}
	}

	private double getStationaryAngle(double bearing) {
		return bearing + Math.PI;
	}

	private double getGuessedShootingAngleByGF(
		EnemyInfo info,
		double bearing,
		double power) {
		int distindex =
			GuessFactorPredictor.getDistanceIndex(info.getDistance());
		// TODO :: distance ���е� ��� 

		int bestGuessFactor =
			GuessFactorPredictor.getBestGuessFactor(
				info.get_fangsGuessFactorScoreMap(),
				distindex);

		if (Debug.isShowBestGF) {
			Debug.println(
				"dist:"
					+ info.getDistance()
					+ "  distindex:"
					+ distindex
					+ " bestGF: "
					+ bestGuessFactor);
			double[][] map = info.get_fangsGuessFactorScoreMap();
			for (int i = 0; i < map[0].length; i++) {
				Debug.print(map[distindex][i] + "  ");
			}
			Debug.println("");

		}

		double targetDirection =
			GuessFactorPredictor.getTargetDirection(
				MyInfo.getVelocity(),
				MyInfo.getHeadingRadians(),
				bearing + Math.PI);

		return GuessFactorPredictor.getAngleToFireByGuessFactor(
			bestGuessFactor,
			bearing + Math.PI,
			targetDirection);
	}

	private double getGuessedCircularAngle(
		double power,
		double x,
		double y,
		double bearing) {
		if (!CircularPredictor.isTargetTurning(MyInfo.get_angularVelocity()))
			return getGuessedLinearAngle(power, bearing);
		// ���� ��� �ƴϸ� �������� 
		Point2D.Double CenterPosition =
			CircularPredictor.getCenterOfCircul(
				MyInfo.getHeadingRadians(),
				MyInfo.getVelocity(),
				MyInfo.get_angularVelocity(),
				MyInfo.getX(),
				MyInfo.getY());

		return CircularPredictor.getAngleToFireByCircular(
			CenterPosition,
			power,
			MyInfo.get_angularVelocity(),
			MyInfo.getHeadingRadians(),
			MyInfo.getX(),
			MyInfo.getY(),
			x,
			y);
	}

	private double getGuessedLinearAngle(double power, double bearing) {
		double myBearing = MathUtil.AbsoluteRadians(bearing + Math.PI);
		double bulletvelocity = 20 - 3 * power;

		double projv =
			Math.sin(MyInfo.getHeadingRadians() - myBearing)
				* MyInfo.getVelocity();
		return MathUtil.AbsoluteRadians(
			myBearing + Math.asin(projv / bulletvelocity));
	}

	public void updateByBulletHit(String Name, double d) {
		EnemyInfo EI = getEnemyInfoByName(Name);
		updateByBulletHit(EI, d);
	}

	private boolean isContainEnemy(String Name) {
		return _enemymap.containsKey(Name);
	}

	public void updateByHit(String name, Bullet bullet, long time) {
		if (isContainEnemy(name)) {
			EnemyInfo ei = (EnemyInfo) getEnemyInfoByName(name);
			double E = ei.get_energy();
			ei.set_energy(E + 3 * bullet.getPower());
			// TODO :: searchBulletOrigin ���� �ϱ� 
			//			ei.searchBulletOrigin(bullet, time);
		}
	}

	public void updateByBulletHit(EnemyInfo EI, double E) {
		EI.set_energy(E);
	}

	public void onRippleHitEnemy(String name, MyFireData data, long time) {
		EnemyInfo info = getEnemyInfoByName(name);
		StateData state = info.getHistoryByTime(data.get_time());
		if (state == null) {
			return;
		}
		/* Guess Factor Update */
		double absBearingAtShoot =
			MathUtil.AbsoluteRadians(
				Math.atan2(
					state.get_x() - data.get_x(),
					state.get_y() - data.get_y()));
		double absHitBearing =
			MathUtil.AbsoluteRadians(
				Math.atan2(
					info.get_x() - data.get_x(),
					info.get_y() - data.get_y()));
		double targetDirection =
			GuessFactorPredictor.getTargetDirection(
				state.get_velocity(),
				state.get_headingRadians(),
				absBearingAtShoot);
		int factor =
			(int) (targetDirection
				* Math.toDegrees(
					MathUtil.relativeRadians(
						absHitBearing - absBearingAtShoot))
				+ 50);

		if (!data.isVictim(name)) {
			updateGuessFactor(
				info.getGuessFactorScoreMap(),
				factor,
				MathUtil.Distance(
					state.get_x(),
					state.get_y(),
					data.get_x(),
					data.get_y()));
			data.addVictim(name);
			if (Debug.isShowEnemyGFInfo) {
				Debug.println(
					"Update ----- ***** "
						+ "  currrentTime = "
						+ GameInfo.getTime()
						+ " distindex="
						+ GuessFactorPredictor.getDistanceIndex(
							MathUtil.Distance(
								state.get_x(),
								state.get_y(),
								data.get_x(),
								data.get_y()))
						+ " factor="
						+ factor
						+ "Shooting T : "
						+ data.get_time());
			}

			// TODO ::
			/* Accuracy Update */
			if (data.get_name().equals(info.get_id())) {
				ShootingOrder[] results = data.get_predictResults();
				double distance =
					MathUtil.Distance(
						info.get_x(),
						info.get_y(),
						data.get_x(),
						data.get_y());
				double HitRange = Math.abs(Math.atan(20 / distance));

				int[] accuracy = info.getAccuracyArray();

				boolean isAllMissed = true;

				for (int i = 0; i < results.length; i++) {
					if (results[i] != null
						&& Math.abs(results[i].get_radians() - absHitBearing)
							<= HitRange) {
						isAllMissed = false;
					}
				}

				if (!isAllMissed) {
					for (int i = 0; i < results.length; i++) {
						//					Debug.println(i);
						if (results[i] != null
							&& Math.abs(results[i].get_radians() - absHitBearing)
								<= HitRange) {
							//						Debug.println("Hit " + i);
							if (accuracy[i] < 5) {
								accuracy[i]++;
								//							Debug.println("UP " + i);
							}

						} else {
							//						Debug.println("Miss " + i);
							if (accuracy[i] > 0) {
								accuracy[i]--;
								//							Debug.println("Dwon " + i);
								// Missed
							}
						}
					}
				}
			}
			//				if (count == 0) {
			//			Debug.println(
			//				" ALL Miss  ALL Miss  ALL Miss  ALL Miss  ALL Miss \n");
			//			for (int i = 0; i < accuracy.length; i++)
			//				if (accuracy[i] != 0)
			//					accuracy[i]++;
			//		}

			/*Debug */
			if (Debug.isShowEnemyGFInfo) {
				Debug.println(
					"HitRipple"
						+ "  currrentTime = "
						+ GameInfo.getTime()
						+ " distindex="
						+ GuessFactorPredictor.getDistanceIndex(
							MathUtil.Distance(
								state.get_x(),
								state.get_y(),
								data.get_x(),
								data.get_y()))
						+ " factor="
						+ factor
						+ "Shooting T : "
						+ data.get_time());
			}

			if (Debug.isShowEnemyGFMapFile) {
				Debug.printToFile(
					"CurrentTime = "
						+ GameInfo.getTime()
						+ " distindex="
						+ GuessFactorPredictor.getDistanceIndex(
							MathUtil.Distance(
								state.get_x(),
								state.get_y(),
								data.get_x(),
								data.get_y()))
						+ " factor="
						+ factor
						+ "Shooting T : "
						+ data.get_time()
						+ "\n");
				Debug.printToFile(
					"absBearingAtShoot="
						+ absBearingAtShoot
						+ " absHitBearing="
						+ absHitBearing
						+ " targetDir="
						+ targetDirection
						+ "\n");
				double[][] tempMap = info.getGuessFactorScoreMap();

				MessageFormat mf = new MessageFormat("{0,number,#.##}");
				for (int j = 0; j < tempMap[0].length; j++) {
					Object[] objs = { new Double(j / 100.0)};
					String result = mf.format(objs);

					Debug.printToFile(" " + result + " ");
				}
				Debug.printToFile("\n");
				for (int i = 0; i < tempMap.length; i++) {
					for (int j = 0; j < tempMap[i].length; j++) {
						Object[] objs = { new Double(tempMap[i][j])};
						String result = mf.format(objs);

						Debug.printToFile(" " + result + " ");
					}
					Debug.printToFile("\n");
				}
				Debug.printToFile("\n");

			}
		}
	}

	private void updateGuessFactor(
		double[][] map,
		int factor,
		double distance) {
		//TODO SIDE EFFECT ��� 
		int distindex = GuessFactorPredictor.getDistanceIndex(distance);
		for (int i = 0; i < map[0].length; i++) {
			map[distindex][i] *= 0.99;
		}

		updateStrikedFactor(map, factor, distance);
		updateNearFactor(map, factor, distance);

	}

	private void updateNearFactor(
		double[][] map,
		int factor,
		double distance) {
		int distindex = GuessFactorPredictor.getDistanceIndex(distance);
		long near =
			Math.round(
				Math.atan(
					30 / GuessFactorPredictor.getDistanceIndex(distance)));

		try {
			for (int i = 1; i < near; i++) {
				map[distindex][factor + i] = 0.1;
				map[distindex][factor - i] = 0.1;
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			Debug.println(e.toString());
		}

	}

	private void updateStrikedFactor(
		double[][] map,
		int factor,
		double distance) {
		int distindex = GuessFactorPredictor.getDistanceIndex(distance);
		if (factor >= 0 && factor < map[0].length)
			map[distindex][factor] += 0.1;

	}

	public void onRippleHitFangs(String name, ShootingData data, long l) {

		EnemyInfo info = getEnemyInfoByName(name);

		double absBearingAtShoot = data.get_mybearing();

		double absHitBearing =
			MathUtil.AbsoluteRadians(
				Math.atan2(
					MyInfo.getX() - data.get_x(),
					MyInfo.getY() - data.get_y()));

		double targetDirection =
			GuessFactorPredictor.getTargetDirection(
				data.get_myvelocity(),
				data.get_myheading(),
				absBearingAtShoot);

		int factor =
			(int) (targetDirection
				* Math.toDegrees(
					MathUtil.relativeRadians(
						absHitBearing - absBearingAtShoot))
				+ 50);

		//		int distindex =
		//			GuessFactorPredictor.getDistanceIndex(data.get_distance());

		if (!data.isRippleHitFang()) {
			if (Debug.isShowRippleHitFangs) {

				Debug.println(
					"  RippleHitFangs-bear HitTime"
						+ GameInfo.getTime()
						+ " ShootTime: "
						+ data.get_stamptime()
						+ "\nshootint Abs Bearing : "
						+ Math.toDegrees(absBearingAtShoot)
						+ "   hit bear  : "
						+ Math.toDegrees(absHitBearing)
						+ "  my Dire : "
						+ targetDirection
						+ " distance: "
						+ data.get_distance());

				Debug.println(
					"my position : " + MyInfo.getX() + "  -  " + MyInfo.getY());
				Debug.println(
					"   shooting shooter position when shooting : "
						+ data.get_x()
						+ "   -   "
						+ data.get_y()
						+ " velocity"
						+ data.get_velocity());

				Debug.println("");

			}
			data.setRippleHitFang(true);
			updateGuessFactor(
				info.get_fangsGuessFactorScoreMap(),
				factor,
				data.get_distance());
		}

	}

	public void setAccuracyToZero(String name, int bestindex) {
		EnemyInfo info = getEnemyInfoByName(name);
		int[] accuracy = info.getAccuracyArray();
		accuracy[bestindex] = 0;
		// bad smell

	}

	//	double absHitRadians =
	//			MathUtil.AbsoluteRadians(
	//				Math.atan2(
	//					MyInfo.getX() - get_originX(),
	//					MyInfo.getY() - get_originY()));
	//		double gapHitRadians =
	//			MathUtil.relativeRadians(absHitRadians - get_absBearing());
	//
	//		double targetDirection = 1;
	//		if (get_selfVelocityWhenShooting() != 0) {
	//			targetDirection =
	//				get_selfVelocityWhenShooting()
	//					* Math.sin(get_selfAbsHeadingRadian() - get_absBearing());
	//		}
	//
	//		targetDirection /= Math.abs(targetDirection);
}
