/*
 * Created on 2003. 5. 10.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.enemy;

import java.util.ArrayList;

import fangs.predict.PredictorManager;
import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class EnemyInfo {
	boolean _alive;
	ArrayList _shootinghistory;
	ArrayList _history;
	String _id;
	StateData _latestData;
	int[] Accuracy;

	int _matchoffset;
	double[][] radianFactorWeight = new double[11][101];
	double[][] _fangsGuessFactorScoreMap = new double[11][101];

	public EnemyInfo(
		String ID,
		double X,
		double Y,
		double Energy,
		double Velocity,
		double HeadingRadians,
		long Timestamp) {
		_id = ID;
		_alive = true;
		_history = new ArrayList();
		_shootinghistory = new ArrayList();
		_latestData =
			new StateData(Timestamp, X, Y, Energy, HeadingRadians, Velocity, 0);
		_history.add(0, _latestData);
		initFactors();

		Accuracy = new int[PredictorManager.getPredictorsNumber()];
	}

	public void initFactors() {
		for (int j = 0; j < radianFactorWeight.length; j++)
			for (int i = 0; i < radianFactorWeight[0].length; i++) {
				radianFactorWeight[j][i] = 1.0000001;
				_fangsGuessFactorScoreMap[j][i] = 1.000001;
			}
	}

	public void clearRoundData() {
		_shootinghistory.clear();
		_history.clear();
	}

	public double getAbsBearingRadians() {
		return MathUtil.AbsoluteRadians(
			Math.atan2(
				_latestData.get_x() - MyInfo.getX(),
				_latestData.get_y() - MyInfo.getY()));
	}

	public double get_angularvelocity() {
		return _latestData.get_angularvelocity();
	}

	public double get_energy() {
		return _latestData.get_energy();
	}

	public double get_headingRadians() {
		return _latestData.get_headingRadians();
	}

	public String get_id() {
		return _id;
	}

	public int get_matchoffset() {
		return _matchoffset;
	}

	public long getLastUpdateTime() {
		return _latestData.get_timestamp();
	}

	public double get_velocity() {
		return _latestData.get_velocity();
	}

	public double get_x() {
		return _latestData._x;
	}

	public double get_y() {
		return _latestData._y;
	}

	public double getDistance() {
		return MathUtil.Distance(
			MyInfo.getX(),
			MyInfo.getY(),
			_latestData.get_x(),
			_latestData.get_y());
	}

	public StateData[] getEnemyDataRecordArray() {
		return (StateData[]) _history.toArray(new StateData[0]);
	}

	public ArrayList getEnemyShootingDataArray() {
		return _shootinghistory;
	}

	public StateData getHistory(int past) {
		if (past > _history.size() - 1)
			return null;
		return (StateData) _history.get(past);
	}

	public double[][] getGuessFactorScoreMap() {
		return radianFactorWeight;
	}

	public boolean isAlive() {
		return _alive;
	}

	public void set_alive(boolean b) {
		_alive = b;
	}

	public void set_matchoffset(int l) {
		_matchoffset = l;
	}

	public void set_energy(double d) {
		_latestData.set_energy(d);
	}

	public void addHistory(StateData record) {
		_history.add(0, record);
		while (_history.size() > 500) {
			_history.remove(500);
		}
		_latestData = record;
	}

	public double[][] get_fangsGuessFactorScoreMap() {
		return _fangsGuessFactorScoreMap;
	}

	public void removeHistory(int i) {
		_history.remove(i);
		_latestData = (StateData) _history.get(0);
	}

	public ShootingData[] getShootingDataArray() {
		return (ShootingData[]) _shootinghistory.toArray(new ShootingData[0]);
	}

	public ShootingData addShootingData(
		double x,
		double y,
		double power,
		double bearing,
		double distance,
		long time,
		double[] angles) {
		ShootingData tmpfire =
			new ShootingData(x, y, power, bearing, distance, time, angles);
		_shootinghistory.add(0, tmpfire);
		return tmpfire;
	}

	public StateData getHistoryByTime(long time) {
		StateData[] states = (StateData[]) _history.toArray(new StateData[0]);

		for (int i = 0; i < states.length; i++) {
			if (states[i].get_timestamp() == time)
				return states[i];
		}
		return null;
	}

	public void removeShootigData(ShootingData data) {
		_shootinghistory.remove(data);
	}

	public int[] getAccuracyArray() {
		return Accuracy;
	}

}
//	public void searchBulletOrigin(Bullet bullet, long time) {
//		ShootingData matcheddata = null;
//		double power = bullet.getPower();
//		double velocity = bullet.getVelocity();
//		double distance;
//		if (_Predictcount < _PredictAngleRate.length)
//			_Predictcount++;
//		ShootingData[] firerecords =
//			(ShootingData[]) _shootinghistory.toArray(new ShootingData[0]);
//		for (int i = 0; i < firerecords.length; i++) {
//			long deadtime =
//				(long) (GameInfo.getBattleW() / firerecords[i].get_velocity());
//			long gaptime = time - firerecords[i].get_stamptime();
//
//			if (gaptime > deadtime || gaptime < 0) {
//				_shootinghistory.remove(firerecords[i]);
//				continue;
//			}
//			distance =
//				MathUtil.Distance(
//					bullet.getX(),
//					bullet.getY(),
//					firerecords[i].get_x(),
//					firerecords[i].get_y());
//
//			long GT = Math.abs(gaptime - (int) (distance / velocity));
//
//			if (GT <= 2) {
//				matcheddata = firerecords[i];
//				continue;
//			}
//		}
//		if (matcheddata != null) {
//			double bullethead = bullet.getHeadingRadians();
//			double mybear = matcheddata.get_mybearing();
//			double mylinear = matcheddata.get_linear();
//
//			double gaplinear = mylinear - mybear;
//			if (gaplinear < 0.0001)
//				return;
//			double gapreal = bullethead - mybear;
//			_PredictAngleRate[_Predictindex] = gapreal / gaplinear;
//
//			double dist = matcheddata.get_distance();
//			_PredictDistance[_Predictindex] = dist * Math.tan(gapreal);
//			firerecords =
//				(ShootingData[]) _shootinghistory.toArray(new ShootingData[0]);
//			for (int i = 0; i < firerecords.length; i++) {
//				firerecords[i].removeGPBsAll();
//				mybear = firerecords[i].get_mybearing();
//				double ratepredictangle =
//					(firerecords[i].get_linear() - mybear)
//						* _PredictAngleRate[_Predictindex]
//						+ mybear;
//				GravPointBullet gpbullet =
//					new GravPointBullet(
//						firerecords[i].get_x(),
//						firerecords[i].get_y(),
//						firerecords[i].get_power(),
//						ratepredictangle,
//						1.8,
//						firerecords[i].get_stamptime());
//				GravPointManager.addGravPoint(gpbullet);
//
//				dist = firerecords[i].get_distance();
//				double distpredict =
//					Math.tan(_PredictDistance[_Predictindex] / dist) + mybear;
//				gpbullet =
//					new GravPointBullet(
//						firerecords[i].get_x(),
//						firerecords[i].get_y(),
//						firerecords[i].get_power(),
//						distpredict,
//						1.8,
//						firerecords[i].get_stamptime());
//				GravPointManager.addGravPoint(gpbullet);
//			}
//			_Predictindex++;
//			if (_Predictindex >= _Predictcount)
//				_Predictindex = 0;
//		} else {
//			//			Debug.println("Unmatch");
//		}
//		if (matcheddata != null)
//			removeFireDataRecord(matcheddata);
//
//	}
//}