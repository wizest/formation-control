/*
 * Created on 2003. 5. 17.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.enemy;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class StateData {
	long _timestamp;
	double _x, _y;
	double _energy;
	double _headingRadians;
	double _velocity;
	double _angularvelocity;

	public StateData(
		long time,
		double x,
		double y,
		double Energy,
		double Heading,
		double Velocity,
		double angle) {
		_timestamp = time;
		_x = x;
		_y = y;
		_energy = Energy;
		_headingRadians = Heading;
		_velocity = Velocity;
		_angularvelocity = angle;
	}

	/**
	 * @return
	 */
	public double get_energy() {
		return _energy;
	}

	/**
	 * @return
	 */
	public double get_headingRadians() {
		return _headingRadians;
	}

	/**
	 * @return
	 */
	public long get_timestamp() {
		return _timestamp;
	}

	/**
	 * @return
	 */
	public double get_velocity() {
		return _velocity;
	}

	/**
	 * @return
	 */
	public double get_x() {
		return _x;
	}

	/**
	 * @return
	 */
	public double get_y() {
		return _y;
	}

	/**
	 * @param d
	 */
	public void set_energy(double d) {
		_energy = d;
	}

	/**
	 * @return
	 */
	public double get_angularvelocity() {
		return _angularvelocity;
	}

}
