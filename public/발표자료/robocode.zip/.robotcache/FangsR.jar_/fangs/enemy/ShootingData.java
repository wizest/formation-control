/*
 * Created on May 28, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.enemy;

import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author cse19
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ShootingData {
	private long _stamptime;
	private double _power, _velocity, _x, _y, _mybearing, _distance;
	private double[] _guessAngles;
	private double _myvelocity, _myheading;
	private boolean isRippleHitFang;


	public ShootingData(
		double posx,
		double posy,
		double Power,
		double Bearing,
		double distance,
		long time,
		double[] angles) {
		_stamptime = time;
		_x = posx;
		_y = posy;
		_power = Power;
		_velocity = 20 - 3 * _power;
		_mybearing = MathUtil.AbsoluteRadians(Bearing + Math.PI);
		_distance = distance;
		_guessAngles = angles;
		
//		Debug.println("Make Shooting Data Time ::: " + time);

		_myvelocity = MyInfo.getVelocity();
		_myheading = MyInfo.getHeadingRadians();
		isRippleHitFang = false;
	}

	public double getDamage() {
		double damage = _power * 4;
		if (_power > 1) {
			damage += 2 * (_power - 1);
		}
		return damage;
	}

	public double get_power() {
		return _power;
	}

	public long get_stamptime() {
		return _stamptime;
	}

	public double get_velocity() {
		return _velocity;
	}

	public double get_x() {
		return _x;
	}

	public double get_y() {
		return _y;
	}

	public double get_mybearing() {
		return _mybearing;
	}

	public double get_distance() {
		return _distance;
	}
	public double[] get_guessAngles() {
		return _guessAngles;
	}

	public double get_myheading() {
		return _myheading;
	}

	public double get_myvelocity() {
		return _myvelocity;
	}

	public boolean isRippleHitFang() {
		return isRippleHitFang;
	}

	public void setRippleHitFang(boolean b) {
		isRippleHitFang = b;
	}

}