package fangs.utility;

public class MathUtil 
{
	static public double AbsoluteRadians( double R)
	{
		while (R < 0)
			R += Math.PI * 2;
		while (R >= 2 * Math.PI)
			R -= Math.PI * 2;
		return R;
	}

	static public double AbsoluteDegrees(double D)
	{
		while (D >= 360)
			D -= 360;
		while (D < 0)
			D += 360;
		return D;
	}

	static public double relativeRadians( double R)
	{
		while (R <= -Math.PI)
			R += Math.PI * 2;
		while (R > Math.PI)
			R -= Math.PI * 2;
		return R;
	}

	static public double relativeDegrees( double D)
	{
		while (D < -180)
			D += 360;
		while (D >= 180)
			D -= 360;
		return D;
	}

	static public double Distance( double x1, double y1, double x2, double y2)
	{
		double x = x2 - x1;
		double y = y2 - y1;
		return Math.sqrt( y * y + x * x);
	}
}