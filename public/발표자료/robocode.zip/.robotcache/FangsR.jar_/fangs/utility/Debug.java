/*
 * Created on 2003. 5. 11.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.utility;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import robocode.RobocodeFileOutputStream;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Debug {
	public static boolean isShowEndData = false;
	public static boolean isShowLeadPointInfoForConerMovement = false;
	public static boolean isShowLinear = false;
	public static boolean isShowPredicInfo = true;
	public static boolean isShowRippleHitFangs = false;
	public static boolean isShowBestGF = false;
	public static boolean isShowShoot = true;
	public static boolean isShowEnemyGFMapFile = false;
	public static boolean isShowEnemyGFInfo = false;
	public static boolean isShowGPS = false;
	public static boolean isShowDriverCall = false;
	public static boolean isShowSenseShooting = false;
	public static boolean isShowScanEvent = false;

	static PrintStream _out;
	static FileOutputStream _fout;

	public static void setOut(PrintStream OUT) {
		_out = OUT;
	}

	public static void println(String STR) {
		_out.println(STR);
	}

	public static void println(int i) {
		_out.println(i);
	}

	public static void println(double d) {
		_out.println(d);
	}
	//	public static void fprintln(String toLog, String filename) {
	//		try {
	//
	//			File outputFile = new File(filename);
	//			FileWriter fout = new FileWriter(outputFile, true);
	//			fout.write(toLog);
	//			fout.close();
	//		} catch (Exception ee) {
	//			ee.printStackTrace();
	//		}
	//	}

	/**
	 * @param string
	 */
	public static void print(String string) {
		_out.print(string);

	}

	public static void printToFile(String msg) {
		try {

			PrintStream w =
				new PrintStream(
					new RobocodeFileOutputStream(
						MyInfo._robo.getDataFile("result.dat").getPath(),
						true));
			w.print(msg);
			// PrintStreams don't throw IOExceptions during prints,
			// they simply set a flag.... so check it here.
			if (w.checkError())
				_out.println("I could not write the count!");
			w.close();
		} catch (IOException e) {
			_out.println("IOException trying to write: " + e);
		}

	}
	public static void main(String args[]) {
		for (int i = 1; i < 15; i += 1) {
			double dist = Math.pow(i, 2) * 10;
			System.out.println(
				"dist : "
					+ dist
					+ " atan   "
					+ Math.toDegrees(Math.atan(20 / dist)));

		}

		System.out.println(786 * Math.tan(Math.toRadians(5)));

	}
}
