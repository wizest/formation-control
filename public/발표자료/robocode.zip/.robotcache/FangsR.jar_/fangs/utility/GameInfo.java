package fangs.utility;

import robocode.AdvancedRobot;

public class GameInfo {
	static double _battlew, _battleh;
	static AdvancedRobot _myrobo;
	static int _otherbots;
	static String _roboname;

	static public int getAllOthers() {
		return _otherbots;
	}

	static public double getBattleH() {
		return _battleh;
	}

	static public double getBattleW() {
		return _battlew;
	}

	static public int getOthers() {
		return _myrobo.getOthers();
	}

	public static long getTime() {
		return _myrobo.getTime();
	}

	static public int getRoundNum() {

		return _myrobo.getRoundNum();
	}

	static public void setRobot(AdvancedRobot R) {
		_myrobo = R;
		_battlew = R.getBattleFieldWidth();
		_battleh = R.getBattleFieldHeight();
		_roboname = R.getName();
		_otherbots = R.getOthers();
	}

}
