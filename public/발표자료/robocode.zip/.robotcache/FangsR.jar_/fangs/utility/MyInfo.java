/*
 * Created on 2003. 5. 14.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.utility;

import robocode.AdvancedRobot;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class MyInfo {
	static AdvancedRobot _robo;
	static boolean _isTooCloseToWall;
	static double _angularVelocity;

	static double _oldheading;
	static double _oldvelocity;
	static double _oldx;
	static double _oldy;

	static long _oldUpdateTime = -1;

	public static void updateMyInfo() {
		_angularVelocity = _robo.getHeadingRadians() - _oldheading;
		_oldheading = _robo.getHeadingRadians();
	}

	public static double getGunHeadingRadians() {
		return _robo.getGunHeadingRadians();
	}

	public static double getHeadingRadians() {
		return _robo.getHeadingRadians();
	}

	public static double getRadarHeadingRadians() {
		return _robo.getRadarHeadingRadians();
	}

	public static double getGunTurnRemaining() {
		return _robo.getGunTurnRemaining();
	}

	public static double getRadarTurnRemainingRadians() {
		return _robo.getRadarTurnRemainingRadians();
	}

	public static double getX() {
		return _robo.getX();
	}

	public static double getY() {
		return _robo.getY();
	}

	public static void setRobot(AdvancedRobot R) {
		_robo = R;
	}

	public static double getGunHeat() {
		return _robo.getGunHeat();
	}

	/**
	 * @return
	 */
	public static double getVelocity() {
		return _robo.getVelocity();
	}

	/**
	 * @return
	 */
	public static double getEnergy() {
		return _robo.getEnergy();
	}

	/**
	 * @return
	 */
	public static double get_angularVelocity() {
		return _angularVelocity;
	}
	public static double getNearWallDistance() {
		return Math.min(
			MyInfo.getX(),
			Math.min(
				MyInfo.getY(),
				Math.min(
					GameInfo.getBattleH() - MyInfo.getY(),
					GameInfo.getBattleW() - MyInfo.getX())));
	}
	public static boolean isTooCloseToWall() {
		if (getNearWallDistance() < 30) {
			_isTooCloseToWall = true;
		}
		if (getNearWallDistance() > 110) {
			_isTooCloseToWall = false;
		}

		return _isTooCloseToWall;

	}

	public static double get_oldheading() {
		return _oldheading;
	}

	public static double get_oldvelocity() {
		return _oldvelocity;
	}

//	public static double get_oldx() {
//		return _oldx;
//	}
//
//	public static double get_oldy() {
//		return _oldy;
//	}

	public static void UpdateOldMyinfo() {
		if (_oldUpdateTime != GameInfo.getTime()) {
			_oldUpdateTime = GameInfo.getTime();
			_oldheading = getHeadingRadians();
			_oldvelocity = getVelocity();
			_oldx = getX();
			_oldy = getY();
		}
	}

}
