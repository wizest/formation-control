/*
 * Created on May 29, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.ripple;

import java.util.ArrayList;

import robocode.Bullet;
import fangs.FangR;
import fangs.enemy.EnemyInfo;
import fangs.enemy.EnemyInfoManager;
import fangs.enemy.ShootingData;
import fangs.predict.PredictorManager;
import fangs.tactician.Tactician;
import fangs.utility.GameInfo;
import fangs.utility.MathUtil;
import fangs.utility.MyInfo;

/**
 * @author cse19
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class RippleManager {
	EnemyInfoManager _enemymgr;
	PredictorManager _predictmgr;
	private ArrayList MyFireHistory;

	public RippleManager() {
		_enemymgr = FangR.enemymgr;
		_predictmgr = FangR.predictormgr;
		MyFireHistory = new ArrayList();
	}

	public void reportFireBullet(Bullet bullet) {
		MyFireHistory.add(
			new MyFireData(
				MyInfo.getX(),
				MyInfo.getY(),
				bullet.getVelocity(),
				GameInfo.getTime(),
				_predictmgr.getAllPredictResult(),
				Tactician.get_target().get_id()));
	}

	private void checkHitToEnemy() {
		//		Debug.println("checking Hit TO Enemies");
		MyFireData[] firehitorys =
			(MyFireData[]) MyFireHistory.toArray(new MyFireData[0]);
		EnemyInfo[] enemies = _enemymgr.getEnemiesArray();
		long nowtime = GameInfo.getTime();

		for (int i = 0; i < firehitorys.length; i++) {
			//			Debug.println("In FOR LOOP1");

			double tmpx, tmpy;
			tmpx = firehitorys[i].get_x();
			tmpy = firehitorys[i].get_y();
			double flyingdistance =
				firehitorys[i].get_velocity()
					* (nowtime - firehitorys[i].get_time());

			if (flyingdistance > getLongerDistanceToWall(tmpx, tmpy)) {
				MyFireHistory.remove(firehitorys[i]);
				break;
			}

			for (int j = 0; j < enemies.length; j++) {

				if (enemies[j].isAlive()) {

					double distance =
						MathUtil.Distance(
							tmpx,
							tmpy,
							enemies[j].get_x(),
							enemies[j].get_y());

					double diffdistance = flyingdistance - distance;
					//				Debug.println("diffdist : " + diffdistance);
					if (diffdistance >= 0 && diffdistance < 20) {
						//					Debug.println("In FOR LOOP2");
						//					Debug.println("Ripple Hit Enemy" + enemies[i].get_id());
						_enemymgr.onRippleHitEnemy(
							enemies[j].get_id(),
							firehitorys[i],
							GameInfo.getTime());
					}
				}
			}

		}
	}

	private static double getLongerDistanceToWall(double x, double y) {
		if (x < (GameInfo.getBattleW() / 2))
			x = GameInfo.getBattleW() - x;
		if (y < (GameInfo.getBattleH() / 2))
			y = GameInfo.getBattleH() - y;
		return MathUtil.Distance(x, y, 0, 0);
	}

	private void checkHitByEnemy() {
		EnemyInfo[] enemies = _enemymgr.getEnemiesArray();
		if (enemies == null)
			return;
		long nowtime = GameInfo.getTime();

		for (int i = 0; i < enemies.length; i++) {
			ShootingData[] fires = enemies[i].getShootingDataArray();
			for (int j = 0; j < fires.length; j++) {
				double distance =
					MathUtil.Distance(
						fires[j].get_x(),
						fires[j].get_y(),
						MyInfo.getX(),
						MyInfo.getY());

				double flyingdistance =
					fires[j].get_velocity()
						* (nowtime - fires[j].get_stamptime());

				if (flyingdistance
					> getLongerDistanceToWall(
						fires[j].get_x(),
						fires[j].get_y())) {
					enemies[i].removeShootigData(fires[j]);
					break;
				}

				double diffdistance = flyingdistance - distance;
				if (diffdistance > 0 && diffdistance < 20) {
					_enemymgr.onRippleHitFangs(
						enemies[i].get_id(),
						fires[j],
						GameInfo.getTime());
				}
			}
		}
	}

	public void checkRippleHit() {
		checkHitToEnemy();
		checkHitByEnemy();
	}
}
