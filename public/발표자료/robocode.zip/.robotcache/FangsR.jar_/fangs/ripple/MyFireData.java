/*
 * Created on 2003. 6. 26.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs.ripple;

import java.util.ArrayList;

import fangs.predict.ShootingOrder;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class MyFireData {
	double _x, _y, _velocity;
	long _time;
	ShootingOrder[] _predictResults;
	ArrayList _victimList;
	String _name;

	public MyFireData(
		double posx,
		double posy,
		double velocity,
		long time,
		ShootingOrder[] results,
		String Name) {
		_x = posx;
		_y = posy;
		_velocity = velocity;
		_time = time;
		_predictResults = results;
		_victimList = new ArrayList();
		_name = Name;
	}

	public long get_time() {
		return _time;
	}

	public double get_velocity() {
		return _velocity;
	}

	public double get_x() {
		return _x;
	}

	public double get_y() {
		return _y;
	}

	public ShootingOrder[] get_predictResults() {
		return _predictResults;
	}

	public boolean isVictim(String name) {
		return _victimList.contains(name);

	}

	public void addVictim(String name) {
		_victimList.add(name);

	}

	public String get_name() {
		return _name;
	}

}
