/*
 * Created on 2003. 5. 10.
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package fangs;

import java.awt.Color;

import robocode.AdvancedRobot;
import robocode.BulletHitBulletEvent;
import robocode.BulletHitEvent;
import robocode.BulletMissedEvent;
import robocode.DeathEvent;
import robocode.HitByBulletEvent;
import robocode.HitRobotEvent;
import robocode.HitWallEvent;
import robocode.RobotDeathEvent;
import robocode.ScannedRobotEvent;
import robocode.WinEvent;
import fangs.driver.Driver;
import fangs.enemy.EnemyInfoManager;
import fangs.gravpoint.GravPointManager;
import fangs.predict.PredictorManager;
import fangs.ripple.RippleManager;
import fangs.scaner.Scanner;
import fangs.tactician.Tactician;
import fangs.utility.Debug;
import fangs.utility.GameInfo;
import fangs.utility.MyInfo;

/**
 * @author vollfeed
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class FangR extends AdvancedRobot {
	Scanner _scanner;
	Driver _driver;
	Shooter _shooter;
	Tactician _tactician;
	EventHandler _eventhandler;

	public static RippleManager ripplemgr;
	public static EnemyInfoManager enemymgr;
	public static GravPointManager gravpointmgr;
	public static PredictorManager predictormgr;

	private long _hitCount;
	private double _hitDamage;
	public long fire;
	public long hit;
	public double firedamage;
	public double hitdamage;

	public void run() {
		initDebug();
		init();
		while (true) {
			MyInfo.updateMyInfo();
			ripplemgr.checkRippleHit();
			_tactician.makeplan();
			_scanner.scan();
			_driver.drive();
			_shooter.shoot();
			//			out.println("time : " + getTime() + "  position : " + getX() + "  -  " + getY());

			MyInfo.UpdateOldMyinfo();
			//			out.println("x : " + getX() + "  y : " + getY());
			execute();
		}
	}

	public void initDebug() {
		Debug.setOut(out);
	}

	public void init() {
		setColors(Color.CYAN, Color.MAGENTA, Color.YELLOW);
		setAdjustGunForRobotTurn(true);
		setAdjustRadarForGunTurn(true);
		setAdjustRadarForRobotTurn(true);

		GameInfo.setRobot(this);
		MyInfo.setRobot(this);

		predictormgr = new PredictorManager();
		if (getRoundNum() < 1)
			enemymgr = new EnemyInfoManager();
		else {

			enemymgr.clearRoundData();
		}
		gravpointmgr = new GravPointManager();
		ripplemgr = new RippleManager();

		_scanner = new Scanner(this);
		_driver = new Driver(this);
		_tactician = new Tactician(this);
		_shooter = new Shooter(this);
		_eventhandler = new EventHandler(enemymgr);
	}

	public void onScannedRobot(ScannedRobotEvent e) {
		_eventhandler.handlingOnScannedRobot(e);
	}

	public void onBulletHit(BulletHitEvent e) {
		_hitCount++;
		//		out.println("POWERRRRRR="+e.getBullet().getPower()+"-"+_hitDamage);
		_hitDamage += (e.getBullet().getPower()) > 1
			? (e.getBullet().getPower() * 4) + 2 * (e.getBullet().getPower() - 1)
			: (e.getBullet().getPower() * 4);
		//		out.println("\ni hit that!! ");
		_eventhandler.handlingBulletHit(e);
	}

	public void onBulletHitBullet(BulletHitBulletEvent e) {
		_eventhandler.handlingBulletHitBullet(e);
	}

	public void onBulletMissed(BulletMissedEvent e) {
		_eventhandler.handlingBulletMissed(e);
	}

	public void onHitByBullet(HitByBulletEvent e) {
		//		out.println("Hit Real Bullet  Shooter : " + e.getName());
		_eventhandler.handlingHitByBullet(e);

		//		Bullet b = e.getBullet();
		//		EnemyInfo E = enemymgr.getEnemyInfoByName(e.getName());
		//		double dist =
		//			MathUtil.Distance(b.getX(), b.getY(), E.get_x(), E.get_y());
		//		double v = b.getVelocity();
		//
		//		double TT = dist / v;
		//		Debug.println("TT :  " + TT + "  Time : " + GameInfo.getTime());

		double p = e.getPower();
		double d = 4 * p;
		if (p >= 1) {
			d += (p - 1) * 2;
		}
		hitdamage += d;
		hit++;
	}

	public void onDeath(DeathEvent e) {
		if (Debug.isShowEndData) {

			out.println("EN fire : " + fire + "   EN hit : " + hit);
			out.println(
				"EN fire D : " + firedamage + "  EN hit D : " + hitdamage);
			out.println(
				"EN hit rate : "
					+ ((double) hit / (double) fire * 100.0)
					+ " %");
			out.println(
				"EN hit D rate : " + (hitdamage / firedamage * 100) + " %");

			out.println(
				"fireCount="
					+ _shooter.get_fireCount()
					+ "   HitCount"
					+ _hitCount);
			out.println(
				"percent : "
					+ (100
						* (double) _hitCount
						/ (double) _shooter.get_fireCount())
					+ "%");
			out.println(
				"fireD=" + _shooter.get_hitDamage() + "   HitD" + _hitDamage);
		}
	}

	public void onHitRobot(HitRobotEvent e) {
		_tactician.hitRobot();
	}

	public void onHitWall(HitWallEvent e) {
		_tactician.hitRobot();
	}

	public void onRobotDeath(RobotDeathEvent e) {
		enemymgr.ReportDeath(e.getName());
	}

	public void onWin(WinEvent e) {
		if (Debug.isShowEndData) {
			out.println("EN fire : " + fire + "   EN hit : " + hit);
			out.println(
				"EN fire D : " + firedamage + "  EN hit D : " + hitdamage);
			out.println(
				"EN hit rate : "
					+ ((double) hit / (double) fire * 100.0)
					+ " %");
			out.println(
				"EN hit D rate : " + (hitdamage / firedamage * 100) + " %");

			out.println(
				"fireCount="
					+ _shooter.get_fireCount()
					+ "   HitCount"
					+ _hitCount);
			out.println(
				"percent : "
					+ (100
						* (double) _hitCount
						/ (double) _shooter.get_fireCount())
					+ "%");
			out.println(
				"fireD=" + _shooter.get_hitDamage() + "   HitD" + _hitDamage);
		}

		Shooter.setShooting(false);
	}

	/**
	 * @return
	 */
	public long getFire() {
		return fire;
	}

	/**
	 * @return
	 */
	public double getFiredamage() {
		return firedamage;
	}

	/**
	 * @return
	 */
	public long getHit() {
		return hit;
	}

	/**
	 * @return
	 */
	public double getHitdamage() {
		return hitdamage;
	}

	/**
	 * @param l
	 */
	public void setFire(long l) {
		fire = l;
	}

	/**
	 * @param d
	 */
	public void setFiredamage(double d) {
		firedamage = d;
	}

	/**
	 * @param l
	 */
	public void setHit(long l) {
		hit = l;
	}

	/**
	 * @param d
	 */
	public void setHitdamage(double d) {
		hitdamage = d;
	}

	public Driver get_driver() {
		return _driver;
	}

}
