package se.move;

import robocode.*;
import se.utils.*;
import se.scan.*;
import robocode.util.Utils;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import java.awt.geom.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MoveWave
    extends Wave {
  static final int DISTANCE_INDEX = 5;
  static final int VELOCITY_INDEX = 5;
  static final int VELOCITY_CHANGE_INDEX = 4;
  static final int GUESS = 45;
  static final int HALF_GUESS = (GUESS - 1) / 2;

  static double[][][][][] visitCounts = new double[DISTANCE_INDEX][
      VELOCITY_INDEX][VELOCITY_CHANGE_INDEX][VELOCITY_CHANGE_INDEX][GUESS];
  static double[][][][] hitCountsTimer = new double[DISTANCE_INDEX][
      VELOCITY_CHANGE_INDEX][VELOCITY_CHANGE_INDEX][GUESS];
  static double[][][][] hitCountsVelocity = new double[DISTANCE_INDEX][
      VELOCITY_INDEX][VELOCITY_INDEX][GUESS];
  static double[] fastHitCounts = new double[GUESS];

  static double warningForward;
  static double warningReverse;
  static double warningStop;
  static List waves = new ArrayList();
  static List surfables = new ArrayList();
  static double hited;

  boolean smooth;
  Movement move;
  int distanceIndex;
  int velocityIndex;
  int lastVelocityIndex;
  int accelIndex;
  int deccelIndex;
  boolean visitRegistered;

  static void reset() {
    waves = new ArrayList();
    surfables = new ArrayList();
    warningForward = 0;
    warningReverse = 0;
    warningStop = 0;
  }

  public MoveWave(Movement move) {
    init(GUESS);
    this.move = move;
  }

  public boolean test() {
    flow(1);
    waves.add(this);
    if (through( -18)) {
      if (!visitRegistered) {
        registerVisit();
        visitRegistered = true;
      }
    }
    if (through(18)) {
      RobotInfo.getRobot().removeCustomEvent(this);
    }
    if (smooth) { //���� �Ѿ��� �߻� ������
      surfables.add(this);
      move.updateDirectionStats(this);
      if (through(0)) {
        move.stopWave = null;
      }
    }
    return false;
  }

  static void restoreFactors(String enemyName) {
    try {
      ObjectInputStream ois = new ObjectInputStream(new GZIPInputStream(new
          FileInputStream(RobotInfo.getRobot().getDataFile(enemyName + ".float"))));
      hitCountsVelocity = (double[][][][]) ois.readObject();
    }
    catch (Exception e) {
      hitCountsVelocity = new double[DISTANCE_INDEX][VELOCITY_INDEX][
          VELOCITY_INDEX][GUESS];
      fastHitCounts[HALF_GUESS] = 35;
    }
  }

  static void saveFactors(String enemyName) {
    try {
      ObjectOutputStream oos = new ObjectOutputStream(new GZIPOutputStream(new
          RobocodeFileOutputStream(RobotInfo.getRobot().getDataFile(enemyName + ".float"))));
      oos.writeObject(hitCountsVelocity);
      oos.close();
    }
    catch (IOException e) {
    }
  }

  void registerVisit() {
    int index = suitableIndex();
    double[] visits = visitCounts[distanceIndex][velocityIndex][accelIndex][
        deccelIndex];
    for (int i = 0; i < GUESS; i++) {
      visits[i] = (float) MathUtile.rollingAvg(visits[i], i == index ? 45.0 : 0.0,
                                            200.0);
    }
  }

  static void storeHit(Bullet bullet) {
    Point2D bulletLocation = new Point2D.Double(bullet.getX(), bullet.getY());
    MoveWave wave = (MoveWave) Wave.findClosest(waves, bulletLocation, bullet.getVelocity());
    if (wave != null) {//�Ѿ� �Ŀ��� ��ġ�ϴ� ���� ������ null�� �߻�
      wave.storeHit(bullet.getHeadingRadians()); //���� ���߿� �Ŀ��� ��ġ�ϴ� �� �߿���
      //(�Ѿ˰� ������ �Ÿ�-distanceFromGun)�� ���� ª�� ���� ã�´�.
    }
  }

  void storeHit(double bearing) {
    storeHit(suitableIndex(bearing));//1~21
  }

  void storeHit(Point2D hitLocation) {
    storeHit(suitableIndex(hitLocation));
  }

  void storeHit(int index) {
    double[] hitsTimer = hitCountsTimer[distanceIndex][accelIndex][deccelIndex];
    double[] hitsVelocity = hitCountsVelocity[distanceIndex][velocityIndex][
        lastVelocityIndex];
    double[] fastHits = fastHitCounts;
    for (int i = 0; i < GUESS; i++) {
      hitsTimer[i] = (float) MathUtile.rollingAvg(hitsTimer[i],
                                               i == index ? 100.0 : 0.0, 2.0);
      hitsVelocity[i] = (float) MathUtile.rollingAvg(hitsVelocity[i],
                                                  i == index ? 100.0 : 0.0, 2.0);
      fastHits[i] = (float) MathUtile.rollingAvg(fastHits[i],
                                              i == index ? 50.0 : 0.0, 2.0);
    }
  }

  double warning(Point2D destination) {
    int index = suitableIndex(destination);
    double[] visits = visitCounts[distanceIndex][velocityIndex][accelIndex][
        deccelIndex];
    double[] hitsTimer = hitCountsTimer[distanceIndex][accelIndex][deccelIndex];
    double[] hitsVelocity = hitCountsVelocity[distanceIndex][velocityIndex][
        lastVelocityIndex];
    double[] fastHits = fastHitCounts;
    double smoothed = 0;
    for (int i = 0; i < GUESS; i++) {
      smoothed +=
          ( (isLowHitRate() ? 0 : visits[i] + hitsTimer[i]) + hitsVelocity[i] +
           fastHits[i]) / Math.pow( (double) (Math.abs(index - i) + 1.0), 0.5);
    }
    return smoothed / Math.pow(travelTime(distance(0)), 0.5);
  }

  static boolean isLowHitRate() {
    return hited / (Movement.roundNum + 1) < 1.5;
  }
}
