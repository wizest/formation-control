package se.move;

import robocode.*;
import se.utils.*;
import se.scan.*;
import robocode.util.Utils;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import java.awt.geom.*;

public class Movement {
  static final double MAX_SMOOTH_WALL= 150;

  static Rectangle2D farmeBoundary;
  static Point2D myPosition = new Point2D.Double(); //��ĵ����� �� �κ��� ��ǥ
  static Point2D enemyPosition = new Point2D.Double(); //��ĵ����� �� �κ��� ��ǥ
  static Point2D lastEnemyPosition=new Point2D.Double(); //���� �ٷ��� ��ǥ
  static Point2D forward;
  static Point2D reverse;
  static Point2D destination;


  static double enemyAbsBearing;
  static double enemyDistance;
  static double enemyEnergy;
  static double enemybulletPower;
  static int distanceIndex;
  static int lastVelocityIndex;
  static double velocity;
  static int timeSinceAccel;
  static int timeSinceDeccel;
  static double roundNum;            //���° �����ΰ�? 1������ ����
  static boolean bulletFired;
  static double smoothing;
  static String enemyName;

  static double whereDirection;             //���� ���� �ٶ󺼶� �������� �����̰� �ֳ� ���������� �����̰� �ֳ� �������� 1
  static double roundsLeft;
  static double robotBearing;
  static double enemyEnergyDiff ;
  static MoveWave stopWave;
  static double bulletVelocity ;
  static double escapeUnit ;
  static double wantedVelocity ;
  static double radian;
  static int velocityIndex;

  public Movement() {
    farmeBoundary = MathUtile.frameBoundary(RobotInfo.getRobot(), RobotInfo.WALL_LIMIT);

    roundsLeft = RobotInfo.getRobot().getNumRounds() - roundNum - 1;
    roundNum++;
  }
  public void onScannedRobot(ScanInfo e) {
    MoveWave wave = new MoveWave(this);
    if (enemyName == null) {
      enemyName = e.getName();
      restoreFactors();
    }
    enemybulletPower=2.0+(0.5/RobotInfo.getOthers()); //���� �⺻ �����Ŀ�����

    lastEnemyPosition = new Point2D.Double(enemyPosition.getX(), enemyPosition.getY());
    wave.setAttackerPosition(lastEnemyPosition);
    robotBearing = wave.bearingByEnemy(myPosition);
    wave.setBegingBearing(robotBearing);

    enemyEnergyDiff = enemyEnergy - e.getEnergy();
    if (enemyEnergyDiff > 0 && enemyEnergyDiff <= 3.0) { //�Ѿ��� �߻� �ߴٸ�
      enemybulletPower = enemyEnergyDiff;
      wave.smooth = true;
      bulletFired=true;
    }

    enemyEnergy = e.getEnergy();
    bulletVelocity = MathUtile.bulletVelocity(enemybulletPower);
    wave.setBulletVelocity(bulletVelocity);

    whereDirection = robotBearingDirection(robotBearing);
    escapeUnit = wave.maxEscapeAngle() * whereDirection/   //���� �ְ� �ӵ��� �޷����� ���� �Ѿ˼ӵ��� �����ؼ� �ִ�� �����϶��� ����/22
        (double) MoveWave.HALF_GUESS;
    wave.setEscapeUnit(escapeUnit);

    distanceIndex = (int) Math.min(MoveWave.DISTANCE_INDEX - 1,
                                   (enemyDistance /
                                    (RobotInfo.getBattlefieldDiagonal() /
                                     MoveWave.DISTANCE_INDEX)));
    wave.distanceIndex = distanceIndex;
    int velocityIndex = (int) Math.abs(velocity / 2);
    velocity = RobotInfo.getRobot().getVelocity();

    if (velocityIndex > lastVelocityIndex) {
      timeSinceAccel = 0;
    }
    if (velocityIndex < lastVelocityIndex) {
      timeSinceDeccel = 0;
    }
    wave.velocityIndex = velocityIndex;
    wave.lastVelocityIndex = lastVelocityIndex;
    lastVelocityIndex = velocityIndex;

    wave.accelIndex = (int) MathUtile.middleValue(0, MoveWave.VELOCITY_CHANGE_INDEX - 1, Math.pow( (bulletVelocity * timeSinceAccel++) /(enemyDistance / timeSinceAccel), 0.35));

    wave.deccelIndex = (int) MathUtile.middleValue(0, MoveWave.VELOCITY_CHANGE_INDEX - 1, Math.pow( (bulletVelocity * timeSinceDeccel++) / (enemyDistance / timeSinceDeccel), 0.35));

    wave.setTargetPosition(myPosition);

    myPosition.setLocation(new Point2D.Double(RobotInfo.getX(), RobotInfo.getY()));
    enemyAbsBearing = RobotInfo.getRobot().getHeadingRadians() + e.getBearingRadians();

    enemyPosition.setLocation(MathUtile.aimPoint(myPosition, enemyDistance, enemyAbsBearing));
    enemyDistance = e.getDistance();
    wave.flow(2);
    RobotInfo.getRobot().addCustomEvent(wave);

    MoveWave closestSurfable = (MoveWave) Wave.findClosest(MoveWave.
        surfables, myPosition);

    forward = wallSurfing(myPosition, whereDirection);
    reverse = wallSurfing(myPosition, -whereDirection);
    destination = forward;
    wantedVelocity = RobotInfo.ROBOT_MAX_VELOCITY;
    if (stopWave != null) {
      wantedVelocity = 0;
    }
    else {
      if ( MoveWave.surfables.size() == 0 &&
            enemyPosition.distance(reverse) / enemyPosition.distance(forward) >
            1.05) {
        destination = reverse;
      }
      if (MoveWave.warningReverse < MoveWave.warningForward ||
          MoveWave.warningStop < MoveWave.warningForward) {
        if (wave.distanceIndex > 1 &&
            MoveWave.warningStop < MoveWave.warningReverse) {
          wantedVelocity = 0;
          stopWave = closestSurfable;
        }
        else {
          destination = reverse;
        }
      }
    }
    RobotInfo.getRobot().setMaxVelocity(wantedVelocity);
    RobotInfo.getRobot().setAhead(Math.cos(radian = MathUtile.absoluteBearing(myPosition, destination) -
                            RobotInfo.getRobot().getHeadingRadians()) * 100);
    RobotInfo.getRobot().setTurnRightRadians(Math.tan(radian));



    if (MoveWave.hited == 0 && RobotInfo.getRobot().getEnergy() > 25 &&
        ( (roundsLeft < 6 && enemybulletPower < 0.3) ||
         (roundsLeft < 3 && enemybulletPower < (3.01 - roundsLeft)))) {
      RobotInfo.getRobot().setMaxVelocity(0);
    }

    MoveWave.reset();
  }

  static Point2D wallSurfing(Point2D location, double whereDirection) {
    Point2D destination = location;
    double evasion = bulletFired ? MathUtile.middleValue(1.1, 1.3, 500 / enemyPosition.distance(location)):1.5; //���� ���� �Ÿ��� ���� ȸ�ǰ�(�Ÿ��� �ָ� 1.1(456�̻�) �Ÿ��� ������ 1.3(384����))�� �����Ѵ�...
    for (int i = 0; i < 2; i++) {
      smoothing = 0;
      while (!farmeBoundary.contains(destination=MathUtile.aimPoint(location, 135, MathUtile.absoluteBearing(location, enemyPosition)-whereDirection*((evasion-smoothing/100)*Math.PI / 2)))&&smoothing < MAX_SMOOTH_WALL) {
        smoothing++;
      }

      if (distanceIndex > 0 || smoothing < 28) {
        break;
      }
      whereDirection = -whereDirection;
    }

    return destination;
  }

  void updateDirectionStats(MoveWave wave) {
    MoveWave.warningForward += wave.warning(waveImpactPosition(wave, 1.0));
    MoveWave.warningReverse += wave.warning(waveImpactPosition(wave, -1.0));
    MoveWave.warningStop +=
        wave.warning(MathUtile.aimPoint(myPosition, RobotInfo.getRobot().getVelocity() * 1.5, RobotInfo.getRobot().getHeadingRadians()));
  }

  Point2D waveImpactPosition(MoveWave wave, double whereDirection) {
    double currentDirection = robotBearingDirection(wave.bearingByEnemy(
        myPosition));
    double v = Math.abs(RobotInfo.getRobot().getVelocity()) * MathUtile.sign(whereDirection);
    Point2D impactLocation = new Point2D.Double(RobotInfo.getX(), RobotInfo.getY());
    double time = 0;
    do {
      impactLocation = MathUtile.aimPoint(impactLocation, v, MathUtile.absoluteBearing(impactLocation,
          wallSurfing(impactLocation, currentDirection * whereDirection)));
      v = Math.min(RobotInfo.ROBOT_MAX_VELOCITY, v + (v < 0 ? 2 : 1));
      time++;
    }
    while (wave.distance(impactLocation, (int) time) > -10);
    return impactLocation;
  }

  double robotBearingDirection(double bearing) {
    return MathUtile.sign(RobotInfo.getRobot().getVelocity() *
                Math.sin(RobotInfo.getRobot().getHeadingRadians() - bearing));
  }

  public void onHitByBullet(HitByBulletEvent e) {
    MoveWave.hited++;
    MoveWave.storeHit(e.getBullet());
  }

  public void onBulletHitBullet(BulletHitBulletEvent e) {
    MoveWave.storeHit(e.getHitBullet());
  }

  public void restoreFactors() {
    MoveWave.restoreFactors(enemyName);
  }

  public void saveFactors() {
    MoveWave.saveFactors(enemyName);
  }

}
