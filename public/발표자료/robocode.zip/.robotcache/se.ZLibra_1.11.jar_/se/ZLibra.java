package se;

import robocode.*;
import robocode.AdvancedRobot;
import robocode.util.Utils;
import se.utils.*;
import se.scan.*;
import se.gun.*;
import se.move.*;
import java.awt.Color;
import java.awt.geom.*;
import java.util.Iterator;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ZLibra
    extends AdvancedRobot {
  private static ScanInfoMgr _sMgr;
  private Iterator itr;
  Scaned _scaned;
  Gun gun;
  Movement move;

  static final double MAX_VELOCITY = 8;
  static final double WALL_MARGIN = 25;
  Point2D robotLocation;
  Point2D enemyLocation;
  double enemyDistance;
  double enemyAbsoluteBearing;
  double movementLateralAngle = 0.2;
  double time=0;
  public void run() {
    init();
    while (true) {
      if(time++<100&&getOthers()>3)
        antiGravMove();
      _scaned.scan();
      execute();
    }
  }

  public void init() {
    setAdjustGunForRobotTurn(true);
    setAdjustRadarForGunTurn(true);
    setColors(Color.white, Color.white, Color.MAGENTA);
    RobotInfo.setRobotInfo(this);
    _sMgr = new ScanInfoMgr();
    _scaned = new Scaned(this, _sMgr);
    gun = new Gun();
    move = new Movement();
    itr = _sMgr.iterator();
  }

  /**
   * onScannedRobot: What to do when you see another robot
   */
  public void onScannedRobot(ScannedRobotEvent e) {
    ScanInfo scanInfo=null;
    ScanInfo rearEnemy=null;
    ScanInfo rearEnemy2=null;
    double maxEnergy;
    double maxDistance=1200;
    double maxDistance2=1200;
    double maxDistance3=300;


    _sMgr.update(e);
    itr = _sMgr.iterator();
    while (itr.hasNext()) {
      scanInfo = (ScanInfo) itr.next();
      //ȸ�ǿ�
      if(scanInfo.getDistance()<maxDistance){
        rearEnemy=scanInfo;
        maxDistance=scanInfo.getDistance()-200;
      }
      if(scanInfo.getDistance()<100)
        rearEnemy=scanInfo;
      //���ݿ�
      if(scanInfo.getDistance()<maxDistance2){
        rearEnemy2=scanInfo;
        maxDistance2=scanInfo.getDistance()-250;
      }
      if(scanInfo.getDistance()<150)
        rearEnemy2=scanInfo;
      if(scanInfo.getEnergy()<10 && scanInfo.getDistance()<maxDistance3){ //������ ���� ��
        rearEnemy2=scanInfo;
        maxDistance=scanInfo.getDistance();
      }
    }

    if(!(time++<100&&getOthers()>3)||e.getDistance()>130){
      move.onScannedRobot(rearEnemy);
    }
    gun.onScannedRobot(rearEnemy2);

  }

  public void onRobotDeath(RobotDeathEvent e) {
    _sMgr.deathRobot(e.getName());
  }

  public void onHitByBullet(HitByBulletEvent e) {
    move.onHitByBullet(e);

  }

  public void onBulletHitBullet(BulletHitBulletEvent e) {
    move.onBulletHitBullet(e);

  }

  public void onWin(WinEvent e) {
    saveFactors();
  }

  public void onDeath(DeathEvent e) {
    saveFactors();
  }

  void saveFactors() {
    if (true) {
      move.saveFactors();
    }
  }
  void antiGravMove(){
    double xforce=0;
    double yforce=0;
    double midPointStrength=0;
    double force;
    double ang;
    GravPoint p;

    midPointStrength = (Math.random() * -1000);
    p = new GravPoint(getBattleFieldWidth()/2, getBattleFieldHeight()/2, midPointStrength);
    force = p.power/Math.pow(getRange(getX(),getY(),p.x,p.y),1.5);
    ang = normaliseBearing(Math.PI/2 - Math.atan2(getY() - p.y, getX() - p.x));
    xforce += Math.sin(ang) * force;
    yforce += Math.cos(ang) * force;
    xforce += 5000/Math.pow(getRange(getX(), getY(), getBattleFieldWidth(), getY()), 3);
    xforce -= 5000/Math.pow(getRange(getX(), getY(), 0, getY()), 3);
    yforce += 5000/Math.pow(getRange(getX(), getY(), getX(), getBattleFieldHeight()), 3);
    yforce -= 5000/Math.pow(getRange(getX(), getY(), getX(), 0), 3);

    goTo(getX()-xforce,getY()-yforce);
  }
  void goTo(double x, double y) {
    double dist = 20;
    double angle = Math.toDegrees(absbearing(getX(),getY(),x,y));
    double r = turnTo(angle);
    setAhead(dist * r);
  }

  int turnTo(double angle) {
    double ang;
    int dir;
    ang = normaliseBearing(getHeading() - angle);
    if (ang > 90) {
      ang -= 180;
      dir = -1;
    }
    else if (ang < -90) {
      ang += 180;
      dir = -1;
    }
    else {
      dir = 1;
    }
    setTurnLeft(ang);
    return dir;
  }

  double normaliseBearing(double ang) {
    if (ang > Math.PI)
      ang -= 2 * Math.PI;
    if (ang < -Math.PI)
      ang += 2 * Math.PI;
    return ang;
  }

  public double getRange(double x1, double y1, double x2, double y2) {
    double xo = x2 - x1;
    double yo = y2 - y1;
    double h = Math.sqrt(xo * xo + yo * yo);
    return h;
  }

  public double absbearing(double x1, double y1, double x2, double y2) {
    double xo = x2 - x1;
    double yo = y2 - y1;
    double h = getRange(x1, y1, x2, y2);
    if (xo > 0 && yo > 0) {
      return Math.asin(xo / h);
    }
    if (xo > 0 && yo < 0) {
      return Math.PI - Math.asin(xo / h);
    }
    if (xo < 0 && yo < 0) {
      return Math.PI + Math.asin( -xo / h);
    }
    if (xo < 0 && yo > 0) {
      return 2.0 * Math.PI - Math.asin( -xo / h);
    }
    return 0;
  }

}

class GravPoint {
    public double x,y,power;
    public GravPoint(double pX,double pY,double pPower) {
        x = pX;
        y = pY;
        power = pPower;
    }
}


