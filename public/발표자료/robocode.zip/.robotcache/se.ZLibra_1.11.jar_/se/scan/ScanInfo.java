package se.scan;

import robocode.*;
import java.awt.geom.Point2D;
/**
 * <p>Title: ��ĵ�� ���� ���� ����  �̸�, ��ĵ����� �ð�, ��� �ִ°�?</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ScanInfo {
  String enemyName;
  double scanTime;
  double bearing;
  double distance;
  double velocity;
  double heading;
  double energy;

  public void setScanTime(double time){
    scanTime=time;
  }

  public double getScanTime(){
    return scanTime;
  }
  public String getName(){
    return enemyName;
  }
  public double getBearingRadians() {
    return bearing;
  }
  public double getDistance(){
    return distance;
  }

  public double getVelocity(){
    return velocity;
  }
  public double getHeadingRadians(){
    return heading;
  }
  public double getEnergy(){
    return energy;
  }

  public ScanInfo(ScannedRobotEvent e){
    enemyName=e.getName();
    scanTime=e.getTime();
    bearing=e.getBearingRadians();
    distance=e.getDistance();
    velocity=e.getVelocity();
    heading=e.getHeadingRadians();
    energy=e.getEnergy();
  }
}
