package se.scan;

import se.*;
import se.scan.*;
import se.utils.*;
import robocode.*;
import java.util.Iterator;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Scaned {
  ZLibra z_libra = null;
  ScanInfoMgr _sMgr = null;

  public Scaned(ZLibra r, ScanInfoMgr sMgr) {
    z_libra = r;
    _sMgr = sMgr;
  }

  public void scan() {
    Iterator itr = _sMgr.iterator();
    double now = RobotInfo.getTime();
    ScanInfo scanInfo=null, oldScanedInfo=null;
    double turnRadian;
    double gapTime;
    double scanedTime =-1;
    boolean findAll = true;

    if(RobotInfo.getTime()<9){
      z_libra.setTurnRadarRightRadians(Math.PI*2);
      return;
    }

    while (itr.hasNext()) {
      scanInfo = (ScanInfo) itr.next();
      gapTime = now - scanInfo.getScanTime();
      if (gapTime < 12) {
        if (gapTime > scanedTime) {
          oldScanedInfo = scanInfo;
          scanedTime = gapTime;
        }
      }
      else{
        findAll = false;
      }
    }

    if(oldScanedInfo!=null && findAll==true){
      double turnMaxRadar=RobotInfo.getHeadingRadians()+oldScanedInfo.getBearingRadians()-RobotInfo.getRadarHeading();
      turnRadian=MathUtile.relativeRadian(turnMaxRadar);
      if(z_libra.getOthers()!=1){
        turnRadian+=Math.toRadians(MathUtile.sign(turnRadian)*20);
      }
      z_libra.setTurnRadarRightRadians(turnRadian);
    }
    else{
      z_libra.setTurnRadarRightRadians(Math.PI*2);
    }
  }
}