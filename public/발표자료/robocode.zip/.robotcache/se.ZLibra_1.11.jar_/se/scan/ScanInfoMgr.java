package se.scan;

import robocode.*;
import se.utils.*;
import java.util.HashMap;
import java.util.Iterator;

import java.awt.geom.Point2D;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ScanInfoMgr {
  static HashMap scanInfoMap;

  public ScanInfoMgr() {
    scanInfoMap = new HashMap(RobotInfo.getAllOthers());

  }
  //��ĵ���� ����(�ð�, bearing, position, �̸�)
  public void update(ScannedRobotEvent e) {
    ScanInfo sInfo;

    sInfo=new ScanInfo(e);
    scanInfoMap.put(e.getName(), sInfo);
  }

  public void deathRobot(String robotName) {
    scanInfoMap.remove(robotName);
  }

  public Iterator iterator(){
    return scanInfoMap.values().iterator();
  }
}
