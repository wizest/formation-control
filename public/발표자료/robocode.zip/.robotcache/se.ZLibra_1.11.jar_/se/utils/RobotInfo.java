package se.utils;

import robocode.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class RobotInfo {
  public static final double ROBOT_WIDTH=36;
  public static final double ROBOT_DIAGONAL=50;
  public static final double WALL_LIMIT=18;
  public static final double MAX_BULLET_POWER=3;
  public static final double ROBOT_MAX_VELOCITY=8;

  static AdvancedRobot bot;
  static double b_w, b_h;
  static int allOthers;

  public static double getBattleWidth(){
    return b_w;
  }
  public static double getBattleHeight(){
    return b_h;
  }
  public static int getAllOthers(){
    return allOthers;
  }

  public static double getTime(){
    return bot.getTime();
  }
  public static int getRoundNum(){
    return bot.getRoundNum();
  }
  public static int getOthers(){
    return bot.getOthers();
  }
  public static double getX(){
    return bot.getX();
  }
  public static double getY(){
    return bot.getY();
  }
  public static double getHeadingRadians(){
    return bot.getHeadingRadians();
  }
  public static double getRadarHeading(){
    return Math.toRadians(bot.getRadarHeading());
  }
  public static double getBattlefieldDiagonal(){
   return Math.sqrt((getBattleWidth()-ROBOT_WIDTH)*(getBattleWidth()-ROBOT_WIDTH)+(getBattleHeight()-ROBOT_WIDTH)*(getBattleHeight()-ROBOT_WIDTH));
  }
  public static double getEnergy(){
    return bot.getEnergy();
  }

  public static AdvancedRobot getRobot(){
    return bot;
  }
  public static void setRobotInfo(AdvancedRobot r){
    bot=r;
    b_w=r.getBattleFieldWidth();
    b_h=r.getBattleFieldHeight();
    allOthers=r.getOthers();
  }
}
