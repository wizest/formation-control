package se.utils;

import robocode.*;
import java.util.*;
import java.awt.geom.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MathUtile {


  public static double absoluteRadian(double angle) {
    double PI2=Math.PI*2;
    if (angle < 0)
      return PI2 + (angle % PI2);
    else
      return angle % PI2;
  }

  public static double relativeRadian(double angle) {
    double PI=Math.PI;
    double PI2=Math.PI*2;
    if (angle > PI)
      return ( (angle + PI) % PI2) - PI;
    if (angle < -PI)
      return ( (angle - PI) % PI2) + PI;
    return angle;
  }

  public static Point2D aimPoint(Point2D sourcePosition, double length, double angle){
    return new Point2D.Double(sourcePosition.getX()+Math.sin(angle) * length, sourcePosition.getY()+Math.cos(angle)*length);
  }

  public static double absoluteBearing(Point2D source, Point2D target){
    return Math.atan2(target.getX()-source.getX(), target.getY()-source.getY());
  }
  public static double bulletVelocity(double bulletPower){
    return 20-3*bulletPower;
  }

  public static double middleValue(double min, double max, double v){
    return Math.max(Math.min(v, max), min);
  }

  //�Ѿ��� ������ �ִ�� ��� �� �ִ� ����
  public static double maxEscapeAngle(double bullectVelocity){
    return Math.asin(RobotInfo.ROBOT_MAX_VELOCITY/bullectVelocity);
  }


  public static Rectangle2D frameBoundary(AdvancedRobot robot, double d){
    return new Rectangle2D.Double(d, d, robot.getBattleFieldWidth()-(d*2), robot.getBattleFieldHeight()-(d*2));
  }


  public static int sign(double n){
    return n<0?-1:1;
  }

  //Rolling Average
  public static double rollingAvg(double value, double newEntry, double n){
    return (value*n+newEntry)/(n+1.0);
  }

}
