package se.utils;

import robocode.*;
import robocode.util.Utils;
import java.util.*;
import java.awt.geom.Point2D;

public abstract class Wave extends Condition {

    private Point2D attackerPosition;
    private Point2D targetPosition;
    private double bulletVelocity;
    private double bulletSpreadDistance;
    private double beginingBearing;
    private double escapeUnit;
    private int guess;
    private int halfGuess;

    public void init(int guess) {
        this.guess = guess; //45,27
        this.halfGuess = (guess - 1) / 2;
    }

    public abstract boolean test();

    public boolean through(double offset) {
        return bulletSpreadDistance > attackerPosition.distance(targetPosition) + offset;
    }

    public void flow(int ticks) {
        bulletSpreadDistance += ticks * bulletVelocity;
    }


    public int suitableIndex() {
        return suitableIndex(targetPosition);
    }

    public int suitableIndex(Point2D location) {
        return suitableIndex(MathUtile.absoluteBearing(attackerPosition, location));//���� �� ��ĵ��ǥ�� �������� Point2D������ ���� bearing
    }

    public int suitableIndex(double bearing) {
      return (int) MathUtile.middleValue(1, guess - 1, Math.round( ( (Utils.normalRelativeAngle(bearing - beginingBearing)) / escapeUnit) + halfGuess));
    }

    public double maxEscapeAngle() {
      return Math.asin(8 / bulletVelocity);
    }
    public double bearingByEnemy(Point2D target) {
        return MathUtile.absoluteBearing(attackerPosition, target);
    }

    public double distance(Point2D location, int timeOffset) {
        return attackerPosition.distance(location) - bulletSpreadDistance - (double)timeOffset * bulletVelocity;
    }

    public double distance(int timeOffset) {
        return distance(targetPosition, timeOffset);
    }

    public double distance(Point2D location) {
        return distance(location, 0);
    }

    public double travelTime(double distance) {
        return distance / bulletVelocity;
    }

    public int botWidth() {
        int width = (int)Math.ceil(guess * (Math.atan2(RobotInfo.ROBOT_WIDTH, attackerPosition.distance(targetPosition)) / maxEscapeAngle()));
        return width;
    }

    public Point2D getGunLocation() {
        return attackerPosition;
    }

    public double getBulletVelocity() {
        return this.bulletVelocity;
    }

    public double getbulletSpreadDistance(){
        return bulletSpreadDistance;
    }


    public void setBulletVelocity(double bulletVelocity) {
        this.bulletVelocity = bulletVelocity;
    }

    public void setBegingBearing(double beginingBearing) {
        this.beginingBearing = beginingBearing;
    }

    public void setEscapeUnit(double escapeUnit) {
        this.escapeUnit = escapeUnit;
    }

    public void setAttackerPosition(Point2D attackerPosition) {
        this.attackerPosition = attackerPosition;
    }

    public void setTargetPosition(Point2D targetPosition) {
        this.targetPosition = targetPosition;
    }

    public static Wave findClosest(List waves, Point2D location) {
        return findClosest(waves, location, -1);
    }

    public static Wave findClosest(List waves, Point2D location, double velocity) {
        double closestDistance = Double.POSITIVE_INFINITY;
        Wave closest = null;
        for (int i = 0, n = waves.size(); i < n; i++) {
            Wave wave = (Wave)waves.get(i);
            double d = Math.abs(wave.distance(location));
            //velocity<0�� ���� �޼ҵ带 ���� ���̰�, Math.abs()�� ���� �Ѿ˰� ���� �Ѿ˰� ���� �Ѿ��� �Ŀ��� ��ġ�ϴ°��� ã�� ����
            if (d < closestDistance && (velocity < 0 || Math.abs(wave.bulletVelocity - velocity) < 0.01)) {
                closest = wave;
                closestDistance = d;
            }
        }
        return closest;
    }
}

