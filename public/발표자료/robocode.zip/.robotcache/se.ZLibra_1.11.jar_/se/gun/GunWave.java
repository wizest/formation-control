package se.gun;

import robocode.*;
import se.utils.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class GunWave extends Wave{
    static final int BULLET_POWER_INDEX = 6;
    static final int DISTANCE_INDEX = 7;
    static final int DISTANCE_SHORT_INDEX = 4;
    static final int VELOCITY_INDEX = 5;
    static final int WALL_INDEX = 4;
    static final int WALL_INDEX_SHORT = 3;
    static final double WALL_INDEX_WIDTH = 5.7;
    static final double WALL_INDEX_WIDTH_SHORT = 7.6;
    static final int VELOCITY_CHANGE_INDEX = 5;
    static final int VELOCITY_CHANGE_SHORT_INDEX = 3;
    static final int HEAINDG_DIRECTION_INDEX =11;
    static final int GUESS = 27;
    static final int HALF_GUESS = (GUESS - 1) / 2;

    static double[][][][][][][] guessFactor = new double[DISTANCE_INDEX][VELOCITY_INDEX][VELOCITY_INDEX][VELOCITY_CHANGE_INDEX][WALL_INDEX][BULLET_POWER_INDEX][GUESS];
    static double[][][][][][][] guessShortFactor = new double[DISTANCE_SHORT_INDEX][VELOCITY_INDEX][VELOCITY_INDEX][VELOCITY_CHANGE_SHORT_INDEX][WALL_INDEX_SHORT][BULLET_POWER_INDEX][GUESS];
    static double[][][][][][][][] factorHDIndex = new double[DISTANCE_SHORT_INDEX][VELOCITY_INDEX][VELOCITY_INDEX][VELOCITY_CHANGE_SHORT_INDEX][WALL_INDEX_SHORT][HEAINDG_DIRECTION_INDEX][BULLET_POWER_INDEX][GUESS];

    int distanceIndex;
    int distanceShortIndex;
    int velocityIndex;
    int lastVelocityIndex;
    int velocityChangedIndex;
    int velocityChangedShortIndex;
    int accelIndex;
    int deccelIndex;
    int wallIndex;
    int wallShortIndex;
    int rhIndex;
    int bulletPowerIndex;
    double weight = 1;

    public GunWave() {
        init(GUESS);
    }

    public boolean test() {
        flow(1);
        if(RobotInfo.getOthers()> 0){
          if (through(-18)){//�Ѿ��� ���� �ոӸ� �Ÿ���ŭ ����
            gainWave();
            RobotInfo.getRobot().removeCustomEvent(this);
          }
        }
        return false;
    }

    public void gainWave() {

        double factor[] = guessFactor[distanceIndex][velocityIndex][lastVelocityIndex][velocityChangedIndex][wallIndex][bulletPowerIndex];
        double SFactor[] = guessShortFactor[distanceShortIndex][velocityIndex][lastVelocityIndex][velocityChangedShortIndex][wallShortIndex][bulletPowerIndex];
        double HDFactor[] = factorHDIndex[distanceShortIndex][velocityIndex][lastVelocityIndex][velocityChangedShortIndex][wallShortIndex][rhIndex][bulletPowerIndex];
        int index = Math.max(1, suitableIndex());//GUESS�� ������ų ��ġ
        factor[index] += weight;
        SFactor[index] += weight;
        HDFactor[index] += weight;
        factor[0] += weight;
        SFactor[0] += weight;
        HDFactor[0] += weight;
    }

    public int bestGuess() {
      double factor[] = guessFactor[distanceIndex][velocityIndex][lastVelocityIndex][velocityChangedIndex][wallIndex][bulletPowerIndex];
      double SFactor[] = guessShortFactor[distanceShortIndex][velocityIndex][lastVelocityIndex][velocityChangedShortIndex][wallShortIndex][bulletPowerIndex];
      double HDFactor[] = factorHDIndex[distanceShortIndex][velocityIndex][lastVelocityIndex][velocityChangedShortIndex][wallShortIndex][rhIndex][bulletPowerIndex];
        int mostVisitedIndex = HALF_GUESS;
        double most = factor[HALF_GUESS] / factor[0] + SFactor[HALF_GUESS] / SFactor[0];
        for (int i = 1; i < GUESS; i++) {
            double visits = factor[i] / factor[0] + SFactor[i] / SFactor[0];
            if (visits > most) {
              most = visits;
              mostVisitedIndex = i;

            }
        }
        return mostVisitedIndex;
    }
}


