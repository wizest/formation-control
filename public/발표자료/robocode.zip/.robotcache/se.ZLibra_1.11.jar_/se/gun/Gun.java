package se.gun;

import robocode.*;
import se.utils.*;
import se.scan.*;
import robocode.util.Utils;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
public class Gun {
    static final double BULLET_POWER = 2.0;

    static Rectangle2D fieldRectangle;
    static Point2D targetPosition=new Point2D.Double();
    static Point2D attackPosition;

    static double lastVelocity;
    static int timeSinceVelocityChange; //�ӵ��� ��ȭ�� ���� ������ �ð� ����
    static int timeSinceDeccel;   //���������� �����д��� ���� ���ķ� �����ð�
    static int timeSinceAccel;    //���������� �����д��� ���� ���ķ� �����ð�
    static double targetDiagonalEscapeBearing;
    static double lastTargetVelocity;
    static double bulletPower;

    static double targetDistance;
    static double targetBearing;
    static double targetHeading;
    static double targetDiagonalAbsHeading;
    static double bulletVelocity;
    static double escapeUnit;

    public Gun() {
        fieldRectangle = MathUtile.frameBoundary(RobotInfo.getRobot(), RobotInfo.WALL_LIMIT);
    }

    public void onScannedRobot(ScanInfo e) {
        GunWave wave = new GunWave();

        /*****bullet Power*********/
        bulletPower=Math.min(BULLET_POWER, e.getEnergy() >= 4 ? (e.getEnergy() + 2) / 6 : e.getEnergy() / 4);
        bulletPower*=300/e.getDistance();
        bulletPower=Math.min(bulletPower+0.15*RobotInfo.getOthers(), RobotInfo.MAX_BULLET_POWER);
        bulletPower=e.getDistance()<180?RobotInfo.MAX_BULLET_POWER:bulletPower;
        if(RobotInfo.getOthers()>5)
        bulletPower=3;
        wave.bulletPowerIndex =(int) MathUtile.middleValue( 0, GunWave.BULLET_POWER_INDEX-1,(int)(bulletPower / 0.5));//0~5
        bulletVelocity =MathUtile.bulletVelocity(bulletPower);
        wave.setBulletVelocity(bulletVelocity);


        targetDistance = e.getDistance();
        wave.distanceIndex = (int)Math.min((targetDistance / (RobotInfo.getBattlefieldDiagonal() / GunWave.DISTANCE_INDEX)), GunWave.DISTANCE_INDEX - 1);//180 0~6
        wave.distanceShortIndex = (int)Math.min((targetDistance / (RobotInfo.getBattlefieldDiagonal() / GunWave.DISTANCE_SHORT_INDEX)), GunWave.DISTANCE_SHORT_INDEX - 1);//300 0~3
        attackPosition = new Point2D.Double(RobotInfo.getX(), RobotInfo.getY());
        targetBearing = RobotInfo.getRobot().getHeadingRadians() + e.getBearingRadians();
        wave.setAttackerPosition(attackPosition);
        wave.setBegingBearing(targetBearing);
        wave.setTargetPosition(targetPosition);
        targetPosition.setLocation(MathUtile.aimPoint(attackPosition, targetDistance, targetBearing));


        if (e.getVelocity() != 0) {
            lastTargetVelocity = e.getVelocity();
        }
          //���� �ٶ󺸴� ����
        targetHeading = e.getHeadingRadians();
        if(MathUtile.sign(lastTargetVelocity)==-1)
         targetHeading+=Math.PI;
        //���� ������ ������ ���� �߰� ���� �������� ���� Heading�� Math.abs(bearing)
        targetDiagonalAbsHeading = Math.abs(Utils.normalRelativeAngle( targetHeading - RobotInfo.getRobot().getHeadingRadians() - e.getBearingRadians()));
        wave.rhIndex = (int)Math.min(GunWave.HEAINDG_DIRECTION_INDEX - 1, targetDiagonalAbsHeading / (Math.PI / GunWave.HEAINDG_DIRECTION_INDEX));


        wave.lastVelocityIndex = (int)Math.abs(lastVelocity / 2);
        lastVelocity = e.getVelocity();
        wave.velocityIndex = (int)Math.abs(lastVelocity / 2);
        if (wave.velocityIndex != wave.lastVelocityIndex) {//�ӵ��� ��ȭ�� ������
            timeSinceVelocityChange = 0;
        }
        if (wave.velocityIndex < wave.lastVelocityIndex) {//����������
            timeSinceDeccel = 0;
        }
        if (wave.velocityIndex > wave.lastVelocityIndex) {//���� ������ �׷��� �ְ��ӵ��� �ö󰡸� ������ ����.
            timeSinceAccel = 0;
        }


        if (e.getVelocity() != 0) {
          //���� ���� ������ �߰� ��setTargetLocation�� ���������� �����̸� �� �ݴ�� ������ �ؼ� �ְ��ӵ��� �޷����� ����� ��(sin�� Ư��)
            targetDiagonalEscapeBearing = wave.maxEscapeAngle() * MathUtile.sign(e.getVelocity() * Math.sin(e.getHeadingRadians() - targetBearing));
        }
        escapeUnit = targetDiagonalEscapeBearing / (double)GunWave.HALF_GUESS;
        wave.setEscapeUnit(escapeUnit);

        wave.wallIndex = 0;
        while (++wave.wallIndex < (GunWave.WALL_INDEX) &&//4
            fieldRectangle.contains(MathUtile.aimPoint(attackPosition, targetDistance,
                targetBearing + escapeUnit * (double)(wave.wallIndex * GunWave.WALL_INDEX_WIDTH))));
        wave.wallIndex -= 1;

        wave.wallShortIndex = 0;
        while (++wave.wallShortIndex < (GunWave.WALL_INDEX_SHORT) &&//3
            fieldRectangle.contains(MathUtile.aimPoint(attackPosition, targetDistance,
                targetBearing + escapeUnit * (double)(wave.wallShortIndex * GunWave.WALL_INDEX_WIDTH_SHORT))));
        wave.wallShortIndex -= 1; //0~1

        wave.velocityChangedIndex = (int)MathUtile.middleValue(0, GunWave.VELOCITY_CHANGE_INDEX - 1, Math.pow((bulletVelocity * timeSinceVelocityChange++) / (targetDistance / timeSinceVelocityChange), 0.35));//0~4
        wave.velocityChangedShortIndex = (int)MathUtile.middleValue(0, GunWave.VELOCITY_CHANGE_SHORT_INDEX - 1, Math.pow((bulletVelocity * timeSinceVelocityChange++) / (targetDistance / timeSinceVelocityChange), 0.35));
        wave.accelIndex = (int)MathUtile.middleValue( 0, GunWave.VELOCITY_CHANGE_INDEX - 1, Math.pow((bulletVelocity * timeSinceAccel++) / (targetDistance / timeSinceAccel), 0.35));
        wave.deccelIndex = (int)MathUtile.middleValue( 0, GunWave.VELOCITY_CHANGE_INDEX - 1, Math.pow((bulletVelocity * timeSinceDeccel++) / (targetDistance / timeSinceDeccel), 0.35));

        RobotInfo.getRobot().setTurnGunRightRadians(Utils.normalRelativeAngle(targetBearing - RobotInfo.getRobot().getGunHeadingRadians() +
                    escapeUnit * (wave.bestGuess() - GunWave.HALF_GUESS)));

        if(RobotInfo.getRobot().getEnergy()<this.bulletPower){
          if (e.getDistance() < 180) {
            bulletPower=Math.min(e.getEnergy() / 4,RobotInfo.getRobot().getEnergy() / 3.0);
            if (RobotInfo.getRobot().setFireBullet(bulletPower) != null) {//cooling time���� null�� ȣ��� �� �ִ�.
              wave.weight = 2;
            }
          }
        }else if(RobotInfo.getRobot().setFireBullet(bulletPower) != null) {
            wave.weight = 2;
        }
        if (RobotInfo.getRobot().getOthers() > 0)
            RobotInfo.getRobot().addCustomEvent(wave);
    }
}



