/*
 * Created on 2004. 5. 13.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;

/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Gravity 
{
	private double x;
	private double y;
	private double distance;
	private double strength;
	private double power;
	
	Gravity()
	{
	}
	
	Gravity( double x, double y, double d, double s, double p )
	{
		this.x = x;
		this.y = y;
		distance = d;
		strength = s;
		power = p;
	}
	
	public void setGravity( double x, double y, double d, double s, double p )
	{
		this.x = x;
		this.y = y;
		distance = d;
		strength = s;
		power = p;
	}
	
	public void setGravity( TriNCalc point, double s, double standardX, double standardY )
	{
		this.x = point.getX();
		this.y = point.getY();
		distance = point.distanceFrom( standardX, standardY );
		strength = s;
	}
	
	public double getForce()
	{
		return strength / Math.pow( distance, power ); 
	}
	
	public static double getForce( double strength, double distance, double power )
	{
		return strength / Math.pow( distance, power );
	}
}
