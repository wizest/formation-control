/*
 * Created on 2004. 4. 6.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;
//import robocode.*;
import java.util.Iterator;
/**
 * @author n1
 * �̵� �Ѿ� ���ϱ� �� �ڸ� ���
 */

public class Body 
{
// ========================================================================
// ���� ���
	private Trickster trickster;
	public double targetX = 0;
	public double targetY = 0;
	
// ========================================================================
// ������
	Body()
	{	
	}
	
	Body( Trickster trickster )
	{
		this.trickster = trickster;
	}
// ========================================================================
	
	// x �� �������� ���� ����
	public void antiGravEnemy( Gravity EnemyGrav, TriNCalc forAngle  )
	{	
		double angle = 0;
		angle = trickster.getCurrentPos().angleXY( forAngle );
		
		//melee ���� EnemyData����..
		targetX += Math.cos( angle ) * EnemyGrav.getForce();
		targetY += Math.sin( angle ) * EnemyGrav.getForce();
	}
	
	public void antiGravWall( double repulsion, double power )
	{
		targetY += Gravity.getForce( repulsion, trickster.getBattleFieldHeight() - trickster.getCurrentPos().getY(), power );
		targetY -= Gravity.getForce( repulsion, trickster.getCurrentPos().getY(), power );	
		targetX -= Gravity.getForce( repulsion, trickster.getCurrentPos().getX(), power );
		targetX += Gravity.getForce( repulsion, trickster.getBattleFieldWidth() - trickster.getCurrentPos().getX(), power );		
	}
	
	public void antiGravCorner( double repulsion, double power )
	{
		double coZeroZero = trickster.getCurrentPos().angleXY( 0, 0 );
		double coZeroMaxHeight = trickster.getCurrentPos().angleXY( 0, trickster.getBattleFieldHeight() );
		double coMaxWidthMaxHeight = trickster.getCurrentPos().angleXY( trickster.getBattleFieldWidth(), trickster.getBattleFieldHeight() );
		double coMaxWidthZero = trickster.getCurrentPos().angleXY( trickster.getBattleFieldWidth(), 0 );
		
		targetX += Math.cos( coZeroZero ) * Gravity.getForce( repulsion, trickster.getCurrentPos().distanceFrom( 0, 0 ), power );	
		targetY += Math.sin( coZeroZero ) * Gravity.getForce( repulsion, trickster.getCurrentPos().distanceFrom( 0, 0 ), power );
		targetX += Math.cos( coZeroMaxHeight ) * Gravity.getForce( repulsion, trickster.getCurrentPos().distanceFrom(  0, trickster.getBattleFieldHeight() ), power );
		targetY += Math.sin( coZeroMaxHeight ) * Gravity.getForce( repulsion, trickster.getCurrentPos().distanceFrom(  0, trickster.getBattleFieldHeight() ), power );
		targetX += Math.cos( coMaxWidthMaxHeight ) * Gravity.getForce( repulsion, trickster.getCurrentPos().distanceFrom( trickster.getBattleFieldWidth(), trickster.getBattleFieldHeight()  ), power );
		targetY += Math.sin( coMaxWidthMaxHeight ) * Gravity.getForce( repulsion, trickster.getCurrentPos().distanceFrom( trickster.getBattleFieldWidth(), trickster.getBattleFieldHeight()  ), power );
		targetX += Math.cos( coMaxWidthZero ) * Gravity.getForce( repulsion, trickster.getCurrentPos().distanceFrom( trickster.getBattleFieldWidth(), 0 ), power );
		targetY += Math.sin( coMaxWidthZero ) * Gravity.getForce( repulsion, trickster.getCurrentPos().distanceFrom(  trickster.getBattleFieldWidth(), 0  ), power );
	}
	
	public void setAttractivePos( TriNCalc pos, double attractive, double power )
	{
		double angle = trickster.getCurrentPos().angleXY( pos.getX(), pos.getY() );
		double distance = trickster.getCurrentPos().distanceFrom( pos );
		
		targetX += Math.cos( angle ) * Gravity.getForce( attractive, distance, 1  );
		targetY += Math.cos( angle ) * Gravity.getForce( attractive, distance, 1  );
	}
	
	public void setAntiPoint( TriNCalc pos, double repulsion, double power )
	{
		double angle = trickster.getCurrentPos().angleXY( pos.getX(), pos.getY() );
		double distance = trickster.getCurrentPos().distanceFrom( pos );
		
	//	trickster.out.println( "��Ƽ ����Ʈ ��!!!!!\n\n\n\n" );
		targetX += Math.cos( angle ) * Gravity.getForce( repulsion, distance, 1  );
		targetY += Math.cos( angle ) * Gravity.getForce( repulsion, distance, 1  );
	}
	
	// ����
	public void antiGravBullet( double repulsion, double power, double dist )
	{
		BulletInfo bI;
		double eDistance = dist;
		double angle = 0;
		boolean fastMove = false;
		Iterator iter = BulletAnalyze.eBulletStore.iterator();
		
		//��(����) �Ÿ� �Ŀ�
		// �Ÿ��� ���� �Ѿ��� ��ġ
		if( Trickster.enemySize > 1 )
			eDistance = 300; // ���� ���
		if( eDistance < 50 && Trickster.enemySize == 1 )
		{
			fastMove = true;
			repulsion -= 10;
		}
		for( ; iter.hasNext() ; )
		{
			
			bI = (BulletInfo)iter.next();
			bI.bulletUpdate( trickster.getTime(), trickster.getCurrentPos() );
			//trickster.out.println( bI.bulletUpdate( trickster.getTime(), trickster.getCurrentPos() ) );
			
			if( bI.remove != true )
			{
				if( bI.distPos < ( eDistance / 1.5 ) || fastMove == true )
				{
					targetX += Math.cos( bI.angle ) * Gravity.getForce( repulsion, bI.distPos, power );
					targetY += Math.sin( bI.angle ) * Gravity.getForce( repulsion, bI.distPos, power );
				}
				else if( bI.bearingChange == true )
				{// ������ �Ѿ�
					targetX += Math.cos( bI.angle ) * Gravity.getForce( repulsion - 0.5, bI.distPos, power );
					targetY += Math.sin( bI.angle ) * Gravity.getForce( repulsion - 0.5, bI.distPos, power );
				}
			}
			else 
				iter.remove();
		}
	}
	
	public boolean antiPoint;
	private int antiCount;
	public boolean meleeMode;
	
	public void setAntiGravMove( double repulsion, double power, double distance )
	{
		if( meleeMode == true )
		{
			int rate = Trickster.enemySize;
			
		//	trickster.out.println( "melee mode " );
			antiGravWall( ( repulsion + 1 ) * rate, 1 );
			antiGravCorner( ( repulsion + 8 ) * rate, 1 );
			antiGravBullet( ( repulsion + 18 ) * rate, 1, distance );
		}
		else
		{
		//	trickster.out.println( "1vs1 mode " );
			antiGravWall( repulsion + 14, 1 );
			antiGravCorner( repulsion + 19.5, 1 );
			antiGravBullet( repulsion + 18, 1, distance );
		}
		
		if( antiPoint == true && antiCount < 10 )
		{
			++antiCount;
			if( Trickster.enemySize > 1 )
				setAntiPoint( trickster.getCurrentPos(), -200, 1 );
			else
				setAntiPoint( trickster.getCurrentPos(), -5, 1 );
		}
		else if( antiCount >= 10 )
		{
			antiPoint = false;
			antiCount = 0;
		}
		
		goToXY( getLastX(), getLastY() );
	}
	
	public void goToXY( double x, double y )
	{
		int direction = 1;
		double angle = 0;
		
		angle = Utils.normalRelativeAngleR( trickster.getCurrentPos().getBearing( x, y, trickster.getHeadingRadians() ) );
		if( Math.abs( angle ) > Math.PI / 2 )
		{
			if( angle > Math.PI / 2 )
			{
				angle -= Math.PI;
			}
			else
			{
				angle += Math.PI;
			}
			direction *= -1;
		}
		trickster.setAhead( 20 * direction );
		trickster.setTurnRightRadians( angle );
	}
	
	public static boolean rampage( long nTick, long eILST )
	{
		if( nTick - eILST > 30 )
			return true;
		return false;
	}

	// ���� �ε������� ������
	public static double hitWallDamage( double velocity )
	{
		return Math.abs( velocity ) * 0.5 - 1;
	}
	
	public double getLastX()
	{
		return trickster.getX() + targetX;
	}
	
	public double getLastY()
	{
		return trickster.getY() + targetY;
	}
}
