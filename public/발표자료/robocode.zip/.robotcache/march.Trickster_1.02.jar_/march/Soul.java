package march;
import java.util.Enumeration;

/**
 * @author Choi moon su
 * 
 */
// ���� ������ �м��Ͽ� ���� �κ��� ������ ���� �Ѵ�.
// ���� ��ġ�� ���� ���⵵ ���鰣 �Ÿ� ������ �̵� �Ÿ���
// ������ �Һ� �ռ��� �� 
// ���������� �����ؼ� ���� Ÿ���� ���Ѵ�.
//import java.util.Vector;

public class Soul 
{
	private Trickster trickster;
	private Radar radar;
	private Body body;
	private Gun gun;
// ===================================================
	private Data data;			 // �� ��ü ����
	private Enumeration enum;	 // �ؽ����̺� ���ſ�
	private Gravity point;
// ====================================================
	private BulletAnalyze ebulletAnalyze;

	
	Soul()
	{
	}
	
	Soul( Trickster trickster )
	{
		this.trickster = trickster;
		this.data = trickster.getEnemyInfoStore();
		this.radar = new Radar( trickster );
		this.body = new Body( trickster );
		this.gun = new Gun( trickster );
		this.ebulletAnalyze = new BulletAnalyze( trickster );
	}
	
	// operator
	public void operator()
	{
		soulInit();
		tracking();
		moving();
		shooting();
	}
	
	public void soulInit()
	{
		body.targetX = 0;
		body.targetY = 0;
		trickster.getPastPos().setLocation( trickster.getCurrentPos() );
		trickster.getCurrentPos().setLocation( trickster.getX(), trickster.getY() );
	//	trickster.out.println( "���� xy  : " + trickster.getX() + ", " + trickster.getY() );
	//	trickster.out.println( "���� xy  : " + trickster.getPastPos().getX() + ", " + trickster.getPastPos().getY() );
		
		if( Trickster.enemySize > 1 )
		{
			body.meleeMode = true;
		}
		else
			body.meleeMode = false;
	}
//=================================================================================
	// Radar
	public void tracking()
	{
		int i = 0;
		String name = null;
		
		if( data.dataSizeFull() )
		{// melee
			if( Trickster.enemySize > 1 )
			{
				for( enum = data.getKeyEnum() ; enum.hasMoreElements() ; )
				{
					radar.data[i] = data.getEnemyData( (String)enum.nextElement() ).getRadarData();
					if( radar.eTName != null )
					{
						if( radar.data[i].newScan == true )
						{
							if( radar.findEnemy( radar.data[i].name ) == true )
							{
								trickster.setTurnRadarRightRadians( trickster.getRadarTurnRemainingRadians() * -99 );
							}
						}
					}
					i++;
				}
				radar.setBestAngle();	
				trickster.setTurnRadarRightRadians( trickster.getRadarTurnRemainingRadians() );	// ȸ�� ( ������ = ���ð� )
			}
			else 
			{// 1vs1 
				for( enum = data.getKeyEnum() ; enum.hasMoreElements() ; )
				{
					name = (String)enum.nextElement();
					
					if( ( trickster.getTime() - data.getEnemyData( name ).getSpotTime() ) < 5 )
						trickster.setTurnRadarRightRadians( radar.anglePlusTwo( radar.trackingAngle( data.getEnemyData( name ).getAbsAngle() ) ) );
				}
			}
		}
		else
		{// start 
			radar.radarFastHoldSweep();
		}
	}
	
//=================================================================================
// MOVEING
	public void moving()
	{
		EnemyData enemy = null;
		double antiBdist = 0;
		
		for( enum = data.getKeyEnum() ; enum.hasMoreElements() ; )
		{
			enemy = data.getEnemyData( (String)enum.nextElement() );		
			//=============================================================================			
			// 1 vs 1
			if( body.meleeMode == false )
			{
				ebulletAnalyze.getEnemyBullet( enemy.getEnergyInfo(), enemy.getGis(), enemy.getHitInfo(), enemy.getEnemyName() );
				
				if( enemy.nalHitHetNya == true )
				{	
					Gun.block = false;
					if( enemy.dangerArea == true )
						body.antiPoint = true;
					if( ebulletAnalyze.scanBullet( enemy.getHitMeBullet().getX(), enemy.getHitMeBullet().getY() , enemy.getEnemyName(), enemy.getHitMeBullet().getVelocity() ) == true )
						ebulletAnalyze.bHeadVariation( ebulletAnalyze.bAnalyzer( enemy.getHitMeBullet().getHeadingRadians() ), enemy.getEnemyName() );	
					enemy.initHitMe();
					enemy.repulsionInit = true;
				}
				
				if( Trickster.enemySize == 1 )
					antiBdist = enemy.getDistance();
				
				if( enemy.getRampage() == true )
				{
					// ���� �Ѿ� �i���� �Ǵ��� ����
					enemy.setRepulsion( enemy.attractive += 0.09, 1 );
				}
				else
				{
				//	enemy.repulsionInit = true;
					if( enemy.repulsionInit == true )
						enemy.initRepulsion(); // �׶��Ƽ Ǯ������ ������ ���𰡰� �ʿ�
				//	trickster.out.println( enemy.enemyRepulsionReport() );
				}	
			}
			//============================================================================
			// melee
			else
			{
				int rate = Trickster.enemySize;
				
				if( ebulletAnalyze.getEnemyBullet( enemy.getEnergyInfo(), enemy.getGis(), enemy.getHitInfo(), enemy.getEnemyName() ) == false )
					enemy.addRepulsion( -2 * rate, 1 );
				
				if( enemy.getRepulsion() > -0.5 * rate + rate / 2 )
					enemy.repulsionInit = true;
				
				if( enemy.nalHitHetNya == true )
				{	
					enemy.addRepulsion( 0.5 * rate, 1 ); // �� �κе� ����
					if( enemy.dangerArea == true && ( trickster.getX() > 18.5 || trickster.getX() < Trickster.fieldWidth - 18.5 || trickster.getY() > 18.5 || trickster.getY() < Trickster.fieldHeight - 18.5 ) )
						body.antiPoint = true;
					
					if( Trickster.enemySize < 4 )
					{ // ���� 3 �̻��̶�� ��� �Ѿ� ������ ��ȭ�� ���� �ʴ´�.
						if( ebulletAnalyze.scanBullet( enemy.getHitMeBullet().getX(), enemy.getHitMeBullet().getY() , enemy.getEnemyName(), enemy.getHitMeBullet().getVelocity() ) == true )
							ebulletAnalyze.bHeadVariation( ebulletAnalyze.bAnalyzer( enemy.getHitMeBullet().getHeadingRadians() ), enemy.getEnemyName() );	
					}
					enemy.initHitMe();
				}	
				
				if( enemy.getRampage() == true && enemy.getDistance() < Trickster.fieldHeight / 2 + 200 )
				{
					if( enemy.getFixedTick() > 40 )
						enemy.setRepulsion( 100 * Trickster.enemySize, 1 );
					enemy.setRepulsion( enemy.attractive += 15 * Trickster.enemySize, 1 );
				}
				else
				{
					if( enemy.repulsionInit == true ) // ���̸� �ʱ�ȭ
						enemy.initRepulsion(); //  Ǯ������ ������ ���𰡰� �ʿ�
					//trickster.out.println( enemy.enemyRepulsionReport() );	
				}
			}//else	
			body.antiGravEnemy( enemy.getGravity(), enemy.getEnemyPos() );
		}//for
		body.setAntiGravMove( -20, 1.5, antiBdist );
	}// rampage ���� �ؾ� �� ���̴�. ���� �������� �������� ���� 
	
	 // melee ��� ����... ���߷�
//=================================================================================
// GUN
	public void shooting()
	{
		EnemyData eD = null;
		double angle = 0;
		double power = 0;
		int aim = 0;
		
		//=================================================================
		// aim : sPMT & vPMT& headOnT
		//=================================================================
		double bPMA = 0;
		double vhPMA = 0;
		
		for( enum = data.getKeyEnum() ; enum.hasMoreElements() ; )
		{
			eD = data.getEnemyData( (String)enum.nextElement() );
			
			// VB ==============================================================
			// ����
			eD.testVB();
			//trickster.out.println( eD.vBReport() );
			
			if( Trickster.enemySize == 1 )
			{
			//	trickster.out.println( "soul���̸�       " + eD.getEnemyName() );		
			//	trickster.out.println( "���� �� ������   " + data.getEnemyData( eD.getEnemyName() ).getXPos() + ", " + data.getEnemyData( eD.getEnemyName() ).getYPos() );
				
				//basedata ======================================================
				power = gun.fireSelect( eD.getDistance(), eD.getEnergy() );
				gun.bulletV = Gun.bulletVelocity( power );
				gun.travelingTime = (long)Math.round( eD.getDistance() / gun.bulletV );
				gun.impactTime = trickster.getTime() + gun.travelingTime;
			
				//aimSelect =======================================================
				aim = eD.aimSelect();
			//	trickster.out.println( "()()���� ���� ���� ���" +  aim );
				
				// Targeting========================================= 
				bPMA =	gun.bPMT( eD.waves, eD.getEnemyName(), eD.getXPos(), eD.getYPos(), eD.getVelocity(), eD.getHeading(), eD.getAbsAngle(), eD.getDistance(), power, eD.getSpotTime() );
				vhPMA = gun.vhPMT( eD.waves, eD.getEnemyName(), eD.getDistance(), eD.getVelocity(), eD.getXPos(), eD.getYPos(), eD.getAbsAngle(),eD.getHeading(), eD.getAvH(),  power, eD.getSpotTime() );
				
				if( Gun.saveShot == true || trickster.getTime() < 40 || eD.getDistance() < 80 )
				{	
				//	trickster.out.println( "S   A    V   E" );
					angle = Utils.normalRelativeAngleR( eD.getAbsAngle() - trickster.getGunHeadingRadians() );
					if( eD.getDistance() < 80 )
						power = 3;
					else
						power = 0.1;
					Gun.saveShot = false;
				}
				else if( aim != 0 )
				{	
					if( aim == 1 )
					{
					//	trickster.out.println( "���� ����  : bPMA" );
						angle = bPMA;
						power = gun.bpPower;
					}
					else if( aim == 2 )
					{
					//	trickster.out.println( "���� ����  : vhpPMA" );
						angle = vhPMA;
						power = gun.vhpPower;
					}
				}
				else if( aim == 0 )
				{
					angle = bPMA;
					power = gun.bpPower;
				}
				else// �⺻ aim
					angle = Utils.normalRelativeAngleR( eD.getAbsAngle() - trickster.getGunHeadingRadians() ); 
				eD.initAim();
			}
			else
			{	
				aim = 0; // melee Mode
				//basedata ======================================================
				power = gun.fireSelect( eD.getDistance(), eD.getEnergy() );
				gun.bulletV = Gun.bulletVelocity( power );
				gun.travelingTime = (long)Math.round( eD.getDistance() / gun.bulletV );
				gun.impactTime = trickster.getTime() + gun.travelingTime;

				// ��ο��� ������ ������( ���� ���� ) vb�� ��� ���ϳ� ���߿� ����
				// Targeting========================================= 
				// ��ü ��ĵ ���� ������ ���� vh // �ð��� ���� �����..
				// ���� ����� Ÿ�ٿ��� ������ ������ �ش�.
				if( ( eD.getEnemyName() == Satellite.closeRobot( trickster.getCurrentPos() ) ) )
				{
					vhPMA = gun.vhPMT( eD.waves, eD.getEnemyName(), eD.getDistance(), eD.getVelocity(), eD.getXPos(), eD.getYPos(), eD.getAbsAngle(),eD.getHeading(), eD.getAvH(),  power, eD.getSpotTime() );			
					angle = Utils.normalRelativeAngleR( eD.getAbsAngle() - trickster.getGunHeadingRadians() );
				
					if( Gun.saveShot == true || eD.getDistance() < 300 )
					{	
						angle = Utils.normalRelativeAngleR( eD.getAbsAngle() - trickster.getGunHeadingRadians() );
						
						if( Gun.saveShot == true )
							power = 0.1;
						else if( eD.getDistance() < 200 || eD.getFixedTick() > 40 && eD.getEnergy() > 30 )
							power = 3;
						else if( eD.getDistance() < 300 || eD.getFixedTick() > 10 && eD.getEnergy() > 30 )
							power = 2.8;
						else if( eD.getDistance() < 400 || eD.getFixedTick() > 5 && eD.getEnergy() > 20 )
							power = 2.5;
						else if( eD.getDistance() < 500 || eD.getFixedTick() > 2 && eD.getEnergy() > 20 )
							power = 2.4;
						else if( eD.getDistance() < 600 || eD.getFixedTick() > 2 && eD.getEnergy() > 20 )
							power = 2.3;
						else if( eD.getDistance() < 700 || eD.getFixedTick() > 2 && eD.getEnergy() > 20 )
							power = 2.2;
						else
							power = 2.1;
					}
					else if( ( aim == 0 && trickster.getTime() > 400 ) )
					{	
					//	trickster.out.println( "���� ���� VHPMA" );
						angle = vhPMA;
						power = gun.vhpPower;
					}
					else
					{
						angle = Utils.normalRelativeAngleR( eD.getAbsAngle() - trickster.getGunHeadingRadians() ); 
						power = 0.1; 
					}
					
					if( eD.getEnergy() < 4 )
					{
						power = 0.1;
					}
					Gun.block = false;
				}//if(same)
			}//else
		}//for
			
		// =============================================================== 		
		trickster.setTurnGunRightRadians( angle );
		
		if( Trickster.enemySize == 0 || trickster.getEnergy() < 1 )
			Gun.block = true;
		if( Gun.block == false && trickster.getGunTurnRemaining() < 10 )
		{// block���� �ʰ� body�� �ִ� ���� ������ ���� �ʴ´ٸ� 
			trickster.setFire( power );
		}
		//Gun.block = false;
		// ===============================================================
	}// gun
//================================================================================
}