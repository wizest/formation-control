/*
 * Created on 2004. 5. 29.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;

/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class HitInfo 
{
	public boolean hitted;
	public long hittedTick;
	public double power;
	
	HitInfo()
	{
		hitted = false;
		hittedTick = 0;
		power = 0;
	}
	
	HitInfo( long tick, double pw )
	{
		hitted = true;
		hittedTick = tick;
		power = pw;
	}
	
	public void setHitInfo( long tick, double pw )
	{
		hitted = true;
		hittedTick = tick;
		power += pw;
	}
	
	public void initHitInfo()
	{
		hitted = false;
		hittedTick = 0;
		power = 0;
	}
}
