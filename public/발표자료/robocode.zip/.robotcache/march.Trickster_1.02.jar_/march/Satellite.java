/*
 * Created on 2004. 5. 19.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;

/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
import java.util.Hashtable;
import java.util.Enumeration;


public class Satellite 
{	
	Satellite()
	{
	}
	
	public static Hashtable distanceInfo = new Hashtable( Trickster.enemySize );
	public static String deathRobot;
//	public static String SatelliteReport()
//	{
//		return ( "distanceInfoSize       : " + distanceInfo.size() );
//	}
	
	//private static double concentration = 9999;
	
	// ���� ���� ��������.. ���� �ð��� ����-_-
/*	public static String getConcentration( String name )
	{
		Enumeration enum = distanceInfo.keys();
		
		double distSum = 0;
		String other = null;
		TriNCalc distPos = null;
		String bokjaphanX = null;
		double dist = 0;
		
		distPos = (TriNCalc)distanceInfo.get( name );
		
		for( int i = 1 ; enum.hasMoreElements()&& i < Trickster.enemySize ; i++ )
		{
			if( ( other = (String)enum.nextElement() ) != name )
			{
				if( ( dist = distPos.distanceFrom( (TriNCalc)distanceInfo.get( other ) ) ) < 100 )
					distSum += dist;
			}
		}
		
		if( bokjaphanX == name )
			concentration = distSum;
		if( concentration < distSum )
		{
			bokjaphanX = name;
			concentration = distSum;
		}
		
		return bokjaphanX;
	}*/
	
	public static String closeRobot( TriNCalc mypos )
	{
		Enumeration enum = distanceInfo.keys();
		String other = null;
		String name = null;
		double dist = 99999;
		
		for( ; enum.hasMoreElements() ; )
		{
			other = (String)enum.nextElement();
			if( dist > mypos.distanceFrom( ( TriNCalc )distanceInfo.get( other ) ) )
			{
				if( deathRobot != other )
				{	
					name = other;
					dist = mypos.distanceFrom( ( TriNCalc )distanceInfo.get( other ) );
				}
			}
		}
		return name;
	}
	
	public static boolean maxDistanceBlock( TriNCalc predPos, TriNCalc eNowPos, long bTravelingTick )
	{
		if( (long)Math.round( eNowPos.distanceFrom( predPos ) / 8. ) < bTravelingTick )
			return true;
		return false;
	}
}
