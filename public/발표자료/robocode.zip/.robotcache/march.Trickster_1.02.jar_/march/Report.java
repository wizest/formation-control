/*
 * Created on 2004. 6. 6.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;

/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
// ��ü���� ����Ʈ�� �����Ѵ�.
public class Report 
{
	private static int skipTurn;
	private static int wallHitBullet;
	
	Report()
	{
	}
	
	public void updateST()
	{
		++skipTurn;
	}
	public void updateWHB()
	{
		++wallHitBullet;
	}
	
	public String ReportAll()
	{
		return 
		(
				"��ŵ��    : " + skipTurn + "\n" +
				"����Ʈ    : " + wallHitBullet + "\n" 
		);
	}
}
