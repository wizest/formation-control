/*
 * Created on 2004. 6. 21.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;

/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */


public class RadarData 
{
	public String name;
	public double absAngle;
	public boolean newScan;
	public TriNCalc pos;
	
	
	RadarData()
	{	
	}
	
	RadarData( String name, TriNCalc pos, double absAngle, boolean newS )
	{
		this.name = name;
		this.pos = pos;
		this.absAngle = absAngle;
		this.newScan = newS;
	}
}
