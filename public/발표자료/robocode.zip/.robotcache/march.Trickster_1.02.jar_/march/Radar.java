
//==================================================================	
package march;
//import robocode.Condition;

public class Radar
{
	private Trickster trickster;
//=======================================
	private double standard;
	private double sweepAngle;
	private RadarData standR = null;	// ���� �κ��� ����
	private RadarData targeR = null;	// ������ �κ��� ����
	
	public String eTName = new String();
	public RadarData [] data = new RadarData[Trickster.enemySize];
	
	
	Radar()
	{
	}
	
	Radar( Trickster trickster )
	{
		this.trickster = trickster;
	}

	public void angleSort()
	{	
	 	RadarData temp = null;
	  	 
	  	for( int i = 0 ; i < Trickster.enemySize - 1 ; i++ )
	  	{
	  		for( int j = i + 1 ; j < Trickster.enemySize ; j++ )
	  		{
	  			if( data[i].absAngle < data[j].absAngle )
	  			{
	  				temp = data[j];
	  				data[j] = data[i];
	  				data[i] = temp;
	  			}
	  		}
	  	}
	}
		
	public void bestAngle()
	{
	  	double target = Math.PI * 2; 
	  
	   	for( int i = 0 ; i < Trickster.enemySize ; i++ )
	  	{
	  		if( i == Trickster.enemySize - 1 )
	  		{// ������ ����(�������� ũ��)�� �ش�
	  			if( target > data[0].absAngle - data[i].absAngle )
	  			{
	  				standR = data[i];
	  				targeR = data[0];
	  				target = data[0].absAngle - data[i].absAngle;
	  		    }
	  		}
	  		else
	  		{
	  			if( target > data[i+1].absAngle + (Math.PI * 2) - data[i].absAngle )
	  			{
	  				standR = data[i];
	  				targeR = data[i+1];
	  				target = data[i+1].absAngle + (Math.PI * 2) - data[i].absAngle;
	  			}
	  		}
	  	}
	   
	 	sweepAngle = target / 2;	// ������ ���ؿ��������� ��밢 ũ��( ���� �������� �̷�� )
	 	standard = standR.absAngle + sweepAngle; // �ִܰ� �߰���
	   	
		if( sweepAngle <= Math.toRadians( 18 ) && standR.newScan == true && targeR.newScan == true )
	 	{		
	 		eTName = null;
	 		sweepAngle = Math.toRadians( 22.5 );
	 		trickster.setTurnRadarRightRadians( 0 );
	 	}
		else
		{
			if( trickster.getRadarTurnRemainingRadians() < 0 )
			{
				trickster.setTurnRadarRightRadians( trickster.getRadarTurnRemainingRadians() * 99 );
				eTName = standR.name;
			}
			else
			{
				trickster.setTurnRadarRightRadians( trickster.getRadarTurnRemainingRadians() * 99 );
				eTName = targeR.name;
			}
	  	}
	}
  
	public void posDataUpdate()
	{
		for( int i = 0 ; i < Trickster.enemySize ; i++ )
		{
			data[i].absAngle = Utils.absAngleR( Math.PI / 2  - trickster.getCurrentPos().angleXY( data[i].pos ) );
		}
	}
	
	public void setBestAngle()
	{
		posDataUpdate();	// ���� ���� ��ġ�� ���� ���밢 ����
		angleSort();		// �� ũ������� ����
		bestAngle();		// �� ���� ������ ����
	
		if( trickster.getRadarTurnRemaining() == 0 )
		{
			trickster.setTurnRadarRightRadians( anglePlus( trackingAngle( standard ), sweepAngle ) ); // ���ݱ��� ��밢, ��ǥ������ ��
		}
	}  
	
	public boolean findEnemy( String nowEnemy )
	{
		if( eTName == nowEnemy )
			return true;
		
		return false;
	}
  
	public double anglePlus( double angle, double sweepAngle )
	{	
		if( angle < 0 )
		{
			angle -= sweepAngle;// + 0.05;
		}
		else if( angle > 0 )
		{
			angle += sweepAngle;// + 0.05;
		}
 
		return Utils.normalRelativeAngleR( angle );
	}

	public double anglePlusTwo( double angle )
	{
		double plus = 0.233;
	
		if( angle < 0 )
			angle -= plus;
		else if( angle > 0 )
			angle += plus;
		return angle;
	}
	
	public void radarFastSweep()
	{
		trickster.setTurnRight( 10 );
		trickster.setTurnGunRight( 30 );
		trickster.setTurnRadarRight( 75 );
	}
	
	int i = 0;
	public void radarFastHoldSweep()
	{
		trickster.setTurnRight( 10 * 4.8 );
		trickster.setTurnGunRight( 30 * 4.8 );
		trickster.setTurnRadarRight( 75 * 4.8 );
/*		trickster.waitFor
		( new Condition( "radarFastHoldSweep" )
			{
				public boolean test() 
				{					
					if( i == Trickster.enemySize || Data.enemySize >= Trickster.enemySize )
					{	
						trickster.setTurnRight( 0 );
						trickster.setTurnGunRight( 0 );
						return true;
					}
					return false;
				}
			}
		);
*/
	}

	public double trackingAngle( double targetAbsAngle )
	{
		return Utils.normalRelativeAngleR( targetAbsAngle - trickster.getRadarHeadingRadians() );
	}
}