/*
 * Created on 2004. 4. 15.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;

/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Utils 
{

	public static double toDegrees( double r ) 
	{
	    return r / Math.PI * 180.0;
	}
	
	public static double toRadians( double d ) 
	{
	    return d * Math.PI / 180.0;
	}
	
	public static double absAngle( double angle )
	{
		while( angle < 0 )
			angle += 360;
		while( angle >= 360 )
			angle -=360;
		return angle;
	}
	
	public static double normalRelativeAngle( double angle )
	{
		while( angle <= -180)
			angle += 360;
		while( angle > 180)
			angle -= 360;
		return angle;
	}
	
	public static double absAngleR( double Rad )
	{
		while( Rad < 0 )
			Rad += Math.PI * 2;
		while( Rad >= Math.PI * 2 )
			Rad-= Math.PI * 2;
		return Rad;
	}
	
	public static double normalRelativeAngleR( double Rad )
	{
		while( Rad <= -Math.PI )
			Rad += Math.PI * 2;
		while( Rad > Math.PI )
			Rad -= Math.PI * 2;
		return Rad;
	}
	
	public static char wrap( double d )
	{
		return (char)( d * 10 );
	}
	
	public static byte unpack( double d )
	{
		return (byte)( d / 10 );
	}
// ==========================================================================	 
// ==========================================================================	 
// ==========================================================================	 
// ==========================================================================	 
// ==========================================================================	 
// ==========================================================================	 


}
