/*
 * Created on 2004. 6. 21.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;

/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

public class EnemyCount 
{
	private String enemyName;
	private int eNum = -1;
	public int count;
	
	EnemyCount()
	{
		enemyName = null;
		eNum = -1;
		count = 0;
	}
	
	EnemyCount( String enemyName, int eNum )
	{
		this.enemyName = enemyName;
		this.eNum = eNum;
		count = 0;
	}
	
	public String setEnemyCount( String name, int num )
	{
		enemyName = name;
		eNum = num;
		
		return enemyName;
	}
	
	public String getName()
	{
		return enemyName;
	}
	
	public int getNumber()
	{
		return eNum;
	}
}
