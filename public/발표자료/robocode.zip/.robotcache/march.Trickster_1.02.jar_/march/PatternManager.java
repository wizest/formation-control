
package march;
/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

public class PatternManager 
{
	public Trickster trickster;
	public static EnemyCount [] enemyCount = new EnemyCount[Trickster.enemySize];
	private SymbolicPattern sP;
	private VHPattern vhP;
	private static int count;
	
	PatternManager()
	{
	}
	
	PatternManager( Trickster trickster )
	{
		this.trickster = trickster;
		sP = new SymbolicPattern(); 
		vhP = new VHPattern();
	}
	
	// ó�� �߰ߵ� ���� ��ȣ�� �ο�
	public static void entry( String name )
	{
		enemyCount[count] = new EnemyCount( name, count++ );
	}
	
	// ���� ��ȣ�� ����
	public static int getCount( String name )
	{
		for( int scan = 0 ; scan < count ; scan++ )
		{
			if( enemyCount[scan].getName() == name )
			{
				return enemyCount[scan].getNumber();
			}
		}
		return -1;
	}
	
	// �ش� ���� �̸��� �ִٸ� ��( ��ȣ�� �ο� �޾Ҵٸ� )
	public static boolean containsKey( String name )
	{
	//	trickster.out.println( "���� ��ϵ� ����" + count );
		if( getCount( name ) >= 0  )
			return true;
		return false;
	}
	
// ���� Ȯ�������� 0.1 headOnT �� guess�� ���� �Ŀ��� �����ش�.
// SymbolicVPatternMatching==============================================================
	public String putSPN( String eN, double velocity, double heading, double absAngle )
	{
	//	trickster.out.println( "putSPN ===================================================" );
		if( containsKey( eN ) == false ) //enemyCount[getCount(eN)].getSpS() == false )
		{
			entry( eN );
			creatBuffer( eN );
		}
		
		sP.add( eN, velocity, heading, absAngle );
	///	trickster.out.println( "===========================================================" );
		return eN;
	}
	
	public double getSPN( String eN, double distance, long travTTick )
	{
	//	trickster.out.println( "getSPN =====================================================" );
	//	trickster.out.println( ":::::: " + eN + " ::::::" );
		if( containsKey( eN ) && sP.getBufferSize( eN ) > SymbolicPattern.SERCH_DEPTH + 70 )
		{
			if( sP.getBufferSize( eN ) < SymbolicPattern.SERCH_DEPTH + 150 ) 
			{
				if( Trickster.ram == false )
					Gun.saveShot = true;
			}
			else
				Gun.block = false;
			
	//		trickster.out.println( "�ش��� ��� ���� ũ�� : " + sP.getBufferSize( eN ) );
	//		trickster.out.println( "=============================================================" );
			return sP.matching( eN, distance, travTTick );//, trickster.getTime() );
		}
		if( Trickster.enemySize == 1 ) 
			Gun.block = true;
		
	//	trickster.out.println( "burning~~ " + sP.getBufferSize( eN ) );
	//	trickster.out.println( "=============================================================" );
		return 0;
	}
//=======================================================================================
	
	public void creatBuffer( String name )
	{
		SymbolicPattern.creatBuffer( getCount( name ) );
		VHPattern.creatBuffer( getCount( name ) );
	}

//=======================================================================================
// VelocityPatternMatching===============================================================
	public String putVHPN( String eN, double velocity, double heading )//, double heading, double absAngle )
	{
	//	trickster.out.println( "putSPN ===================================================" );
		if( containsKey( eN ) == false )//enemyCount[getCount(eN)].getVpS() == false )
		{
			entry( eN );
			creatBuffer( eN );
		}
		
		vhP.add( eN, velocity, heading );//, heading, absAngle );
	///	trickster.out.println( "===========================================================" );
		return eN;
	}
	
//=========================================================================================
	public double getVPN( String eN, long travTTick )
	{
	//	trickster.out.println( "getSPN =====================================================" );
	//	trickster.out.println( ":::::: " + eN + " ::::::" );
		if( containsKey( eN ) && vhP.getVBufferSize( eN ) > VHPattern.SERCH_DEPTH + 30)
		{
			// getHPN�� ����
			if( vhP.getVBufferSize( eN ) < SymbolicPattern.SERCH_DEPTH + 150 )
			{
				if( Trickster.ram == false )
					Gun.saveShot = true;
			}
			else
				Gun.block = false;
			
	//		trickster.out.println( "�ش��� ���� ���� ũ�� : " + vhP.getVBufferSize( eN ) );
	//		trickster.out.println( "=============================================================" );
			return vhP.vMatching( eN, travTTick );//, trickster.getTime() );
		}
		if( Trickster.enemySize == 1 ) 
			Gun.block = true;
	
	//	trickster.out.println( "burning~~ " + vhP.getVBufferSize( eN ) );
	//	trickster.out.println( "=============================================================" );
		
		return 0;//0�϶� headOn 
	}
	
//==================================================================================================
	
	public double getHPN( String eN, long travTTick )
	{
	//	trickster.out.println( "getHPN =====================================================" );
	//	trickster.out.println( ":::::: " + eN + " ::::::" );
		if( containsKey( eN ) && vhP.getHBufferSize( eN ) > VHPattern.SERCH_DEPTH + 60 )
		{			
	//		trickster.out.println( "�ش��� ��� ���� ũ�� : " + vhP.getHBufferSize( eN ) );
	//		trickster.out.println( "=============================================================" );
			return vhP.hMatching( eN, travTTick );//, trickster.getTime() );
		}
	//	trickster.out.println( "burning~~ " + vhP.getHBufferSize( eN ) );
	//	trickster.out.println( "=============================================================" );
		
		return 0;//0�϶� headOn 
	}
	
//==================================================================================================
}