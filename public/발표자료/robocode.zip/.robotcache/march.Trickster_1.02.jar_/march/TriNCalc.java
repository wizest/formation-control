/*
 * Created on 2004. 4. 29.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;
import java.awt.geom.Point2D;
/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */


public class TriNCalc
{
	private double x;
	private double y;
	
	TriNCalc()
	{
		x = 0;
		y = 0;
	}
	
	TriNCalc( double x, double y )
	{
		this.x = x;
		this.y = y;
	}
	
	TriNCalc( Point2D point )
	{
		this.x = point.getX();
		this.y = point.getY();
	}
	
	TriNCalc( TriNCalc point )
	{
		this.x = point.getX();
		this.y = point.getY();
	}
	
	public double distance( double x, double y )
	{
		return Math.sqrt( ( x * x ) + ( y * y ) );
	}
	
	public double distanceFrom( Point2D point )
	{
		return distance( getXX( point.getX() ), getYY( point.getY() ) );
	}
	
	public double distanceFrom( double x, double y )
	{
		return distance( getXX( x ), getYY( y ) );
	}
	
	public double distanceFrom( TriNCalc point )
	{
		return distance( getXX( point.getX() ), getYY( point.getY() ) );
	}
	
	public double getXX( double x )
	{
		return x - getX();
	}
	
	public double getYY( double y )
	{
		return y - getY();
	}

	
	public void setLocation( double x, double y )
	{
		this.x = x;
		this.y = y;
	}
	
	public void setLocation( TriNCalc d )
	{
		x = d.getX();
		y = d.getY();
	}
	
	public boolean same( TriNCalc pos )
	{
		if( x == pos.getX() && y == pos.getY() )
			return true;
		return false;
	}
	
	public void setLocation( Point2D point )
	{
		setLocation( point.getX(), point.getY() );
	}
	// x -> rev
	public double angleXY( double x, double y )
	{
		return Math.atan2( getYY( y ), getXX( x ) );
	}
	
	public double angleXY( TriNCalc point )
	{
		return  Math.atan2( getYY( point.getY() ), getXX( point.getX() ) );
	}
	
	public double getBearing( double x, double y, double heading )
	{
		if( getX() == x && getY() == y )
		{
			return 0;
		}
		return Utils.normalRelativeAngleR( ( Math.PI / 2 - angleXY( x, y ) )  -  heading );
	}
	
	public double getBearing( TriNCalc pos, double heading )
	{
		if( getX() == x && getY() == y )
		{
			return 0;
		}
		return Utils.normalRelativeAngleR( ( Math.PI / 2 - angleXY( pos.getX(), pos.getY() ) ) -  heading );
	}
	
	// return x, y 
	public double getX()
	{
		return x;
	}
	
	public double getY()
	{
		return y;
	}
	
	
	// static/	
	public static double getHeight( double btwAngle, double oblique )
	{
		return Math.sin( btwAngle ) * oblique;
	}
	
	public static double getWidth( double btwAngle, double oblique )
	{
		return Math.cos( btwAngle ) * oblique;
	}
//====================================================================================
}
