/*
 * Created on 2004. 5. 18.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;

/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

public class Gis
{
	public long tick;
	public double damage;
//�浹====================================
	public boolean collision;
	public int count;
//������ ����=============================
	public boolean rampaged;
//========================================
	public static boolean wallPosCh;
	public long tempTick;
	public static TriNCalc tri = new TriNCalc();

	Gis()
	{
	}
	
	public void initGis()
	{
		collision = false;
	//	rampaged = false;
		count = 0;
	}
	
	public static boolean wallPassed( double x, double y )
	{
		if( ( x > Trickster.fieldWidth ) || ( x < 0 ) )
			return true;
		else if( ( y > Trickster.fieldHeight ) || ( y < 0 ) )
			return true;
		return false;
	}
	
	public void hitWall( TriNCalc pos, long t, double velocity )
	{
		tempTick = tick; // ����ƽ
		
		if( pos.getX() < 18.0011 
		|| pos.getY() < 18.0011  // 1000 - 999
		|| ( Trickster.fieldWidth - pos.getX() ) < 18.0011
		|| ( Trickster.fieldHeight - pos.getY() ) < 18.0011 ) 
		{ // ����
			if(  t - this.tick != 1 )
			{ 
				tick = t;
				collision = true;
				++count;
				damage += Body.hitWallDamage( velocity );
			}
			else 
			{
				tick = t; // ���Ŷ����� (1ƽ)  
	//			return "���� �پ� �ٴϳ�?";
			}
		}
	//	else
	//	{
	//		return "���� �Ÿ��� �ִ�";
	//	}
	//	return ( "Gis report ================================================\n" +
	///			 "ƽ����      : " + ( t - tempTick ) + "\n" +
		//	     "���� ������ : " + damage + "\n" +
	//			 "�浹 ����   : " + collision + "\n" +
	//			 "�浹 Ƚ��   : " + count + "\n" +
	//			 "===========================================================" );
	}
	
	// �������� ������ �κ��̶�� �κ����� �浹�� ������ �ش�.
	public boolean hitRobot( TriNCalc posOne, TriNCalc posTwo )
	{
		if( Math.abs( posOne.getX() - posTwo.getX() ) < 36.0022
		 && Math.abs( posOne.getY() - posTwo.getY() ) < 36.0022 )
			return true;
		return false;
	}
	
	public static boolean wallTest( double x, double y )
	{
		if( x <= 18 
		|| x >= Trickster.fieldWidth - 18 
		|| y <= 18 
		|| y >= Trickster.fieldWidth - 18 )
		{
			return true;
		}
		return false;
	}
	
	public static double marginX( double x )
	{
		if( x <= 18 )
		{
			x = 18;
		}
		if( x >= Trickster.fieldWidth - 18 )
		{
			x = Trickster.fieldWidth - 18;
		}
		
		return x;
	}
		
	public static double marginY( double y )
	{
		
		if( y <= 18 )
		{
			y = 18;
		}
		if( y >= Trickster.fieldHeight - 18 )
		{
			y = Trickster.fieldHeight - 18;
		}
		
		return y;
	}

}