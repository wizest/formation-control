/*
 * Created on 2004. 4. 6.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;
import java.util.Vector;
/**
 * @author n1
 * ���� �ϱ��� ������ �����ϰ� ���� ������ ������ ��� Ŭ����
 */
public class Gun 
{
	private Trickster trickster;
	public PatternManager pM;
	//==========================
	public double bulletV;
	public long travelingTime;
	public long impactTime;
	//==========================
	public TriNCalc perfectS = new TriNCalc();
	public TriNCalc perfectV = new TriNCalc();
	//==========================
	public static boolean block; 
	public static boolean saveShot;
//====================================================================================

	Gun()
	{
	}
	
	Gun( Trickster trickster )
	{
		this.trickster = trickster;
		pM = new PatternManager( trickster );
	}
//====================================================================================	
	public double bpPower;
	public double bPMT( Vector vBIn, String name, double x, double y, double velocity, double heading, double absAngle, double distance, double power, long spotTime )
	{	
		double bearing = 0;
		double moveDist = bulletV * travelingTime; 
		// ���ϴ� xy�� ������ �ð����� ���Ǿ� �Ŀ� ������ ����.
		
		bpPower = power;	
		//=====================================================
		if( spotTime == trickster.getTime() )
			pM.putSPN( name, velocity, heading, absAngle );
		bearing = pM.getSPN( name, distance, travelingTime );
		//=====================================================
		
		// bearing ������ x, y
		x = trickster.getX() + Math.cos( Math.PI / 2 - Utils.absAngleR( absAngle + bearing ) ) * moveDist;
		y = trickster.getY() + Math.sin( Math.PI / 2 - Utils.absAngleR( absAngle + bearing ) ) * moveDist; 
			
		bearing += absAngle - trickster.getGunHeadingRadians();		
		
		// ����
		if( Gis.wallTest( x, y ) == true )
		{
		//	trickster.out.println( "saveShot" + " x : " + x + " y : " + y );
			if( distance < 600 )
				saveShot = true;
			else
				block = true;
		}
		
		// VB
		perfectS.setLocation( x, y );
		vBIn.addElement( new Wave(  1,trickster.getCurrentPos(), perfectS, impactTime, travelingTime ) );
	
		return Utils.normalRelativeAngleR( bearing );
	}
//===================================================================================

//===================================================================================
	public double vhpPower;
	public double vhPMT( Vector vBIn, String name, double distance, double velocity, double x, double y, double absAngle, double heading, double headingDv, double power, long spotTime )
	{ 
		double bearing = 0; 
		double avV = 0;
		double avH = 0;
	
		vhpPower = power;
	
		//=========================================================
		if( spotTime == trickster.getTime() )
			pM.putVHPN( name, velocity, headingDv ); // headingDv(Degrees)
	
		avV = pM.getVPN( name, travelingTime );
		avH = pM.getHPN( name, travelingTime );
		//=========================================================
	
		for( int i = 0 ; i < travelingTime ; i++ )
		{		
			heading += avH;
			
			x += TriNCalc.getWidth( Math.PI / 2  - heading, avV );
			y += TriNCalc.getHeight( Math.PI / 2 - heading, avV );
		}
		
		// bp�ʹ� �ٸ��� ������ �Ŀ��� �ӵ��� ���� ����ð����� 
		// ������ �������� �Ÿ��� ����� ������ �����Ѵ�.(round)�� ������ ������
		// ���� �ð��̾��⿡ ������ bp �� ��ǥ�� ������ ���� �ð��� ������.
		vhpPower = fireAdjustment( x, y, power, travelingTime );
		
		bearing = trickster.getCurrentPos().getBearing( x, y, trickster.getGunHeadingRadians() );		
	
		// ��ó�� 4��
		if( Gis.wallTest( x, y ) == true )
		{
		//	trickster.out.println( "saveShot" + " x : " + x + " y : " + y );
			if( distance < 600 )
				saveShot = true;
			else
				block = true;
		}	
		
		// VB 
		perfectV.setLocation( x, y );
		vBIn.addElement( new Wave(  2, trickster.getCurrentPos(), perfectV, impactTime, travelingTime ) );

		return Utils.normalRelativeAngleR( bearing );	
	}
//=====================================================================================================

	public double fireAdjustment( double x, double y, double power, double travelingTime )
	{
		double bVelocity = bulletVelocity( power );
		
		return getPower( bVelocity += ( ( trickster.getCurrentPos().distanceFrom( x, y ) - ( bVelocity * travelingTime ) ) / travelingTime ) );
	}
	
	public double fireSelect( double distance, double energy )
	{
		if( trickster.getEnergy() < 20 )
		{
			return trickster.getEnergy() / 20;
		}
		else
		{
			if( energy > 10 )
			{
				if( distance < 80  )
				{
					return 3;
				}
				else if( distance < 100 )
				{
					return 2.9;
				}
				else if( distance < 200 )
				{
					return 2.8;
				}
				else if( distance < 300 )
				{
					return 2.7;
				}
				else if( distance < 500 )
				{
					return 2.6;
				}
				else if( distance < 600 )
				{
					return 2.5;
				}
				else if( distance < 700 )
				{
					return 2.1;
				}
				else if( distance < 800 )
				{
					return 2;
				}
				else if( distance > 900 )
				{
					return 1.1;
				}
			}
			else if( energy <= 10 )
			{
				return energy / 12;
			}
			else if( energy <= 6 )
			{
				return energy / 30;
			}
			else if( energy <= 3 )
			{
				return 0.1;
			}
		}
		
		return 0.;
	}
	
	public static double bulletVelocity( double power )
	{
		return 20 - ( 3 * power ); 
	}
		
	// ������ ��ƽ�Ŀ� �� �ٿ� �ϴ��� �˷���
 	public static long getCoolingDownTick( double firePower, double CoolingRate )
 	{
        return (long)Math.ceil( ( 1.0 + ( firePower / 5 ) ) / CoolingRate );
   	}
    
	public static double getPower( double bVelocity )
	{ 
		return  ( 20 - bVelocity ) / 3;
	}
	
	public static double damage( double power )
	{
		if( power <= 1 )
			return 4 * power;
		else
			return 4 * power + ( 2 * ( power - 1 ) );
	}
}
