/*
 * Created on 2004. 4. 15.
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package march;
import robocode.*;
import java.util.Hashtable;
import java.util.Enumeration;
/**
 * @author n1
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

public class Data 
{
	private Hashtable hashtable;
//========================================================================
	private ScannedRobotEvent scannedRobot;
	private RobotDeathEvent robotDeath;
	private BulletHitEvent bulletHit;
	private HitByBulletEvent hitMe;
	private HitRobotEvent hitRobot;
	private Trickster trickster;
	private EnemyData eD;
	public static int enemySize;
	
// ������
	Data()
	{
		hashtable = new Hashtable();
	}
	
	Data( Trickster trickster )
	{
		hashtable = new Hashtable( Trickster.enemySize );	// ũ��� ����
		this.trickster = trickster; 
	}
	// ���� �� ����
	public void update( Object e )
	{
		if( e instanceof ScannedRobotEvent )
		{
			scannedRobot = (ScannedRobotEvent) e;
			
			if( containsKey( scannedRobot.getName() ) ) // ����
			{
				eD = getEnemyData( scannedRobot.getName() );
				eD.setScannedRobotEvent( scannedRobot );
				// ������
				eD.setGis();
				eD.setEnergyInfo();
				eD.setRampage( eD.getEnergyInfo().lastShotTick );
				//	trickster.out.println( getEnemyData( scannedRobot.getName() ).getEnergyInfo().energyInfoReport( scannedRobot.getName() ) );
				//trickster.out.println( getEnemyData( scannedRobot.getName() ).scannedRobotReport() );
			}
			else // ����
			{
				EnemyData temp = new EnemyData( trickster );
				temp.setScannedRobotEvent( scannedRobot );
				temp.setGis();
				temp.setEnergyInfo();	// ������
			//	trickster.out.println( temp.getEnergyInfo().energyInfoReport( scannedRobot.getName() ) );
			//	trickster.out.println( temp.scannedRobotReport() );
				temp.initRepulsion(); // �ʱ� ���Ŀ��� ���� ����
				put( temp );
				// �� ���⵵�� ����
				Satellite.distanceInfo.put( temp.getEnemyName(), temp.getEnemyPos() );
				++enemySize;
			}
		//	trickster.out.println( "�⺻ ���� ���� ������ ������ : " + size() );
		//	return true;
		}
		else if( e instanceof BulletHitEvent )
		{// �κ��� ���߾����� ���� ƽ
			bulletHit = (BulletHitEvent) e;
			
			if( containsKey( bulletHit.getName() ) )
			{
				getEnemyData( bulletHit.getName() ).setHitInfo( bulletHit.getTime(), bulletHit.getBullet().getPower() );
			}
			else
			{
				EnemyData temp = new EnemyData( trickster );
				temp.setHitInfo( bulletHit.getTime(), bulletHit.getBullet().getPower() );
				put( temp );
			}
		//	trickster.out.println( "�Ѿ� �¾��� ���� ������ ������ : " + size() );
		//	return true;
		}
		else if( e instanceof HitByBulletEvent )
		{
			hitMe = (HitByBulletEvent)e;
			
			if( containsKey( hitMe.getName() ) )
			{
				getEnemyData( hitMe.getName() ).setHitMe( hitMe, hitMe.getTime() );
				//report
			//	trickster.out.println( getEnemyData( hitMe.getName() ).hitByBulletReport() );
			}
		}
		else if( e instanceof HitRobotEvent )
		{//�κ��� �浹 // �������ڸ��� �� �̺�Ʈ�� �߻��� ���� 619
			//������ �ÿ� �ʱ�ȭ �۾��� ö���� ����.
			hitRobot = (HitRobotEvent) e;
			
			if( containsKey( hitRobot.getName() ) )
			{
				getEnemyData( hitRobot.getName() ).getEnergyInfo().setCollision();
			}
		}
		else if( e instanceof RobotDeathEvent )
		{// �κ��� �׾����� ����
			robotDeath = (RobotDeathEvent) e;
			
			if( containsKey( robotDeath.getName() ) )
			{
			//	trickster.out.println( "**************************�� ����" + robotDeath.getName() );
				enemySize = 0; // ���ϰ� ���� ���带 �غ�����.
				remove( robotDeath.getName() );
			}
		//	return true;
		}	
		//return false;
	}

	public void put( EnemyData e )
	{
		hashtable.put( e.getEnemyName(), e );
	}

	public EnemyData getEnemyData( String eName )
	{
		return (EnemyData)hashtable.get( eName );
	}
	
	public void remove( String key )
	{
		hashtable.remove( key );
	}
	
	public boolean containsKey( String eName )
	{
		return hashtable.containsKey( eName );
	}

	public boolean dataSizeFull()
	{
		return hashtable.size() == Trickster.enemySize;
	}
	
	public Enumeration getKeyEnum()
	{
		return hashtable.keys();
	}
	
	public int size()
	{
		return hashtable.size();
	}
}