public class CompilerTest {
	public static void main(String args[]) {
		System.out.println("Compiler operational");
	}
}
